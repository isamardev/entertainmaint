import { r as __toESM } from "../_runtime.mjs";
import { a as require_react, i as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { g as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { M as Eye, P as ExternalLink, S as LoaderCircle, h as RotateCcw, m as Save, v as PenLine } from "../_libs/lucide-react.mjs";
import { i as saveAdminPrivacyPolicy, n as getAdminPrivacyPolicy, t as DEFAULT_PRIVACY_POLICY } from "./privacyService-DHCqyMEH.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/admin.privacy-C4YqZ0pO.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function PrivacyPolicyForm() {
	const [form, setForm] = (0, import_react.useState)(() => ({ ...DEFAULT_PRIVACY_POLICY }));
	const [loading, setLoading] = (0, import_react.useState)(true);
	const [saving, setSaving] = (0, import_react.useState)(false);
	const [activeTab, setActiveTab] = (0, import_react.useState)("edit");
	const textareaRef = import_react.useRef(null);
	(0, import_react.useEffect)(() => {
		let active = true;
		(async () => {
			setLoading(true);
			try {
				const data = await getAdminPrivacyPolicy();
				if (active) setForm(data);
			} catch (err) {
				toast.error("Failed to load privacy policy settings.");
			} finally {
				if (active) setLoading(false);
			}
		})();
		return () => {
			active = false;
		};
	}, []);
	async function handleSave(e) {
		e.preventDefault();
		setSaving(true);
		try {
			await saveAdminPrivacyPolicy(form);
			toast.success("Privacy Policy updated successfully!");
		} catch (err) {
			toast.error(err?.message || "Failed to save Privacy Policy.");
		} finally {
			setSaving(false);
		}
	}
	function handleReset() {
		if (window.confirm("Are you sure you want to reset the Privacy Policy to the default template? Any unsaved changes will be lost.")) {
			setForm({
				...DEFAULT_PRIVACY_POLICY,
				last_updated: (/* @__PURE__ */ new Date()).toLocaleDateString("en-US", {
					month: "long",
					year: "numeric"
				})
			});
			toast.info("Reset to default Privacy Policy template.");
		}
	}
	function insertTag(openTag, closeTag, placeholder = "Text") {
		const el = textareaRef.current;
		if (!el) return;
		const start = el.selectionStart;
		const end = el.selectionEnd;
		const sel = el.value.substring(start, end) || placeholder;
		const replacement = `${openTag}${sel}${closeTag}`;
		const newVal = el.value.substring(0, start) + replacement + el.value.substring(end);
		setForm((prev) => ({
			...prev,
			content: newVal
		}));
		setTimeout(() => {
			el.focus();
			el.setSelectionRange(start + openTag.length, start + openTag.length + sel.length);
		}, 50);
	}
	if (loading) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col items-center justify-center p-16 text-neutral-500",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "w-8 h-8 animate-spin mb-3 text-black" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-sm font-semibold",
			children: "Loading Privacy Policy..."
		})]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		onSubmit: handleSave,
		className: "space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center justify-between gap-4 bg-neutral-50 border border-neutral-200 p-4 rounded-xl",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "font-bold text-base text-neutral-900",
					children: "Privacy Policy Editor"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-neutral-500",
					children: "Edit and publish legal disclosures, data collection terms, and cookie policies."
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/privacy-policy",
						target: "_blank",
						className: "inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold text-neutral-700 bg-white border border-neutral-300 rounded-lg hover:bg-neutral-100 transition-colors",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExternalLink, { size: 14 }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "View Public Page" })]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: handleReset,
						className: "inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold text-neutral-600 bg-white border border-neutral-300 rounded-lg hover:bg-neutral-100 transition-colors cursor-pointer",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, { size: 14 }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Reset Template" })]
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-1 md:grid-cols-2 gap-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
					className: "block text-xs font-bold uppercase tracking-wider text-neutral-700 mb-1.5",
					children: "Page Title"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					type: "text",
					required: true,
					value: form.title,
					onChange: (e) => setForm({
						...form,
						title: e.target.value
					}),
					placeholder: "Privacy Policy",
					className: "w-full px-3.5 py-2.5 text-sm bg-white border border-neutral-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-black"
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
					className: "block text-xs font-bold uppercase tracking-wider text-neutral-700 mb-1.5",
					children: "Last Updated Date / Notice"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					type: "text",
					required: true,
					value: form.last_updated,
					onChange: (e) => setForm({
						...form,
						last_updated: e.target.value
					}),
					placeholder: "October 2026",
					className: "w-full px-3.5 py-2.5 text-sm bg-white border border-neutral-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-black"
				})] })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
				className: "block text-xs font-bold uppercase tracking-wider text-neutral-700 mb-1.5",
				children: "Introduction Summary (Optional)"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
				rows: 2,
				value: form.intro || "",
				onChange: (e) => setForm({
					...form,
					intro: e.target.value
				}),
				placeholder: "Brief summary paragraph displayed under the title...",
				className: "w-full px-3.5 py-2.5 text-sm bg-white border border-neutral-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-black"
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "border border-neutral-300 rounded-xl overflow-hidden bg-white shadow-xs",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-center justify-between border-b border-neutral-200 bg-neutral-100/70 p-2 sm:px-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => setActiveTab("edit"),
							className: `inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold rounded-lg transition-colors cursor-pointer ${activeTab === "edit" ? "bg-black text-white" : "bg-white text-neutral-700 hover:bg-neutral-200 border border-neutral-300"}`,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PenLine, { size: 14 }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "HTML / Text Editor" })]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => setActiveTab("preview"),
							className: `inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold rounded-lg transition-colors cursor-pointer ${activeTab === "preview" ? "bg-black text-white" : "bg-white text-neutral-700 hover:bg-neutral-200 border border-neutral-300"}`,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eye, { size: 14 }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Live Preview" })]
						})]
					}), activeTab === "edit" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-center gap-1 mt-2 sm:mt-0",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => insertTag("<section>\n  <h2>", "</h2>\n  <p>Content...</p>\n</section>\n", "Section Title"),
								className: "px-2 py-1 text-xs font-bold bg-white hover:bg-neutral-200 border border-neutral-300 rounded text-neutral-800 cursor-pointer",
								title: "Add Section",
								children: "+ Section"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => insertTag("<h2>", "</h2>", "Section Heading"),
								className: "px-2 py-1 text-xs font-bold bg-white hover:bg-neutral-200 border border-neutral-300 rounded text-neutral-800 cursor-pointer",
								children: "H2"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => insertTag("<h3>", "</h3>", "Subheading"),
								className: "px-2 py-1 text-xs font-bold bg-white hover:bg-neutral-200 border border-neutral-300 rounded text-neutral-800 cursor-pointer",
								children: "H3"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => insertTag("<p>", "</p>", "Paragraph text"),
								className: "px-2 py-1 text-xs font-bold bg-white hover:bg-neutral-200 border border-neutral-300 rounded text-neutral-800 cursor-pointer",
								children: "Paragraph"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => insertTag("<ul>\n  <li>", "</li>\n  <li>Item 2</li>\n</ul>", "List item"),
								className: "px-2 py-1 text-xs font-bold bg-white hover:bg-neutral-200 border border-neutral-300 rounded text-neutral-800 cursor-pointer",
								children: "List"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => insertTag("<strong>", "</strong>", "bold text"),
								className: "px-2 py-1 text-xs font-bold bg-white hover:bg-neutral-200 border border-neutral-300 rounded text-neutral-800 cursor-pointer font-serif",
								children: "B"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => insertTag("<a href=\"https://...\" class=\"underline\">", "</a>", "link text"),
								className: "px-2 py-1 text-xs font-bold bg-white hover:bg-neutral-200 border border-neutral-300 rounded text-neutral-800 cursor-pointer",
								children: "Link"
							})
						]
					})]
				}), activeTab === "edit" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "p-2 sm:p-4 bg-neutral-900",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
						ref: textareaRef,
						rows: 22,
						required: true,
						value: form.content,
						onChange: (e) => setForm({
							...form,
							content: e.target.value
						}),
						className: "w-full font-mono text-xs sm:text-sm text-green-400 bg-neutral-950 p-4 rounded-lg border border-neutral-800 focus:outline-none focus:ring-1 focus:ring-green-500 leading-relaxed",
						placeholder: "<section> ... </section>"
					})
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "p-6 md:p-10 bg-white max-h-[600px] overflow-y-auto",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mx-auto max-w-3xl",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
							className: "mb-8 border-b-2 border-neutral-200 pb-4",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-[11px] font-black uppercase tracking-widest text-black",
									children: "Legal"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
									className: "font-serif text-3xl font-bold text-neutral-900 mt-1",
									children: form.title
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-xs text-neutral-500 mt-2",
									children: ["Last updated: ", form.last_updated]
								}),
								form.intro && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-3 text-sm text-neutral-700 leading-relaxed font-sans",
									children: form.intro
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "prose max-w-none text-sm md:text-base leading-relaxed text-neutral-900 space-y-6 prose-headings:font-bold prose-headings:font-serif prose-headings:text-neutral-900 prose-h2:text-xl prose-h2:mt-6 prose-h2:mb-2 prose-p:my-3 prose-ul:list-disc prose-ul:pl-5 prose-li:my-1",
							dangerouslySetInnerHTML: { __html: form.content }
						})]
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex items-center justify-end gap-4 pt-2",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "submit",
					disabled: saving,
					className: "inline-flex items-center gap-2 px-6 py-3 bg-black hover:bg-neutral-800 text-white text-sm font-black uppercase tracking-wider rounded-lg transition-colors shadow-sm disabled:opacity-50 cursor-pointer",
					children: saving ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "w-4 h-4 animate-spin" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Saving Changes..." })] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Save, { size: 16 }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Save Privacy Policy" })] })
				})
			})
		]
	});
}
function AdminPrivacy() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "display mb-2 text-xl font-black uppercase",
			children: "Privacy Policy Management"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "mb-6 text-sm text-gray-600",
			children: [
				"Update the official Privacy Policy terms, data handling policies, and legal notices that appear on the public site at ",
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("code", {
					className: "bg-gray-100 px-1 py-0.5 rounded text-xs",
					children: "/privacy-policy"
				}),
				"."
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrivacyPolicyForm, {})
	] });
}
//#endregion
export { AdminPrivacy as component };
