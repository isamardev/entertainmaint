import { r as __toESM } from "../_runtime.mjs";
import { t as getApiUrl } from "./safe-fetch-DWXDrtX7.mjs";
import { a as require_react, i as require_jsx_runtime, t as useQuery } from "../_libs/react+tanstack__react-query.mjs";
import { n as categoryService, t as articleService } from "./articleService-UhMa44iK.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { C as Italic, D as Bold, T as Image, a as Underline, c as TextAlignStart, d as TextAlignCenter, f as Share2, i as Unlink, l as TextAlignJustify, r as Video, u as TextAlignEnd, v as List, x as Link, y as ListOrdered } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/ArticleForm-B-wKKA4e.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var _removeStylesInjected = false;
function ensureRemoveStylesInjected() {
	if (_removeStylesInjected) return;
	_removeStylesInjected = true;
	const id = "art-inline-remove-styles";
	if (document.getElementById(id)) return;
	const style = document.createElement("style");
	style.id = id;
	style.textContent = ".art-inline-remove{  display:inline-flex; align-items:center; gap:6px;  padding:5px 12px;  font-size:12px; line-height:1;  font-weight:700; text-transform:uppercase; letter-spacing:.04em;  background:rgb(220 38 38);  color:#fff;  border-radius:9999px;  border:1px solid rgb(0 0 0 / 0.1);  box-shadow:0 6px 14px rgb(0 0 0 / 0.18);  cursor:pointer;  white-space:nowrap;  user-select:none;  transition:transform .08s ease, background .15s ease, opacity .15s ease;}.art-inline-remove:hover{ background:#7f1d1d; transform:translateY(-1px); color:#fff }.art-inline-row{  display:flex; align-items:center; justify-content:space-between; gap:8px;  padding-top:6px;}.art-inline-wrap{  position:relative;}.art-inline-wrap:hover{ outline:2px dashed #6b7280; outline-offset:3px; border-radius:10px; }.art-inline-caption{  margin:0; font-size:12px; color:#4b5563; flex:1 1 auto; min-width:0;}";
	document.head.appendChild(style);
}
function slugify(s) {
	return s.toLowerCase().trim().replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, "").slice(0, 90);
}
function ArticleForm({ initial, onSaved, uploadingState }) {
	const { data: categories = [] } = useQuery({
		queryKey: ["categories"],
		queryFn: categoryService.list
	});
	const [form, setForm] = (0, import_react.useState)({
		title: "",
		slug: "",
		dek: "",
		body: "",
		hero_image_hd: "",
		hero_image_lq: "",
		hero_caption: "",
		embed_url: "",
		category_id: null,
		status: "draft",
		is_breaking: false,
		is_featured: false,
		...initial
	});
	const [saving, setSaving] = (0, import_react.useState)(false);
	const [localUploading, setLocalUploading] = (0, import_react.useState)(false);
	const [localUploadProgress, setLocalUploadProgress] = (0, import_react.useState)(null);
	const [err, setErr] = (0, import_react.useState)(null);
	const [categoryError, setCategoryError] = (0, import_react.useState)(false);
	const isUploading = uploadingState ? uploadingState.uploading : localUploading;
	const progressPct = uploadingState ? uploadingState.progress : localUploadProgress;
	const setIsUploading = uploadingState?.setUploading ?? setLocalUploading;
	const setProgressPct = uploadingState?.setProgress ?? setLocalUploadProgress;
	(0, import_react.useEffect)(() => {
		if (initial) setForm((f) => ({
			...f,
			...initial
		}));
	}, [initial]);
	function set(k, v) {
		setForm((f) => ({
			...f,
			[k]: v
		}));
	}
	const categoryId = typeof form.category_id === "string" ? Number(form.category_id) : form.category_id;
	async function upload(file) {
		const setU = setIsUploading;
		const setP = setProgressPct;
		const setE = setErr;
		setU(true);
		setP(0);
		setE(null);
		try {
			const prepared = await maybeCompressImage(file);
			const formData = new FormData();
			formData.append("image", prepared);
			const data = await uploadWithProgress(getApiUrl("/upload"), formData, (p) => setP(p));
			set("hero_image_hd", data.imageUrl);
			set("hero_image_lq", data.imageUrl);
			setP(100);
			toast.success("Image uploaded successfully!");
		} catch (e) {
			setE(e.message);
			toast.error(e.message || "Upload failed.");
		} finally {
			setU(false);
			setP(null);
		}
	}
	async function submit(e) {
		e.preventDefault();
		setErr(null);
		if (!categoryId) {
			setCategoryError(true);
			toast.error("Please select a category before saving the article.");
			return;
		}
		setCategoryError(false);
		setSaving(true);
		try {
			const payload = {
				...form,
				category_id: categoryId,
				slug: form.slug && form.slug.length > 0 ? form.slug : slugify(form.title ?? ""),
				published_at: form.status === "published" ? form.published_at ?? (/* @__PURE__ */ new Date()).toISOString() : null
			};
			const saved = initial?.id ? await articleService.update(initial.id, payload) : await articleService.create(payload);
			toast.success(initial?.id ? "Article updated!" : "Article created!");
			onSaved(saved);
		} catch (e) {
			console.error("Error saving article:", e);
			setErr(e.message);
			toast.error(`Failed to save article: ${e.message}`);
		} finally {
			setSaving(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		onSubmit: submit,
		className: "grid gap-6 lg:grid-cols-[1fr_320px]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "space-y-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Title",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						required: true,
						value: form.title ?? "",
						onChange: (e) => set("title", e.target.value),
						onBlur: (e) => !form.slug && set("slug", slugify(e.target.value)),
						className: "w-full border border-gray-300 bg-white px-3 py-2 text-lg outline-none focus:border-black"
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Slug",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						value: form.slug ?? "",
						onChange: (e) => set("slug", e.target.value),
						className: "w-full border border-gray-300 bg-white px-3 py-2 outline-none focus:border-black"
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Dek (subheadline)",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
						rows: 2,
						value: form.dek ?? "",
						onChange: (e) => set("dek", e.target.value),
						className: "w-full border border-gray-300 bg-white px-3 py-2 outline-none focus:border-black"
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Body",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RichTextEditor, {
						value: form.body ?? "",
						onChange: (value) => set("body", value),
						uploadingState
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Hero caption",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						value: form.hero_caption ?? "",
						onChange: (e) => set("hero_caption", e.target.value),
						className: "w-full border border-gray-300 bg-white px-3 py-2 outline-none focus:border-black"
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Field, {
					label: "Embedded post link",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						value: form.embed_url ?? "",
						onChange: (e) => set("embed_url", e.target.value),
						placeholder: "Instagram, X / Twitter, TikTok, or any public post URL",
						className: "w-full border border-gray-300 bg-white px-3 py-2 outline-none focus:border-black"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-1 text-xs text-muted-foreground",
						children: "Photo upload aur post embed link dono ek sath save ho sakte hain."
					})]
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
			className: "space-y-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "border border-gray-200 bg-gray-50 p-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-xs font-black uppercase tracking-widest text-black mb-3",
							children: "Publish"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "mb-2 block text-sm",
							children: ["Status", /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
								value: form.status ?? "draft",
								onChange: (e) => set("status", e.target.value),
								className: "mt-1 w-full border border-gray-300 bg-white px-2 py-1.5",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "draft",
										children: "Draft"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "published",
										children: "Published"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "archived",
										children: "Archived"
									})
								]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "mb-2 flex items-center gap-2 text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "checkbox",
								checked: !!form.is_breaking,
								onChange: (e) => set("is_breaking", e.target.checked)
							}), "Mark as breaking"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "flex items-center gap-2 text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "checkbox",
								checked: !!form.is_featured,
								onChange: (e) => set("is_featured", e.target.checked)
							}), "Featured on home"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Field, {
							label: "Category",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
								value: categoryId ?? "",
								onChange: (e) => {
									const val = e.target.value ? Number(e.target.value) : null;
									set("category_id", val);
									if (val && categoryError) setCategoryError(false);
								},
								className: `w-full border bg-white px-2 py-1.5 ${categoryError ? "border-red-500 focus:border-red-600" : "border-gray-300 focus:border-black"}`,
								"aria-invalid": categoryError || void 0,
								"aria-describedby": categoryError ? "category-error" : void 0,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "",
									children: "— None —"
								}), categories.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: c.id,
									children: c.name
								}, c.id))]
							}), categoryError && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								id: "category-error",
								className: "mt-1 text-xs text-red-600 font-semibold",
								children: "Please select a category — you cannot save an article without one."
							})]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "border border-gray-200 bg-gray-50 p-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-xs font-black uppercase tracking-widest text-black mb-3",
							children: "Hero Image"
						}),
						form.hero_image_hd && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "relative mb-2 group",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: form.hero_image_hd,
								alt: "",
								className: "w-full block"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onMouseDown: (e) => e.preventDefault(),
								onClick: () => {
									set("hero_image_hd", "");
									set("hero_image_lq", "");
									toast.success("Hero image removed.");
								},
								className: "absolute top-2 right-2 z-20 bg-black/80 hover:bg-black text-white text-xs font-bold uppercase rounded px-2 py-1 flex items-center gap-1 shadow",
								title: "Remove hero image",
								children: "🗑 Remove"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "file",
							accept: "image/*",
							onChange: (e) => e.target.files?.[0] && upload(e.target.files[0]),
							className: "w-full"
						}),
						isUploading && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "text-sm text-black mt-2",
							children: ["Uploading…", typeof progressPct === "number" ? ` ${progressPct}%` : ""]
						}),
						typeof progressPct === "number" && progressPct > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-2 w-full overflow-hidden rounded-full bg-gray-200 h-2",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "h-full bg-black transition-all",
								style: { width: `${Math.max(0, Math.min(100, progressPct))}%` }
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							placeholder: "…or paste image URL",
							value: form.hero_image_hd ?? "",
							onChange: (e) => {
								set("hero_image_hd", e.target.value);
								set("hero_image_lq", e.target.value);
							},
							className: "mt-2 w-full border border-gray-300 bg-white px-2 py-1.5 text-xs"
						})
					]
				}),
				err && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "border border-red-500 bg-red-50 p-3 text-xs",
					children: err
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					disabled: saving || isUploading || typeof progressPct === "number" && progressPct < 100,
					className: "bg-black text-white hover:bg-gray-800 w-full py-3 font-black uppercase tracking-widest disabled:opacity-60",
					title: isUploading || typeof progressPct === "number" && progressPct < 100 ? "Wait until the upload finishes (100%) before saving." : void 0,
					children: saving ? "Saving…" : isUploading || typeof progressPct === "number" && progressPct < 100 ? `Uploading… ${typeof progressPct === "number" ? progressPct + "%" : ""}` : "Save Article"
				})
			]
		})]
	});
}
async function maybeCompressImage(file) {
	if (!file.type.startsWith("image/")) return file;
	if (file.size <= 6 * 1024 * 1024) return file;
	try {
		const bitmap = await createImageBitmap(file);
		const scale = Math.min(1, 2560 / Math.max(bitmap.width, bitmap.height));
		const width = Math.max(1, Math.round(bitmap.width * scale));
		const height = Math.max(1, Math.round(bitmap.height * scale));
		const canvas = document.createElement("canvas");
		canvas.width = width;
		canvas.height = height;
		const ctx = canvas.getContext("2d");
		if (!ctx) return file;
		ctx.drawImage(bitmap, 0, 0, width, height);
		const blob = await new Promise((resolve) => canvas.toBlob((b) => resolve(b), file.type === "image/png" ? "image/png" : "image/jpeg", .88));
		if (!blob) return file;
		if (blob.size >= file.size) return file;
		const baseName = file.name.replace(/\.[^.]+$/, "");
		const ext = file.type === "image/png" ? "png" : "jpg";
		return new File([blob], `${baseName}.${ext}`, { type: file.type === "image/png" ? "image/png" : "image/jpeg" });
	} catch {
		return file;
	}
}
async function uploadWithProgress(url, formData, onProgress) {
	return await new Promise((resolve, reject) => {
		const xhr = new XMLHttpRequest();
		xhr.open("POST", url, true);
		xhr.responseType = "json";
		onProgress(0);
		xhr.upload.onprogress = (e) => {
			if (!e.lengthComputable) return;
			const p = Math.round(e.loaded / e.total * 100);
			onProgress(Math.max(0, Math.min(100, p)));
		};
		xhr.onload = () => {
			const status = xhr.status;
			const json = xhr.response;
			if (status >= 200 && status < 300) {
				resolve(json);
				return;
			}
			const errorFromJson = json && typeof json === "object" ? json.error : null;
			if (errorFromJson) {
				reject(new Error(String(errorFromJson)));
				return;
			}
			const text = xhr.responseText || "";
			if (text) {
				try {
					const parsed = JSON.parse(text);
					if (parsed?.error) return reject(new Error(String(parsed.error)));
				} catch {}
				return reject(new Error(text));
			}
			reject(/* @__PURE__ */ new Error("Upload failed"));
		};
		xhr.onerror = () => reject(/* @__PURE__ */ new Error("Network error"));
		xhr.send(formData);
	});
}
function Field({ label, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "block",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "text-xs font-black uppercase tracking-widest text-black mb-1.5",
			children: label
		}), children]
	});
}
function RichTextEditor({ value, onChange, uploadingState }) {
	const editorRef = (0, import_react.useRef)(null);
	const pendingUploadsRef = (0, import_react.useRef)(0);
	const perFileProgressRef = (0, import_react.useRef)(/* @__PURE__ */ new Map());
	const uploadTokenRef = (0, import_react.useRef)(0);
	const attachedBtnsRef = (0, import_react.useRef)(/* @__PURE__ */ new Set());
	(0, import_react.useEffect)(() => {
		if (!editorRef.current) return;
		if (editorRef.current.innerHTML !== value) editorRef.current.innerHTML = value || "<p></p>";
	}, [value]);
	(0, import_react.useEffect)(() => {
		if (!editorRef.current) return;
		const editor = editorRef.current;
		ensureRemoveStylesInjected();
		function isRemovableBlock(el) {
			if (!el) return false;
			if (el.getAttribute && el.getAttribute("data-art-block") === "1") return true;
			return false;
		}
		function makeRemoveBtn(block) {
			const btn = document.createElement("button");
			btn.type = "button";
			btn.className = "art-inline-remove";
			btn.setAttribute("title", "Remove this block");
			btn.setAttribute("contenteditable", "false");
			btn.setAttribute("data-art-remove", "1");
			btn.innerHTML = "<span aria-hidden=\"true\" style=\"pointer-events:none\">🗑 Remove</span>";
			btn.addEventListener("mousedown", (e) => {
				e.preventDefault();
				e.stopPropagation();
			});
			btn.addEventListener("click", (e) => {
				e.preventDefault();
				e.stopPropagation();
				removeBlock(block);
			});
			btn.addEventListener("mouseover", (e) => e.stopPropagation());
			btn.addEventListener("mouseout", (e) => e.stopPropagation());
			attachedBtnsRef.current.add(btn);
			return btn;
		}
		function ensureBlockUi(block) {
			if (!editor.contains(block)) return;
			if (block.getAttribute("data-art-block") === "1") {
				const row = block.querySelector(":scope > .art-inline-row");
				if (!row) buildBottomRow(block);
				else if (!row.querySelector("button.art-inline-remove")) row.appendChild(makeRemoveBtn(block));
				return;
			}
			const tag = block.tagName;
			if (tag === "VIDEO" || tag === "IFRAME" || tag === "A" && block.querySelector("img, video, iframe") != null || tag === "BLOCKQUOTE" && /(^|\s)(twitter-tweet|instagram-media|fb-post|tiktok-embed)(\s|$)/.test(block.getAttribute("class") || "")) {
				const fig = document.createElement("figure");
				fig.setAttribute("data-art-block", "1");
				fig.classList.add("art-inline-wrap");
				fig.style.margin = "0";
				fig.style.padding = "0";
				fig.style.background = "transparent";
				const style = block.getAttribute("style") || "";
				if (style) fig.style.cssText = style;
				const prev = block.previousSibling;
				const parent = block.parentElement || editor;
				if (prev) prev.after(fig);
				else parent.insertBefore(fig, parent.firstChild);
				fig.appendChild(block);
				buildBottomRow(fig);
				return;
			}
			if (tag === "FIGURE") {
				block.setAttribute("data-art-block", "1");
				block.classList.add("art-inline-wrap");
				buildBottomRow(block);
				return;
			}
		}
		function buildBottomRow(block) {
			block.querySelectorAll(":scope > .art-inline-row").forEach((r) => {
				r.querySelectorAll("button.art-inline-remove").forEach((b) => attachedBtnsRef.current.delete(b));
				r.remove();
			});
			const row = document.createElement("div");
			row.className = "art-inline-row";
			row.setAttribute("contenteditable", "false");
			row.style.background = "transparent";
			const oldCaption = block.querySelector(":scope > figcaption");
			let captionText = "";
			if (oldCaption) {
				captionText = (oldCaption.textContent || "").trim();
				oldCaption.remove();
			}
			if (captionText) {
				const cap = document.createElement("div");
				cap.className = "art-inline-caption";
				cap.textContent = captionText;
				cap.setAttribute("contenteditable", "false");
				row.appendChild(cap);
			} else {
				const spacer = document.createElement("div");
				spacer.className = "art-inline-caption";
				spacer.textContent = "\xA0";
				spacer.setAttribute("contenteditable", "false");
				spacer.style.visibility = "hidden";
				spacer.style.flex = "1 1 auto";
				row.appendChild(spacer);
			}
			row.appendChild(makeRemoveBtn(block));
			block.appendChild(row);
		}
		function inventoryAll() {
			Array.from(editor.querySelectorAll("figure, video, iframe, a:has(img, video, iframe)")).forEach(ensureBlockUi);
		}
		function removeBlock(block) {
			const toRemove = block.closest("[data-art-block=\"1\"]") || block;
			const prevEl = toRemove.previousElementSibling;
			const nextEl = toRemove.nextElementSibling;
			const prevText = toRemove.previousSibling;
			const nextText = toRemove.nextSibling;
			toRemove.querySelectorAll("button.art-inline-remove").forEach((b) => attachedBtnsRef.current.delete(b));
			toRemove.remove();
			const isEmptyParagraph = (n) => {
				if (!n || n.tagName !== "P") return false;
				const txt = (n.textContent || "").trim() === "";
				const hasOnlyBreaks = n.children.length === 0 || n.children.length === 1 && n.children[0].tagName === "BR";
				return txt && hasOnlyBreaks;
			};
			if (isEmptyParagraph(prevEl)) prevEl.remove();
			if (isEmptyParagraph(nextEl)) nextEl.remove();
			if (prevText && prevText.nodeType === 3 && (prevText.textContent || "").trim() === "") prevText.remove();
			if (nextText && nextText.nodeType === 3 && (nextText.textContent || "").trim() === "") nextText.remove();
			const last = editor.lastElementChild;
			if (!last || last.tagName !== "P") {
				const p = document.createElement("p");
				p.innerHTML = "<br>";
				editor.appendChild(p);
			}
			syncValue();
		}
		const ignoreMutation = { ignore: false };
		const io = new MutationObserver(() => {
			if (ignoreMutation.ignore) return;
			reInventory();
		});
		function reInventory() {
			ignoreMutation.ignore = true;
			try {
				requestAnimationFrame(() => {
					inventoryAll();
					ignoreMutation.ignore = false;
				});
			} finally {}
		}
		io.observe(editor, {
			childList: true,
			subtree: true
		});
		inventoryAll();
		editor.addEventListener("input", reInventory);
		editor.addEventListener("paste", () => setTimeout(reInventory, 80));
		function onKeyDown(e) {
			if (e.key !== "Backspace" && e.key !== "Delete") return;
			const sel = window.getSelection();
			if (!sel || sel.rangeCount === 0 || !editor.contains(sel.anchorNode)) return;
			const range = sel.getRangeAt(0);
			if (!range.collapsed) return;
			let candidate = range.startContainer.nodeType === 1 ? range.startContainer : range.startContainer.parentElement;
			while (candidate && candidate !== editor) {
				if (isRemovableBlock(candidate)) {
					e.preventDefault();
					removeBlock(candidate);
					return;
				}
				candidate = candidate.parentElement;
			}
		}
		editor.addEventListener("keydown", onKeyDown, true);
		return () => {
			io.disconnect();
			editor.removeEventListener("input", reInventory);
			editor.removeEventListener("paste", reInventory);
			editor.removeEventListener("keydown", onKeyDown, true);
			attachedBtnsRef.current.forEach((b) => b.remove());
			attachedBtnsRef.current.clear();
		};
	}, []);
	function syncValue() {
		const raw = editorRef.current?.innerHTML ?? "";
		const trimmed = stripTransientHtml(raw).trim();
		onChange(trimmed === "<p></p>" ? "" : trimmed);
	}
	function run(command, commandValue) {
		const selection = window.getSelection();
		const hasSelection = !!selection && selection.rangeCount > 0 && !selection.getRangeAt(0).collapsed && editorRef.current?.contains(selection.anchorNode);
		if ((/* @__PURE__ */ new Set([
			"bold",
			"italic",
			"underline",
			"createLink"
		])).has(command) && !hasSelection) {
			editorRef.current?.focus();
			return;
		}
		editorRef.current?.focus();
		document.execCommand(command, false, commandValue);
		syncValue();
	}
	function insertHtmlAtCursor(html) {
		editorRef.current?.focus();
		const sel = window.getSelection();
		if (!sel || sel.rangeCount === 0 || !editorRef.current?.contains(sel.anchorNode)) {
			const el = editorRef.current;
			if (!el) return;
			el.insertAdjacentHTML("beforeend", html);
			syncValue();
			return;
		}
		const range = sel.getRangeAt(0);
		range.deleteContents();
		const tmp = document.createElement("div");
		tmp.innerHTML = html;
		const frag = document.createDocumentFragment();
		let lastNode = null;
		while (tmp.firstChild) {
			lastNode = tmp.firstChild;
			frag.appendChild(tmp.firstChild);
		}
		range.insertNode(frag);
		if (lastNode) {
			range.setStartAfter(lastNode);
			range.collapse(true);
			sel.removeAllRanges();
			sel.addRange(range);
		}
		syncValue();
	}
	function beginUpload() {
		pendingUploadsRef.current += 1;
		uploadingState?.setUploading?.(true);
	}
	function endUpload(tokenId, _success) {
		perFileProgressRef.current.delete(tokenId);
		pendingUploadsRef.current = Math.max(0, pendingUploadsRef.current - 1);
		if (pendingUploadsRef.current === 0) {
			uploadingState?.setProgress?.(null);
			setTimeout(() => uploadingState?.setUploading?.(false), 350);
		} else recomputeAggregateProgress();
	}
	function recomputeAggregateProgress() {
		const map = perFileProgressRef.current;
		if (map.size === 0) {
			uploadingState?.setProgress?.(null);
			return;
		}
		let sum = 0;
		map.forEach((v) => sum += v);
		const avg = Math.round(sum / map.size);
		uploadingState?.setProgress?.(avg);
	}
	function fileIsVideo(file) {
		return file.type.startsWith("video/");
	}
	function figureImageHtml(src, alt) {
		const safeAlt = String(alt || "").replace(/"/g, "&quot;");
		return `<figure class="my-6 flex flex-col items-center"><img src="${String(src).replace(/"/g, "&quot;")}" alt="${safeAlt}" class="w-full max-w-full rounded border border-gray-200 bg-gray-50" loading="lazy" />` + (safeAlt ? `<figcaption class="meta mt-2 text-sm text-muted-foreground text-center">${safeAlt.replace(/</g, "&lt;").replace(/>/g, "&gt;")}</figcaption>` : "") + "</figure><p><br></p>";
	}
	function figureVideoHtml(src, label) {
		const safeSrc = String(src).replace(/"/g, "&quot;");
		const safeLabel = String(label || "").replace(/</g, "&lt;").replace(/>/g, "&gt;");
		return `<figure class="my-8 w-full max-w-none"><div class="w-full overflow-hidden rounded border border-gray-200 bg-black"><video src="${safeSrc}" class="h-full w-full" controls playsinline preload="metadata" poster=""></video></div>` + (safeLabel ? `<figcaption class="meta mt-2 text-sm text-muted-foreground text-center">${safeLabel}</figcaption>` : "") + "</figure><p><br></p>";
	}
	function insertLink() {
		const sel = window.getSelection();
		if (!sel || sel.rangeCount === 0 || sel.getRangeAt(0).collapsed || !editorRef.current?.contains(sel.anchorNode)) {
			toast.info("Select some text first, then click Add link to insert a hyperlink.");
			editorRef.current?.focus();
			return;
		}
		const currentAnchor = (() => {
			try {
				let node = sel.anchorNode;
				while (node && node !== editorRef.current) {
					if (node.nodeType === 1 && node.tagName === "A") return node.href || "";
					node = node.parentNode;
				}
			} catch {}
			return "";
		})();
		const url = window.prompt("Link URL daalein (https://...):", currentAnchor || "https://");
		if (url == null) return;
		const trimmed = url.trim();
		if (!trimmed) return;
		run("createLink", trimmed);
		(editorRef.current?.querySelectorAll?.("a") ?? []).forEach((aEl) => {
			const a = aEl;
			if (a.getAttribute("data-link-applied") === "1") return;
			if (!a.href) return;
			const href = a.getAttribute("href") || "";
			if (href && href.trim() !== "#" && !a.getAttribute("target")) {
				a.setAttribute("target", "_blank");
				a.setAttribute("rel", "noreferrer noopener nofollow");
				a.setAttribute("data-link-applied", "1");
			}
		});
		syncValue();
	}
	function removeLink() {
		const sel = window.getSelection();
		if (!sel || sel.rangeCount === 0 || !editorRef.current?.contains(sel.anchorNode)) {
			editorRef.current?.focus();
			return;
		}
		run("unlink");
	}
	async function insertImageInline() {
		editorRef.current?.focus();
		const input = document.createElement("input");
		input.type = "file";
		input.multiple = true;
		input.accept = "image/*,video/*";
		input.onchange = () => {
			const files = Array.from(input.files ?? []).filter((f) => f.type.startsWith("image/") || f.type.startsWith("video/"));
			if (files.length === 0) return;
			uploadMany(files).catch((e) => toast.error(e?.message || "Upload failed"));
		};
		input.click();
	}
	async function uploadMany(files) {
		const order = files.map((f, i) => ({
			file: f,
			index: i,
			token: ++uploadTokenRef.current,
			done: null,
			err: null
		}));
		order.forEach((o) => {
			perFileProgressRef.current.set(o.token, 0);
			beginUpload();
		});
		recomputeAggregateProgress();
		const progressFor = (token) => (p) => {
			perFileProgressRef.current.set(token, p);
			recomputeAggregateProgress();
		};
		await Promise.all(order.map(async (o) => {
			try {
				const prepared = fileIsVideo(o.file) ? o.file : await maybeCompressImage(o.file);
				const formData = new FormData();
				formData.append("image", prepared);
				const data = await uploadWithProgress(getApiUrl("/upload"), formData, progressFor(o.token));
				perFileProgressRef.current.set(o.token, 100);
				recomputeAggregateProgress();
				o.done = {
					url: data.imageUrl,
					label: o.file.name
				};
				toast.success(`${fileIsVideo(o.file) ? "Video" : "Image"} uploaded (${o.index + 1}/${order.length})`);
			} catch (e) {
				o.err = e;
			} finally {
				endUpload(o.token, !o.err);
			}
		}));
		order.sort((a, b) => a.index - b.index).forEach((o) => {
			if (o.err) {
				toast.error(o.err?.message ? o.err.message : `${o.file.name} upload failed`);
				return;
			}
			if (!o.done) return;
			if (fileIsVideo(o.file)) insertHtmlAtCursor(figureVideoHtml(o.done.url, o.done.label));
			else insertHtmlAtCursor(figureImageHtml(o.done.url, o.done.label));
		});
	}
	function insertVideoEmbed() {
		editorRef.current?.focus();
		const url = window.prompt("Paste a public video URL (YouTube or Vimeo iframe embed URLs are also accepted):", "https://www.youtube.com/watch?v=");
		if (!url) return;
		const embed = (() => {
			try {
				const u = new URL(url.trim());
				const host = u.hostname.replace(/^www\./, "");
				if (host === "youtube.com" || host === "m.youtube.com" || host === "music.youtube.com" || host === "youtu.be") {
					const videoId = (() => {
						if (host === "youtu.be") return u.pathname.split("/").filter(Boolean)[0] || null;
						if (u.pathname === "/watch") return u.searchParams.get("v");
						if (u.pathname.startsWith("/shorts/") || u.pathname.startsWith("/embed/")) return u.pathname.split("/").filter(Boolean)[1] || null;
						return null;
					})();
					if (!videoId) return null;
					return {
						tag: "iframe",
						src: `https://www.youtube-nocookie.com/embed/${videoId}?rel=0`,
						title: "YouTube video"
					};
				}
				if (host === "vimeo.com") {
					const id = u.pathname.split("/").filter(Boolean).pop();
					if (!id || !/^\d+$/.test(id)) return null;
					return {
						tag: "iframe",
						src: `https://player.vimeo.com/video/${id}`,
						title: "Vimeo video"
					};
				}
				if (host === "youtube-nocookie.com" || host === "player.vimeo.com") return {
					tag: "iframe",
					src: u.toString(),
					title: "Embedded video"
				};
				return null;
			} catch {
				return null;
			}
		})();
		if (!embed) {
			toast.error("This video URL is not supported. Please paste a valid YouTube or Vimeo URL.");
			return;
		}
		insertHtmlAtCursor(`<figure class="my-8 w-full max-w-none"><div class="aspect-video w-full overflow-hidden rounded border border-gray-200 bg-black"><iframe src="${embed.src.replace(/"/g, "&quot;")}" title="${(embed.title || "Video").replace(/"/g, "&quot;")}" class="h-full w-full" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen loading="lazy"></iframe></div></figure><p><br></p>`);
	}
	function insertPostEmbed() {
		editorRef.current?.focus();
		const url = window.prompt("Paste a public social post URL (X / Twitter, Instagram, TikTok, Facebook, YouTube):", "");
		if (!url) return;
		const normalized = url.trim();
		let parsed = null;
		try {
			parsed = new URL(normalized);
		} catch {
			toast.error("Please enter a valid URL.");
			return;
		}
		const host = parsed.hostname.replace(/^www\./, "");
		const permalink = parsed.toString().replace(/"/g, "&quot;");
		if (host === "twitter.com" || host === "x.com" || host === "mobile.twitter.com" || host === "m.x.com") {
			const safePermalink = `https://x.com${parsed.pathname.replace(/\/+$/, "") || "/"}`.replace(/"/g, "&quot;");
			insertHtmlAtCursor(`<figure class="my-8 w-full max-w-none"><blockquote class="twitter-tweet" data-lang="en" data-dnt="true" data-embed-permalink="${safePermalink}"><p lang="en" dir="ltr"><a href="${safePermalink}">View post on X / Twitter</a></p></blockquote></figure><p><br></p>`);
			toast.success("X / Twitter post embedded.");
			return;
		}
		if (host === "instagram.com" || host === "m.instagram.com" || host === "instagr.am") {
			const pathOnly = parsed.pathname.replace(/\/+$/, "") + "/";
			if (!(pathOnly.startsWith("/p/") || pathOnly.startsWith("/reel/") || pathOnly.startsWith("/tv/") || pathOnly.startsWith("/stories/"))) {
				toast.error("This Instagram link is not valid. Please paste a post, reel, or story URL.");
				return;
			}
			const safePermalink = `https://www.instagram.com${pathOnly}`.replace(/"/g, "&quot;");
			insertHtmlAtCursor(`<figure class="my-8 w-full max-w-none"><blockquote class="instagram-media" data-instgrm-captioned data-instgrm-permalink="${safePermalink}" data-instgrm-version="14" data-embed-type="instagram" data-embed-permalink="${safePermalink}"><a href="${safePermalink}">View post on Instagram</a></blockquote></figure><p><br></p>`);
			toast.success("Instagram post embedded.");
			return;
		}
		if (host === "tiktok.com" || host.endsWith(".tiktok.com")) {
			const safePermalink = `https://www.tiktok.com${parsed.pathname.replace(/\/+$/, "")}`.replace(/"/g, "&quot;");
			insertHtmlAtCursor(`<figure class="my-8 w-full max-w-none"><blockquote class="tiktok-embed" cite="${safePermalink}" data-video-id="" data-embed-type="tiktok" data-embed-permalink="${safePermalink}"><section><a target="_blank" rel="noopener noreferrer nofollow" href="${safePermalink}">View post on TikTok</a></section></blockquote></figure><p><br></p>`);
			toast.success("TikTok post embedded.");
			return;
		}
		if (host === "facebook.com" || host.endsWith(".facebook.com") || host === "fb.watch" || host === "fb.com") {
			const safePermalink = permalink;
			insertHtmlAtCursor(`<figure class="my-8 w-full max-w-none"><blockquote class="fb-post" data-href="${safePermalink}" data-width="500" data-show-text="true" data-embed-type="facebook" data-embed-permalink="${safePermalink}"><a href="${safePermalink}">View post on Facebook</a></blockquote></figure><p><br></p>`);
			toast.success("Facebook post embedded.");
			return;
		}
		if (host === "youtube.com" || host === "m.youtube.com" || host === "youtu.be" || host === "youtube-nocookie.com" || host === "music.youtube.com") {
			const videoId = (() => {
				if (host === "youtu.be") return parsed.pathname.split("/").filter(Boolean)[0] || null;
				if (parsed.pathname === "/watch") return parsed.searchParams.get("v");
				if (parsed.pathname.startsWith("/shorts/") || parsed.pathname.startsWith("/embed/")) return parsed.pathname.split("/").filter(Boolean)[1] || null;
				return null;
			})();
			if (!videoId) {
				toast.error("This YouTube URL is not valid. Please use the Insert video URL button instead.");
				return;
			}
			insertHtmlAtCursor(`<figure class="my-8 w-full max-w-none"><div class="aspect-video w-full overflow-hidden rounded border border-gray-200 bg-black"><iframe src="${`https://www.youtube-nocookie.com/embed/${videoId}?rel=0`.replace(/"/g, "&quot;")}" title="YouTube video" class="h-full w-full" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen loading="lazy"></iframe></div></figure><p><br></p>`);
			toast.success("YouTube video embedded.");
			return;
		}
		toast.error("This post URL is not supported yet. Supported platforms: X / Twitter, Instagram, TikTok, Facebook, YouTube.");
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "overflow-hidden border border-gray-300 bg-white",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center gap-2 border-b border-gray-200 bg-gray-50 p-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ToolbarGroup, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToolbarButton, {
							label: "Bold",
							icon: Bold,
							onClick: () => run("bold")
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToolbarButton, {
							label: "Italic",
							icon: Italic,
							onClick: () => run("italic")
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToolbarButton, {
							label: "Underline",
							icon: Underline,
							onClick: () => run("underline")
						})
					] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ToolbarGroup, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToolbarButton, {
							label: "Left",
							icon: TextAlignStart,
							onClick: () => run("justifyLeft")
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToolbarButton, {
							label: "Center",
							icon: TextAlignCenter,
							onClick: () => run("justifyCenter")
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToolbarButton, {
							label: "Right",
							icon: TextAlignEnd,
							onClick: () => run("justifyRight")
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToolbarButton, {
							label: "Justify",
							icon: TextAlignJustify,
							onClick: () => run("justifyFull")
						})
					] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ToolbarGroup, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToolbarButton, {
						label: "Bullets",
						icon: List,
						onClick: () => run("insertUnorderedList")
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToolbarButton, {
						label: "Numbered",
						icon: ListOrdered,
						onClick: () => run("insertOrderedList")
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ToolbarGroup, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToolbarButton, {
						label: "Add link",
						icon: Link,
						onClick: insertLink
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToolbarButton, {
						label: "Remove link",
						icon: Unlink,
						onClick: removeLink
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ToolbarGroup, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToolbarButton, {
							label: "Insert HD image (in article)",
							icon: Image,
							onClick: insertImageInline
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToolbarButton, {
							label: "Insert video URL (YouTube/Vimeo)",
							icon: Video,
							onClick: insertVideoEmbed
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToolbarButton, {
							label: "Embed social post (X/Instagram/TikTok/Facebook)",
							icon: Share2,
							onClick: insertPostEmbed
						})
					] })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				ref: editorRef,
				contentEditable: true,
				suppressContentEditableWarning: true,
				onInput: syncValue,
				onBlur: syncValue,
				className: "min-h-[420px] w-full px-4 py-4 text-[15px] leading-7 outline-none"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "border-t border-gray-200 bg-gray-50 px-3 py-2 text-xs text-muted-foreground",
				children: "Tip: Select text and use Add link to insert hyperlinks. Use the Image button to upload files or paste a URL — HD images up to 2560px are preserved. Video embed supports YouTube and Vimeo. Use Embed social post to insert posts from X, Instagram, TikTok, and Facebook directly between paragraphs."
			})
		]
	});
}
function ToolbarGroup({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex flex-wrap items-center gap-1 rounded-md border border-gray-200 bg-white p-1",
		children
	});
}
function ToolbarButton({ label, icon: Icon, onClick }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		title: label,
		"aria-label": label,
		onMouseDown: (e) => e.preventDefault(),
		onClick,
		className: "flex h-9 w-9 items-center justify-center rounded border border-transparent bg-white text-black hover:border-gray-300 hover:bg-gray-50",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "h-4 w-4" })
	});
}
//#endregion
export { ArticleForm as t };
