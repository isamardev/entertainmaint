import { r as __toESM } from "../_runtime.mjs";
import { a as require_react, i as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { a as socialLinkLabels, i as saveAdminSettings, n as getAdminSettings, t as EMPTY_SOCIAL_LINKS } from "./settingsService-DMMu0PZz.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/admin.socials-CD6WMN7x.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function SocialLinksForm() {
	const [socials, setSocials] = (0, import_react.useState)(() => ({ ...EMPTY_SOCIAL_LINKS }));
	const [socialsInitial, setSocialsInitial] = (0, import_react.useState)(() => ({ ...EMPTY_SOCIAL_LINKS }));
	const [saving, setSaving] = (0, import_react.useState)(false);
	const [loading, setLoading] = (0, import_react.useState)(true);
	const [error, setError] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		let cancelled = false;
		(async () => {
			setLoading(true);
			setError(null);
			try {
				const data = await getAdminSettings();
				if (cancelled) return;
				setSocials(data.social_links);
				setSocialsInitial({ ...data.social_links });
			} catch (err) {
				if (cancelled) return;
				const raw = err?.message;
				if (!raw) setError("Failed to load social links. Please try again later.");
				else if (raw.includes("<") || raw.includes("DOCTYPE") || raw.startsWith("Unexpected token")) setError("Something went wrong. Please try again later.");
				else setError(raw.length > 240 ? raw.slice(0, 240) + "…" : raw);
			} finally {
				if (!cancelled) setLoading(false);
			}
		})();
		return () => {
			cancelled = true;
		};
	}, []);
	async function handleSave(e) {
		e.preventDefault();
		setError(null);
		setSaving(true);
		try {
			await saveAdminSettings({ social_links: socials });
			toast.success("Social media links saved successfully.");
			setSocialsInitial({ ...socials });
		} catch (err) {
			let msg = err?.message;
			if (!msg) msg = "Failed to save social links. Please try again later.";
			else if (msg.includes("<") || msg.includes("DOCTYPE")) msg = "Something went wrong. Please try again later.";
			else if (msg.length > 240) msg = msg.slice(0, 240) + "…";
			setError(msg);
			toast.error(msg);
		} finally {
			setSaving(false);
		}
	}
	const isDirty = JSON.stringify(socials) !== JSON.stringify(socialsInitial);
	const placeholderFor = {
		facebook: "https://www.facebook.com/YourPage",
		x: "https://x.com/YourHandle",
		instagram: "https://www.instagram.com/yourhandle/",
		youtube: "https://www.youtube.com/@YourChannel",
		tiktok: "https://www.tiktok.com/@yourhandle",
		whatsapp: "https://wa.me/923001234567",
		linkedin: "https://www.linkedin.com/in/yourprofile/",
		email: "hello@yourdomain.com",
		website: "https://yourdomain.com",
		threads: "https://www.threads.net/@yourhandle"
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		onSubmit: handleSave,
		className: "space-y-5 border border-gray-200 bg-gray-50 p-5 md:p-6",
		children: [
			loading && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "text-sm text-gray-500",
				children: "Loading current social links…"
			}),
			error && !loading && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "rounded border border-red-200 bg-red-50 px-3 py-2 text-xs text-red-700",
				children: error
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid gap-3 sm:grid-cols-2",
				children: socialLinkLabels.map((field) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "flex flex-col gap-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-xs font-black uppercase tracking-widest text-black",
						children: field.label
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "text",
						value: socials[field.key],
						onChange: (e) => setSocials((s) => ({
							...s,
							[field.key]: e.target.value
						})),
						placeholder: placeholderFor[field.key],
						className: "w-full border border-gray-300 bg-white px-3 py-2 outline-none focus:border-black",
						disabled: loading,
						autoComplete: "off"
					})]
				}, field.key))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col gap-2 pt-2 sm:flex-row sm:items-center sm:justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "text-xs text-gray-500",
					children: loading ? "Waiting for saved links…" : isDirty ? "You have unsaved changes." : "All links are saved and in sync."
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "submit",
					disabled: saving || loading || !isDirty,
					className: "px-6 py-2 font-black uppercase tracking-widest bg-black text-white hover:bg-gray-800 disabled:opacity-60 disabled:cursor-not-allowed",
					children: saving ? "Saving…" : "Save Social Links"
				})]
			})
		]
	}) });
}
function AdminSocials() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "display mb-2 text-xl font-black uppercase",
			children: "Social Media Links"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mb-6 text-sm text-gray-600",
			children: "Add or update the social media URLs that appear in the site Footer and other public locations. Only the links you fill in will be rendered — leave empty any platforms you don't use."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SocialLinksForm, {})
	] });
}
//#endregion
export { AdminSocials as component };
