import { i as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { g as Link } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/article._slug-bSVkwLXe.js
var import_jsx_runtime = require_jsx_runtime();
var SplitNotFoundComponent = () => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
	className: "p-8 text-center",
	children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "display mb-4 text-xl font-black",
		children: "Article not found"
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
		to: "/",
		className: "mt-4 inline-block yellow-bar px-4 py-2 font-bold uppercase tracking-widest",
		children: "Back home"
	})]
});
//#endregion
export { SplitNotFoundComponent as notFoundComponent };
