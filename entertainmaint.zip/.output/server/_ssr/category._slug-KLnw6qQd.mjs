import { M as notFound, m as createFileRoute, p as lazyRouteComponent } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as categoryService } from "./articleService-CLr-p8NN.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/category._slug-KLnw6qQd.js
var $$splitNotFoundComponentImporter = () => import("./category._slug-DxEsJ-oc.mjs");
var $$splitErrorComponentImporter = () => import("./category2._slug-CKMZ-kgP.mjs");
var $$splitComponentImporter = () => import("./category._slug-BYW21_-p.mjs");
var Route = createFileRoute("/category/$slug")({
	loader: async ({ params }) => {
		const cat = (await categoryService.list()).find((c) => c.slug === params.slug);
		if (!cat) throw notFound();
		return { category: cat };
	},
	head: ({ loaderData }) => ({
		meta: loaderData ? [{ title: `${loaderData.category.name} — Entertainment Trends` }, {
			name: "description",
			content: `Latest ${loaderData.category.name} news on Entertainment Trends.`
		}] : [{ title: "Category — Entertainment Trends" }],
		links: loaderData ? [{
			rel: "canonical",
			href: `/category/${loaderData.category.slug}`
		}] : []
	}),
	component: lazyRouteComponent($$splitComponentImporter, "component"),
	errorComponent: lazyRouteComponent($$splitErrorComponentImporter, "errorComponent"),
	notFoundComponent: lazyRouteComponent($$splitNotFoundComponentImporter, "notFoundComponent")
});
//#endregion
export { Route as t };
