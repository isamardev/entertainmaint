import { r as __toESM } from "../_runtime.mjs";
import { a as require_react, i as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { E as Facebook, _ as Mail, b as Linkedin, o as Twitter, t as Youtube, w as Instagram } from "../_libs/lucide-react.mjs";
import { r as getPublicSocialLinks } from "./settingsService-BFnovDaY.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/SocialFollowLinks-Ngoy-Hnm.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function mailtoOrDirect(email) {
	if (!email) return "";
	if (/^mailto:/i.test(email)) return email;
	return `mailto:${email}`;
}
function waOrDirect(whatsapp) {
	if (!whatsapp) return "";
	if (/^https?:\/\//i.test(whatsapp) || /^whatsapp:/i.test(whatsapp)) return whatsapp;
	const digits = whatsapp.replace(/[^\d]/g, "");
	if (digits) return `https://wa.me/${digits}`;
	return `https://${whatsapp.replace(/^[\/]+/, "")}`;
}
function resolveLink(key, value) {
	if (!value) return "";
	if (key === "email") return mailtoOrDirect(value);
	if (key === "whatsapp") return waOrDirect(value);
	if (/^(https?:|mailto:|tel:|whatsapp:)/i.test(value)) return value;
	if (value.startsWith("//")) return `https:${value}`;
	return `https://${value.replace(/^[\/]+/, "")}`;
}
function externalAttrs(url) {
	if (!url) return {};
	if (/^https?:\/\//i.test(url)) return {
		target: "_blank",
		rel: "noreferrer noopener nofollow"
	};
	return {};
}
function TikTok({ size = 16 }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
		xmlns: "http://www.w3.org/2000/svg",
		width: size,
		height: size,
		viewBox: "0 0 24 24",
		fill: "none",
		stroke: "currentColor",
		strokeWidth: "2",
		strokeLinecap: "round",
		strokeLinejoin: "round",
		"aria-hidden": "true",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M9 12a4 4 0 1 0 4 4V3a7 7 0 0 0 5 2.4 7 7 0 0 1-5 6.6" })
	});
}
function Threads({ size = 16 }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		xmlns: "http://www.w3.org/2000/svg",
		width: size,
		height: size,
		viewBox: "0 0 24 24",
		fill: "none",
		stroke: "currentColor",
		strokeWidth: "2",
		strokeLinecap: "round",
		strokeLinejoin: "round",
		"aria-hidden": "true",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M8 21c-4 0-5-3.2-5-9S4 3 8 3h8c4 0 5 3.2 5 9s-1 9-5 9-5-4-5-4 1 3 4 1 2-5-4-5-8 2-8 5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M13 8c3.5.5 4 3 4 4s-.5 3.5-4 4" })]
	});
}
function Globe({ size = 16 }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		xmlns: "http://www.w3.org/2000/svg",
		width: size,
		height: size,
		viewBox: "0 0 24 24",
		fill: "none",
		stroke: "currentColor",
		strokeWidth: "2",
		strokeLinecap: "round",
		strokeLinejoin: "round",
		"aria-hidden": "true",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "12",
				cy: "12",
				r: "9"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M3 12h18" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M12 3a14 14 0 0 1 0 18a14 14 0 0 1 0-18" })
		]
	});
}
function Whatsapp({ size = 16 }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		xmlns: "http://www.w3.org/2000/svg",
		width: size,
		height: size,
		viewBox: "0 0 24 24",
		fill: "none",
		stroke: "currentColor",
		strokeWidth: "2",
		strokeLinecap: "round",
		strokeLinejoin: "round",
		"aria-hidden": "true",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M21 11.5a9 9 0 0 1-13.2 8L3 21l1.5-4.8A9 9 0 1 1 21 11.5Z" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M8.5 9c.4-1.5 2-1.6 2.6-1.6.6 0 1.7 1 1.7 1.4 0 .4-.2.7-.6 1-.4.3-.5.5-.1 1 .4.5 1.4 2 2.5 3 1.1 1 1.3.7 2 .2.7-.5 1.3-.6 2.4-.2 1 2.8 1.5 3.5.8 5-.8 1.4-3.8 3.7-8.6.3-4.5-1.5-8.3-4.2-8.3Z" })]
	});
}
function SocialFollowLinks({ iconSize = 16, onlyNonEmpty = true, className = "flex gap-3", linkClassName = "rounded border border-border p-2 hover:border-yellow hover:text-yellow" }) {
	const [socials, setSocials] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		let cancelled = false;
		getPublicSocialLinks().then((s) => {
			if (cancelled) return;
			setSocials(s);
		}).catch(() => {
			if (!cancelled) setSocials({});
		});
		return () => {
			cancelled = true;
		};
	}, []);
	if (!socials) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className,
		"aria-hidden": "true"
	});
	const items = [
		{
			key: "facebook",
			label: "Facebook",
			node: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Facebook, { size: iconSize })
		},
		{
			key: "x",
			label: "X",
			node: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Twitter, { size: iconSize })
		},
		{
			key: "instagram",
			label: "Instagram",
			node: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Instagram, { size: iconSize })
		},
		{
			key: "youtube",
			label: "YouTube",
			node: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Youtube, { size: iconSize })
		},
		{
			key: "tiktok",
			label: "TikTok",
			node: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TikTok, { size: iconSize })
		},
		{
			key: "threads",
			label: "Threads",
			node: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Threads, { size: iconSize })
		},
		{
			key: "linkedin",
			label: "LinkedIn",
			node: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Linkedin, { size: iconSize })
		},
		{
			key: "whatsapp",
			label: "WhatsApp",
			node: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Whatsapp, { size: iconSize })
		},
		{
			key: "email",
			label: "Email",
			node: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mail, { size: iconSize })
		},
		{
			key: "website",
			label: "Website",
			node: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Globe, { size: iconSize })
		}
	];
	const visible = onlyNonEmpty ? items.filter((it) => Boolean(socials[it.key])) : items;
	if (visible.length === 0) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className,
		"aria-label": "Social links",
		children: visible.map((it) => {
			const raw = socials[it.key];
			const url = resolveLink(it.key, raw);
			if (!url) return null;
			return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
				href: url,
				"aria-label": it.label,
				title: it.label,
				className: linkClassName,
				...externalAttrs(url),
				children: it.node
			}, it.key);
		})
	});
}
//#endregion
export { SocialFollowLinks as t };
