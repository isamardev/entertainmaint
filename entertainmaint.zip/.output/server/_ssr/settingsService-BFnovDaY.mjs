import { n as safeFetchJson, t as getApiUrl } from "./safe-fetch-DWXDrtX7.mjs";
import { t as adminApiRequest } from "./adminAuthService-C0X5K4ik.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/settingsService-BFnovDaY.js
var EMPTY_SOCIAL_LINKS = {
	facebook: "",
	x: "",
	instagram: "",
	youtube: "",
	tiktok: "",
	whatsapp: "",
	linkedin: "",
	email: "",
	website: "",
	threads: ""
};
var socialLinkLabels = [
	{
		key: "facebook",
		label: "Facebook"
	},
	{
		key: "x",
		label: "X (Twitter)"
	},
	{
		key: "instagram",
		label: "Instagram"
	},
	{
		key: "youtube",
		label: "YouTube"
	},
	{
		key: "tiktok",
		label: "TikTok"
	},
	{
		key: "threads",
		label: "Threads"
	},
	{
		key: "linkedin",
		label: "LinkedIn"
	},
	{
		key: "whatsapp",
		label: "WhatsApp"
	},
	{
		key: "email",
		label: "Email"
	},
	{
		key: "website",
		label: "Website"
	}
];
async function getAdminSettings() {
	const res = await adminApiRequest(getApiUrl("/admin/settings"), { method: "GET" });
	const jsonSafe = await parseAdminJsonAuthenticated(await res.text(), res.headers.get("content-type"), res.status);
	return {
		social_links: {
			...EMPTY_SOCIAL_LINKS,
			...jsonSafe?.social_links || {}
		},
		site_meta: jsonSafe?.site_meta || {}
	};
}
async function saveAdminSettings(body) {
	const res = await adminApiRequest(getApiUrl("/admin/settings"), {
		method: "POST",
		headers: { "Content-Type": "application/json" },
		body: JSON.stringify(body)
	});
	return await parseAdminJsonAuthenticated(await res.text(), res.headers.get("content-type"), res.status) || { ok: true };
}
async function getPublicSocialLinks() {
	const r = await safeFetchJson(getApiUrl("/settings/socials"), { method: "GET" });
	if (!r.ok) return { ...EMPTY_SOCIAL_LINKS };
	return {
		...EMPTY_SOCIAL_LINKS,
		...r.data || {}
	};
}
async function parseAdminJsonAuthenticated(text, contentType, status) {
	const trimmed = text.trim();
	if (!trimmed) {
		if (status >= 200 && status < 300) return void 0;
		if (status === 401) throw new Error("Your session has expired. Please sign in again.");
		if (status === 403) throw new Error("You do not have permission to perform this action.");
		if (status === 404) throw new Error("The requested page or action is currently unavailable. Please try again later.");
		throw new Error("Something went wrong. Please try again later.");
	}
	if (trimmed.slice(0, 9).toUpperCase().startsWith("<!DOCTYPE") || /<html[\s>]/i.test(trimmed.slice(0, 512))) {
		if (status === 404) throw new Error("The requested page or action is currently unavailable. Please try again later.");
		throw new Error("Something went wrong. Please try again later.");
	}
	const isJsonLike = !!contentType && (/application\/json/i.test(contentType) || /application\/.*\+json/i.test(contentType) || /text\/json/i.test(contentType));
	let parsed = void 0;
	if (isJsonLike || /^[\[{]/.test(trimmed)) try {
		parsed = JSON.parse(trimmed);
	} catch {
		throw new Error("Something went wrong. Please try again later.");
	}
	else throw new Error("Something went wrong. Please try again later.");
	const payload = parsed;
	if (!(status >= 200 && status < 300)) {
		const errMsg = payload && typeof payload === "object" ? payload.error || payload.message : void 0;
		if (typeof errMsg === "string" && errMsg.trim()) throw new Error(errMsg.trim().replace(/[<>]/g, ""));
		if (status === 401) throw new Error("Your session has expired. Please sign in again.");
		if (status === 403) throw new Error("You do not have permission to perform this action.");
		throw new Error("Something went wrong. Please try again later.");
	}
	return parsed;
}
//#endregion
export { socialLinkLabels as a, saveAdminSettings as i, getAdminSettings as n, getPublicSocialLinks as r, EMPTY_SOCIAL_LINKS as t };
