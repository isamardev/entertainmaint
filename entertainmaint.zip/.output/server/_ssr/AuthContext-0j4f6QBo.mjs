import { r as __toESM } from "../_runtime.mjs";
import { t as supabase } from "./client-CFA_939g.mjs";
import { i as clearLegacyAdminStorage, n as adminAuthService, r as clearAdminToken } from "./adminAuthService-C0X5K4ik.mjs";
import { a as require_react, i as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/AuthContext-0j4f6QBo.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var AuthContext = (0, import_react.createContext)(null);
function AuthProvider({ children }) {
	const [session, setSession] = (0, import_react.useState)(null);
	const [roles, setRoles] = (0, import_react.useState)([]);
	const [loading, setLoading] = (0, import_react.useState)(true);
	const [isDevAdmin, setIsDevAdmin] = (0, import_react.useState)(false);
	const [devAdminEmail, setDevAdminEmail] = (0, import_react.useState)("");
	(0, import_react.useEffect)(() => {
		let active = true;
		async function initAuth() {
			clearLegacyAdminStorage();
			const adminSession = await adminAuthService.me();
			if (!active) return;
			if (adminSession.ok) {
				setIsDevAdmin(true);
				setDevAdminEmail(adminSession.email);
				setRoles(["admin", "super_admin"]);
				setLoading(false);
				return;
			}
			const { data: sub } = supabase.auth.onAuthStateChange((_event, s) => {
				setSession(s);
				if (s?.user) setTimeout(() => loadRoles(s.user.id), 0);
				else setRoles([]);
			});
			const { data } = await supabase.auth.getSession();
			if (!active) {
				sub.subscription.unsubscribe();
				return;
			}
			setSession(data.session);
			if (data.session?.user) await loadRoles(data.session.user.id);
			setLoading(false);
			return () => sub.subscription.unsubscribe();
		}
		const cleanupPromise = initAuth();
		return () => {
			active = false;
			cleanupPromise.then((cleanup) => cleanup?.());
		};
	}, []);
	async function loadRoles(uid) {
		const { data } = await supabase.from("user_roles").select("role").eq("user_id", uid);
		setRoles((data ?? []).map((r) => r.role));
	}
	const value = {
		user: isDevAdmin ? {
			id: "dev-admin-id",
			email: devAdminEmail
		} : session?.user ?? null,
		session: isDevAdmin ? {} : session,
		roles,
		loading,
		isAdmin: isDevAdmin || roles.includes("admin") || roles.includes("super_admin"),
		isSuperAdmin: isDevAdmin || roles.includes("super_admin"),
		async signIn(email, password, remember = true) {
			const result = await adminAuthService.login(email, password, remember);
			if (result.error) return { error: result.error };
			setIsDevAdmin(true);
			setDevAdminEmail(result.email ?? "");
			setRoles(["admin", "super_admin"]);
			setLoading(false);
			return {};
		},
		async signUp(email, password, displayName) {
			const { error } = await supabase.auth.signUp({
				email,
				password,
				options: {
					emailRedirectTo: `${window.location.origin}/`,
					data: displayName ? { display_name: displayName } : void 0
				}
			});
			return { error: error?.message };
		},
		async signOut() {
			if (isDevAdmin) {
				clearAdminToken();
				setIsDevAdmin(false);
				setDevAdminEmail("");
				setRoles([]);
				return;
			}
			await supabase.auth.signOut();
		},
		async updateEmail(newEmail, currentPassword) {
			if (!isDevAdmin) {
				const email = session?.user?.email;
				if (!email) return { error: "Not signed in." };
				const { error: signInError } = await supabase.auth.signInWithPassword({
					email,
					password: currentPassword
				});
				if (signInError) return { error: "Current password is incorrect." };
				const { error } = await supabase.auth.updateUser({ email: newEmail });
				return { error: error?.message };
			}
			const result = await adminAuthService.updateEmail(newEmail, currentPassword);
			if (result.error) return { error: result.error };
			if (result.email) setDevAdminEmail(result.email);
			return {};
		},
		async updatePassword(newPassword, currentPassword) {
			if (!isDevAdmin) {
				const email = session?.user?.email;
				if (!email) return { error: "Not signed in." };
				const { error: signInError } = await supabase.auth.signInWithPassword({
					email,
					password: currentPassword
				});
				if (signInError) return { error: "Current password is incorrect." };
				const { error } = await supabase.auth.updateUser({ password: newPassword });
				return { error: error?.message };
			}
			return { error: (await adminAuthService.updatePassword(newPassword, currentPassword)).error };
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuthContext.Provider, {
		value,
		children
	});
}
function useAuth() {
	const ctx = (0, import_react.useContext)(AuthContext);
	if (!ctx) throw new Error("useAuth must be used inside AuthProvider");
	return ctx;
}
//#endregion
export { useAuth as n, AuthProvider as t };
