import { r as __toESM } from "../_runtime.mjs";
import { a as require_react, i as require_jsx_runtime, r as useQueryClient, t as useQuery } from "../_libs/react+tanstack__react-query.mjs";
import { g as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as articleService } from "./articleService-UhMa44iK.mjs";
import { t as DeleteModal } from "./DeleteModal-DhnY0sX8.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { m as Pencil, s as Trash2 } from "../_libs/lucide-react.mjs";
import { t as Route } from "./admin.index-B6zmczWe.mjs";
import { t as fullDate } from "./format-BhnsDS-S.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/admin.index-D_kqBy9S.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function AdminArticles() {
	const qc = useQueryClient();
	const { status: statusFilter } = Route.useSearch();
	const { data = [], isLoading, error } = useQuery({
		queryKey: ["admin-articles"],
		queryFn: articleService.listAll
	});
	const [deleteModal, setDeleteModal] = (0, import_react.useState)({
		isOpen: false,
		id: 0,
		title: ""
	});
	async function handleDelete() {
		try {
			await articleService.remove(deleteModal.id);
			qc.invalidateQueries({ queryKey: ["admin-articles"] });
			toast.success("Article deleted successfully!");
		} catch (error) {
			console.error("Error deleting article:", error);
			toast.error(`Failed to delete article: ${error.message || "Unknown error"}`);
		} finally {
			setDeleteModal({
				isOpen: false,
				id: 0,
				title: ""
			});
		}
	}
	const filteredArticles = statusFilter === "all" ? data : data.filter((a) => a.status === statusFilter);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex h-full min-h-0 flex-col",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mb-4 shrink-0",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "display text-xl font-black uppercase",
					children: {
						all: "All Articles",
						published: "Published Articles",
						draft: "Draft Articles",
						archived: "Archived Articles"
					}[statusFilter]
				})
			}),
			isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "text-sm text-black",
				children: "Loading articles…"
			}) : error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "rounded-lg border border-red-200 bg-red-50 p-5",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-start justify-between gap-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "text-sm font-semibold text-red-800",
							children: "Unable to load articles"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-sm text-red-700",
							children: (() => {
								const raw = error?.message;
								if (!raw) return "Please refresh the page and try again.";
								if (raw.includes("<") || raw.includes("DOCTYPE") || raw.startsWith("Unexpected token")) return "Something went wrong. Please try again later.";
								if (raw.length > 220) return raw.slice(0, 220) + "…";
								return raw;
							})()
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => qc.invalidateQueries({ queryKey: ["admin-articles"] }),
						className: "shrink-0 rounded-md border border-red-300 bg-white px-3 py-1.5 text-xs font-semibold uppercase tracking-wider text-red-700 hover:bg-red-100",
						children: "Retry"
					})]
				})
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "min-h-0 flex-1 overflow-auto border border-gray-200",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "min-w-[840px]",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
						className: "w-full text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
							className: "bg-gray-50 text-left",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "p-3 text-xs font-black uppercase tracking-widest text-black",
									children: "Title"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "p-3 text-xs font-black uppercase tracking-widest text-black",
									children: "Category"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "p-3 text-xs font-black uppercase tracking-widest text-black",
									children: "Status"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "p-3 text-xs font-black uppercase tracking-widest text-black",
									children: "Updated"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { className: "p-3" })
							] })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tbody", { children: [filteredArticles.map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
							className: "border-t border-gray-200",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "p-3 font-semibold",
									children: a.title
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "p-3 text-black",
									children: a.category?.name ?? "—"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "p-3",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: `px-2 py-0.5 text-[0.65rem] font-black uppercase tracking-widest ${a.status === "published" ? "bg-black text-white" : "border border-gray-300 text-black"}`,
										children: a.status
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "p-3 text-xs text-black",
									children: fullDate(a.updated_at)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
									className: "p-3 text-right flex items-center justify-end gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
										to: "/admin/edit/$id",
										params: { id: a.id },
										className: "p-1 text-black hover:text-gray-700",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pencil, { size: 18 })
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										onClick: () => setDeleteModal({
											isOpen: true,
											id: a.id,
											title: a.title
										}),
										className: "p-1 text-red-600 hover:text-red-800",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { size: 18 })
									})]
								})
							]
						}, a.id)), filteredArticles.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
							colSpan: 5,
							className: "p-8 text-center text-black",
							children: [
								"No ",
								statusFilter,
								" articles yet."
							]
						}) })] })]
					})
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DeleteModal, {
				isOpen: deleteModal.isOpen,
				title: "Delete Article",
				message: `Are you sure you want to delete "${deleteModal.title}"?`,
				onConfirm: handleDelete,
				onCancel: () => setDeleteModal({
					isOpen: false,
					id: 0,
					title: ""
				})
			})
		]
	});
}
//#endregion
export { AdminArticles as component };
