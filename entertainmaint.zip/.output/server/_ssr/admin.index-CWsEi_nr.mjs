import { m as createFileRoute, p as lazyRouteComponent } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as objectType, t as enumType } from "../_libs/zod.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/admin.index-CWsEi_nr.js
var $$splitComponentImporter = () => import("./admin.index-Enl_TDB0.mjs");
var adminArticlesSearchSchema = objectType({ status: enumType([
	"all",
	"draft",
	"published",
	"archived"
]).optional().default("all") });
var Route = createFileRoute("/admin/")({
	validateSearch: (s) => adminArticlesSearchSchema.parse(s),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
