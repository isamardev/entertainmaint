import { i as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/category._slug-DxEsJ-oc.js
var import_jsx_runtime = require_jsx_runtime();
var SplitNotFoundComponent = () => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
	className: "p-8 text-center",
	children: "Category not found."
});
//#endregion
export { SplitNotFoundComponent as notFoundComponent };
