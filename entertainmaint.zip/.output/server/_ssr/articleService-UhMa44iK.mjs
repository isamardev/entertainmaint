import { n as safeFetchJson, t as getApiUrl } from "./safe-fetch-DWXDrtX7.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/articleService-UhMa44iK.js
var articleService = {
	async listPublished(opts = {}) {
		try {
			const params = new URLSearchParams();
			if (opts.limit) params.set("limit", opts.limit.toString());
			if (opts.offset) params.set("offset", opts.offset.toString());
			const result = await safeFetchJson(getApiUrl(`/articles/published?${params}`));
			if (!result.ok) return {
				data: [],
				count: 0
			};
			let data = Array.isArray(result.data) ? result.data : [];
			if (opts.categorySlug) data = data.filter((a) => a.category?.slug === opts.categorySlug);
			return {
				data,
				count: data.length
			};
		} catch {
			return {
				data: [],
				count: 0
			};
		}
	},
	async getBySlug(slug) {
		try {
			const result = await safeFetchJson(getApiUrl(`/articles/slug/${slug}`));
			return result.ok ? result.data : null;
		} catch {
			return null;
		}
	},
	async listBreaking() {
		try {
			const result = await safeFetchJson(getApiUrl("/articles/published"));
			if (!result.ok) return [];
			return (Array.isArray(result.data) ? result.data : []).filter((a) => a.is_breaking).slice(0, 6);
		} catch {
			return [];
		}
	},
	async listTrending(limit = 6) {
		try {
			const result = await safeFetchJson(getApiUrl("/articles/published"));
			if (!result.ok) return [];
			const data = Array.isArray(result.data) ? result.data : [];
			const seenSlugs = /* @__PURE__ */ new Set();
			return data.slice().sort((a, b) => {
				const aTime = a.published_at ? new Date(a.published_at).getTime() : new Date(a.created_at).getTime();
				const bTime = b.published_at ? new Date(b.published_at).getTime() : new Date(b.created_at).getTime();
				if (bTime !== aTime) return bTime - aTime;
				return (b.view_count ?? 0) - (a.view_count ?? 0);
			}).filter((a) => {
				const key = (a.slug || `${a.id}`).toLowerCase().trim();
				if (seenSlugs.has(key)) return false;
				seenSlugs.add(key);
				return true;
			}).slice(0, limit);
		} catch {
			return [];
		}
	},
	async search(q) {
		try {
			const term = q.trim().toLowerCase();
			if (!term) return [];
			const result = await safeFetchJson(getApiUrl("/articles/published"));
			if (!result.ok) return [];
			return (Array.isArray(result.data) ? result.data : []).filter((a) => a.title.toLowerCase().includes(term) || a.dek?.toLowerCase().includes(term));
		} catch {
			return [];
		}
	},
	async related(article, limit = 4) {
		try {
			if (!article.category_id) return [];
			const result = await safeFetchJson(getApiUrl("/articles/published"));
			if (!result.ok) return [];
			return (Array.isArray(result.data) ? result.data : []).filter((a) => a.category_id === article.category_id && a.id !== article.id).slice(0, limit);
		} catch {
			return [];
		}
	},
	async listAll() {
		const result = await safeFetchJson(getApiUrl("/articles?includeCategory=true"));
		if (!result.ok) throw new Error(result.error);
		return Array.isArray(result.data) ? result.data : [];
	},
	async create(input) {
		const payload = {
			title: input.title || "",
			slug: input.slug || "",
			dek: input.dek || null,
			body: input.body || "",
			category_id: input.category_id || null,
			author_id: input.author_id || null,
			status: input.status || "draft",
			is_breaking: input.is_breaking || false,
			is_featured: input.is_featured || false,
			view_count: input.view_count || 0,
			published_at: input.published_at || null,
			hero_image_hd: input.hero_image_hd || null,
			hero_image_lq: input.hero_image_lq || null,
			hero_caption: input.hero_caption || null,
			embed_url: input.embed_url || null
		};
		const result = await safeFetchJson(getApiUrl("/articles"), {
			method: "POST",
			headers: { "Content-Type": "application/json" },
			body: JSON.stringify(payload)
		});
		if (!result.ok) throw new Error(result.error);
		return result.data;
	},
	async update(id, input) {
		const payload = { ...input };
		delete payload.created_at;
		delete payload.updated_at;
		delete payload.id;
		const result = await safeFetchJson(getApiUrl(`/articles/${id}`), {
			method: "PUT",
			headers: { "Content-Type": "application/json" },
			body: JSON.stringify(payload)
		});
		if (!result.ok) throw new Error(result.error);
		return result.data;
	},
	async remove(id) {
		const result = await safeFetchJson(getApiUrl(`/articles/${id}`), { method: "DELETE" });
		if (!result.ok) throw new Error(result.error);
	},
	async delete(id) {
		return this.remove(id);
	}
};
var categoryService = {
	async list() {
		try {
			const result = await safeFetchJson(getApiUrl("/categories"), { cache: "no-store" });
			if (!result.ok) return [];
			return Array.isArray(result.data) ? result.data : [];
		} catch {
			return [];
		}
	},
	async create(input) {
		const result = await safeFetchJson(getApiUrl("/categories"), {
			method: "POST",
			headers: { "Content-Type": "application/json" },
			cache: "no-store",
			body: JSON.stringify({
				...input,
				created_at: (/* @__PURE__ */ new Date()).toISOString()
			})
		});
		if (!result.ok) throw new Error(result.error);
		return result.data;
	},
	async update(id, input) {
		const result = await safeFetchJson(getApiUrl(`/categories/${id}`), {
			method: "PUT",
			headers: { "Content-Type": "application/json" },
			body: JSON.stringify({ ...input })
		});
		if (!result.ok) throw new Error(result.error);
		return result.data;
	},
	async remove(id) {
		const result = await safeFetchJson(getApiUrl(`/categories/${id}`), { method: "DELETE" });
		if (!result.ok) throw new Error(result.error);
	},
	async delete(id) {
		return this.remove(id);
	}
};
//#endregion
export { categoryService as n, articleService as t };
