import { r as __toESM } from "../_runtime.mjs";
import { a as require_react, i as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { n as useAuth } from "./AuthContext-0j4f6QBo.mjs";
import { f as Outlet, v as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as AdminLoginForm } from "./AdminLoginForm-CUEkuYXL.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/admin-D95j5GrA.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function AdminLayout() {
	const { user, loading, isAdmin } = useAuth();
	const navigate = useNavigate();
	(0, import_react.useEffect)(() => {
		if (loading) return;
		if (user && !isAdmin) navigate({
			to: "/",
			replace: true
		});
	}, [
		user,
		loading,
		isAdmin,
		navigate
	]);
	if (loading) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "p-16 text-center text-black",
		children: "Checking access…"
	});
	if (!user) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AdminLoginForm, {
		redirectTo: "/admin",
		showBackLink: false
	});
	if (!isAdmin) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "p-16 text-center text-black",
		children: "Checking access…"
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-7xl px-0 py-4 md:px-4 md:py-8",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-6 border-b-4 border-black pb-4 md:mb-8",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "text-xs font-black uppercase tracking-widest text-black",
				children: "Entertainment Trends"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "display text-2xl font-black uppercase md:text-3xl",
				children: "Admin Dashboard"
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {})]
	});
}
//#endregion
export { AdminLayout as component };
