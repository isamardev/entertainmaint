import { i as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/DeleteModal-DhnY0sX8.js
var import_jsx_runtime = require_jsx_runtime();
function DeleteModal({ isOpen, title, message, onConfirm, onCancel }) {
	if (!isOpen) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "fixed inset-0 z-50 flex items-center justify-center bg-black/60",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "bg-white rounded-lg shadow-xl max-w-md w-full mx-4 p-6",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "text-xl font-black uppercase mb-2",
					children: title
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-gray-600 mb-6",
					children: message
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex gap-4 justify-end",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: onCancel,
						className: "px-4 py-2 border border-gray-300 text-gray-700 font-semibold uppercase tracking-widest hover:bg-gray-100",
						children: "Cancel"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: onConfirm,
						className: "px-4 py-2 bg-red-600 text-white font-semibold uppercase tracking-widest hover:bg-red-700",
						children: "Delete"
					})]
				})
			]
		})
	});
}
//#endregion
export { DeleteModal as t };
