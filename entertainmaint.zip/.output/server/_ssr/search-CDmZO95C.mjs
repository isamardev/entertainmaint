import { r as __toESM } from "../_runtime.mjs";
import { a as require_react, i as require_jsx_runtime, t as useQuery } from "../_libs/react+tanstack__react-query.mjs";
import { t as articleService } from "./articleService-CLr-p8NN.mjs";
import { t as ArticleCard } from "./ArticleCard-BgZT1eXg.mjs";
import { t as Route } from "./search-yMLF2aks.mjs";
import { t as GridSkeleton } from "./Skeleton-CGTHVyfA.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/search-CDmZO95C.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function SearchPage() {
	const { q: initial } = Route.useSearch();
	const navigate = Route.useNavigate();
	const [q, setQ] = (0, import_react.useState)(initial);
	const term = initial.trim();
	const { data = [], isLoading } = useQuery({
		queryKey: ["search", term],
		queryFn: () => articleService.search(term),
		enabled: !!term
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-5xl px-4 py-10",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-8",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "eyebrow",
					children: "Search"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "display text-4xl font-black uppercase md:text-5xl",
					children: "Find a story"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				onSubmit: (e) => {
					e.preventDefault();
					navigate({ search: { q } });
				},
				className: "mb-8 flex gap-2 border-b-2 border-yellow pb-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					value: q,
					onChange: (e) => setQ(e.target.value),
					placeholder: "Search Entertainment Trends…",
					className: "flex-1 bg-transparent text-xl outline-none placeholder:text-muted-foreground"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					className: "yellow-bar px-4 py-2 text-sm font-black uppercase tracking-widest",
					children: "Search"
				})]
			}),
			!term && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-muted-foreground",
				children: "Enter a search term to see stories."
			}),
			term && isLoading && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GridSkeleton, {}),
			term && !isLoading && data.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "border border-border bg-surface p-10 text-center text-muted-foreground",
				children: [
					"No matches for “",
					term,
					"”."
				]
			}),
			term && !isLoading && data.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "meta mb-4",
				children: [
					data.length,
					" result",
					data.length === 1 ? "" : "s",
					" for “",
					term,
					"”"
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid gap-8 sm:grid-cols-2 lg:grid-cols-3",
				children: data.map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArticleCard, { article: a }, a.id))
			})] })
		]
	});
}
//#endregion
export { SearchPage as component };
