import { r as __toESM } from "../_runtime.mjs";
import { a as require_react, i as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { n as useAuth } from "./AuthContext-DIfp1ZVF.mjs";
import { M as Eye, N as EyeOff } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/admin.settings-CjlHwYzA.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function AdminSettingsForm() {
	const { user, updateEmail, updatePassword } = useAuth();
	const [currentPassword, setCurrentPassword] = (0, import_react.useState)("");
	const [newEmail, setNewEmail] = (0, import_react.useState)(user?.email ?? "");
	const [newPassword, setNewPassword] = (0, import_react.useState)("");
	const [confirmPassword, setConfirmPassword] = (0, import_react.useState)("");
	const [showCurrentPasswordEmail, setShowCurrentPasswordEmail] = (0, import_react.useState)(false);
	const [showCurrentPasswordChange, setShowCurrentPasswordChange] = (0, import_react.useState)(false);
	const [showNewPassword, setShowNewPassword] = (0, import_react.useState)(false);
	const [showConfirmPassword, setShowConfirmPassword] = (0, import_react.useState)(false);
	const [emailBusy, setEmailBusy] = (0, import_react.useState)(false);
	const [passwordBusy, setPasswordBusy] = (0, import_react.useState)(false);
	const [emailErr, setEmailErr] = (0, import_react.useState)(null);
	const [passwordErr, setPasswordErr] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		setNewEmail(user?.email ?? "");
	}, [user?.email]);
	async function handleEmailChange(e) {
		e.preventDefault();
		setEmailErr(null);
		if (!currentPassword) {
			setEmailErr("Current password is required.");
			return;
		}
		if (!newEmail.trim()) {
			setEmailErr("New email is required.");
			return;
		}
		if (newEmail === user?.email) {
			setEmailErr("New email must be different from the current one.");
			return;
		}
		setEmailBusy(true);
		const result = await updateEmail(newEmail.trim(), currentPassword);
		setEmailBusy(false);
		if (result.error) {
			setEmailErr(result.error);
			toast.error("Failed to update username.");
		} else {
			toast.success("Username updated successfully.");
			setCurrentPassword("");
		}
	}
	async function handlePasswordChange(e) {
		e.preventDefault();
		setPasswordErr(null);
		if (!currentPassword) {
			setPasswordErr("Current password is required.");
			return;
		}
		if (newPassword.length < 6) {
			setPasswordErr("New password must be at least 6 characters.");
			return;
		}
		if (newPassword !== confirmPassword) {
			setPasswordErr("New passwords do not match.");
			return;
		}
		setPasswordBusy(true);
		const result = await updatePassword(newPassword, currentPassword);
		setPasswordBusy(false);
		if (result.error) {
			setPasswordErr(result.error);
			toast.error("Failed to update password.");
		} else {
			toast.success("Password updated successfully.");
			setCurrentPassword("");
			setNewPassword("");
			setConfirmPassword("");
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mb-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "eyebrow",
				children: "Account Settings"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "display text-2xl font-black uppercase text-black",
				children: "Account Security"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-gray-600",
				children: "Update your admin username (email) or password. Your current password is required for both actions as a security measure."
			})
		]
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-8 lg:grid-cols-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			onSubmit: handleEmailChange,
			className: "space-y-3 border border-gray-200 bg-gray-50 p-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "text-xs font-black uppercase tracking-widest text-black",
					children: "Change Username"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-xs text-gray-600",
					children: ["Current: ", user?.email]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: showCurrentPasswordEmail ? "text" : "password",
						required: true,
						value: currentPassword,
						onChange: (e) => setCurrentPassword(e.target.value),
						placeholder: "Current password",
						className: "w-full border border-gray-300 bg-white px-3 py-2 pr-10 outline-none focus:border-black"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => setShowCurrentPasswordEmail((prev) => !prev),
						"aria-label": showCurrentPasswordEmail ? "Hide password" : "Show password",
						className: "absolute right-2.5 top-1/2 -translate-y-1/2 text-gray-500 hover:text-black transition-colors p-1",
						children: showCurrentPasswordEmail ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EyeOff, { size: 18 }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eye, { size: 18 })
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					type: "email",
					required: true,
					value: newEmail,
					onChange: (e) => setNewEmail(e.target.value),
					placeholder: "New email / username",
					className: "w-full border border-gray-300 bg-white px-3 py-2 outline-none focus:border-black"
				}),
				emailErr && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "text-xs text-red-600",
					children: emailErr
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "submit",
					disabled: emailBusy,
					className: "w-full py-2 font-black uppercase tracking-widest bg-black text-white hover:bg-gray-800 disabled:opacity-60",
					children: emailBusy ? "Updating…" : "Update Username"
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			onSubmit: handlePasswordChange,
			className: "space-y-3 border border-gray-200 bg-gray-50 p-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "text-xs font-black uppercase tracking-widest text-black",
					children: "Change Password"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: showCurrentPasswordChange ? "text" : "password",
						required: true,
						value: currentPassword,
						onChange: (e) => setCurrentPassword(e.target.value),
						placeholder: "Current password",
						className: "w-full border border-gray-300 bg-white px-3 py-2 pr-10 outline-none focus:border-black"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => setShowCurrentPasswordChange((prev) => !prev),
						"aria-label": showCurrentPasswordChange ? "Hide password" : "Show password",
						className: "absolute right-2.5 top-1/2 -translate-y-1/2 text-gray-500 hover:text-black transition-colors p-1",
						children: showCurrentPasswordChange ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EyeOff, { size: 18 }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eye, { size: 18 })
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: showNewPassword ? "text" : "password",
						required: true,
						minLength: 6,
						value: newPassword,
						onChange: (e) => setNewPassword(e.target.value),
						placeholder: "New password",
						className: "w-full border border-gray-300 bg-white px-3 py-2 pr-10 outline-none focus:border-black"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => setShowNewPassword((prev) => !prev),
						"aria-label": showNewPassword ? "Hide password" : "Show password",
						className: "absolute right-2.5 top-1/2 -translate-y-1/2 text-gray-500 hover:text-black transition-colors p-1",
						children: showNewPassword ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EyeOff, { size: 18 }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eye, { size: 18 })
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: showConfirmPassword ? "text" : "password",
						required: true,
						minLength: 6,
						value: confirmPassword,
						onChange: (e) => setConfirmPassword(e.target.value),
						placeholder: "Confirm new password",
						className: "w-full border border-gray-300 bg-white px-3 py-2 pr-10 outline-none focus:border-black"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => setShowConfirmPassword((prev) => !prev),
						"aria-label": showConfirmPassword ? "Hide password" : "Show password",
						className: "absolute right-2.5 top-1/2 -translate-y-1/2 text-gray-500 hover:text-black transition-colors p-1",
						children: showConfirmPassword ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EyeOff, { size: 18 }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eye, { size: 18 })
					})]
				}),
				passwordErr && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "text-xs text-red-600",
					children: passwordErr
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "submit",
					disabled: passwordBusy,
					className: "w-full py-2 font-black uppercase tracking-widest bg-black text-white hover:bg-gray-800 disabled:opacity-60",
					children: passwordBusy ? "Updating…" : "Update Password"
				})
			]
		})]
	})] });
}
function AdminSettings() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "display mb-2 text-xl font-black uppercase",
			children: "Settings"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mb-6 text-sm text-gray-600",
			children: "Manage your admin account credentials. Use this page to change your username (email) or password. Your current password is required for security-sensitive changes."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AdminSettingsForm, {})
	] });
}
//#endregion
export { AdminSettings as component };
