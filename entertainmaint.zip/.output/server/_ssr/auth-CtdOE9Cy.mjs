import { r as __toESM } from "../_runtime.mjs";
import { a as require_react } from "../_libs/react+tanstack__react-query.mjs";
import { _ as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/auth-CtdOE9Cy.js
var import_react = /* @__PURE__ */ __toESM(require_react());
function AuthRedirect() {
	const navigate = useNavigate();
	(0, import_react.useEffect)(() => {
		navigate({
			to: "/admin/login",
			replace: true
		});
	}, [navigate]);
	return null;
}
//#endregion
export { AuthRedirect as component };
