//#region node_modules/.nitro/vite/services/ssr/assets/safe-fetch-Dfsgx9OJ.js
var DEFAULT_BACKEND_API = "/api";
var PROD_BACKEND_ORIGIN = "https://aliceblue-goose-490382.hostingersite.com";
var normalizedProdBase = DEFAULT_BACKEND_API;
var normalizedDevBase = DEFAULT_BACKEND_API;
var isDev = Boolean(false);
var IS_PROD_BUILD = Boolean(true);
var API_BASE = isDev ? normalizedDevBase : normalizedProdBase;
function looksLikeOrigin(value) {
	return /^https?:\/\//i.test(value);
}
function getApiUrl(path) {
	const base = API_BASE || DEFAULT_BACKEND_API;
	const normalizedPath = path.startsWith("/") ? path : `/${path}`;
	if (typeof window === "undefined") {
		if (looksLikeOrigin(base)) return `${base}${normalizedPath}`;
		return `${isDev || !IS_PROD_BUILD ? "http://localhost:3000" : PROD_BACKEND_ORIGIN}${base}${normalizedPath}`;
	}
	if (looksLikeOrigin(base)) return `${base}${normalizedPath}`;
	return `${base}${normalizedPath}`;
}
var HTTP_DESCRIPTIONS = {
	0: "No response from server (check your network connection).",
	400: "The request contained invalid data.",
	401: "Your session has expired. Please sign in again.",
	403: "You do not have permission to perform this action.",
	404: "The requested resource was not found.",
	405: "The server rejected this request method.",
	408: "The request timed out. Please try again.",
	409: "A conflict occurred with the current state of the resource.",
	413: "The upload is too large. Please try a smaller file.",
	415: "The request format is not supported.",
	422: "Some fields were invalid. Please review and try again.",
	429: "Too many requests. Please wait a moment and try again.",
	500: "The server encountered an unexpected error.",
	502: "The server is temporarily unavailable (bad gateway).",
	503: "The service is temporarily down for maintenance.",
	504: "The service took too long to respond. Please try again."
};
function describeHttpStatus(status, statusText) {
	if (HTTP_DESCRIPTIONS[status]) return HTTP_DESCRIPTIONS[status];
	if (statusText && /^[a-zA-Z0-9\s,.'-]{2,160}$/.test(statusText)) return `${statusText.trim()} (${status}).`;
	return `Request failed with status ${status}.`;
}
function extractJsonError(payload) {
	if (!payload) return null;
	if (typeof payload === "string") {
		if (!payload.trim()) return null;
		const s = payload.trim().replace(/[<>]/g, "");
		return s.length <= 220 ? s : s.slice(0, 220) + "…";
	}
	if (typeof payload === "object") {
		const p = payload;
		const candidates = [
			p.error,
			p.message,
			p.errorMessage,
			p.detail,
			p.msg,
			p.reason
		];
		for (const c of candidates) if (typeof c === "string" && c.trim()) {
			const s = c.trim().replace(/[<>]/g, "");
			return s.length <= 220 ? s : s.slice(0, 220) + "…";
		}
		if (Array.isArray(p.errors) && p.errors.length) {
			const first = p.errors[0];
			if (typeof first === "string" && first.trim()) return first.trim();
			if (first && typeof first === "object") {
				const msg = first.message;
				if (typeof msg === "string" && msg.trim()) return msg.trim();
			}
		}
	}
	return null;
}
function extractHtmlBodyTitle(html) {
	const titleMatch = html.match(/<title[^>]*>([^<]{1,200})<\/title>/i);
	if (titleMatch && titleMatch[1]) {
		const clean = titleMatch[1].trim().replace(/\s+/g, " ");
		return clean.length <= 200 ? clean : clean.slice(0, 200) + "…";
	}
	return null;
}
function contentTypeIsJsonLike(ct) {
	if (!ct) return false;
	const low = ct.toLowerCase();
	return low.includes("application/json") || low.includes("application/vnd.api+json") || low.includes("application/ld+json") || low.includes("application/problem+json") || low.includes("text/json");
}
/**
* Drop-in safer replacement for the pattern:
*   const res = await fetch(url); const data = await res.json();
*
* Guarantees:
*  - Never throws a SyntaxError for non-JSON bodies.
*  - Responses that look like a hosting-provider HTML 404 page
*    produce a professional English error message (no raw HTML shown).
*  - Error messages are sanitized and short: safe to render anywhere on
*    the frontend (toasts, form error rows etc.).
*/
async function safeFetchJson(input, init = {}) {
	const { tolerateEmptyBody = true, ...rest } = init;
	let res;
	try {
		res = await fetch(input, rest);
	} catch (err) {
		const baseMessage = err instanceof TypeError && /failed to fetch|networkerror|load failed/i.test(err.message) ? "Unable to reach the server. Please check your internet connection and try again." : "Network error. Please try again.";
		const stackMsg = err instanceof Error && err.message && !/<|DOCTYPE/i.test(err.message) ? ` (${err.message})` : "";
		const message = stackMsg && !/CORS|Failed to fetch/i.test(baseMessage + stackMsg) ? baseMessage : baseMessage;
		return {
			ok: false,
			status: 0,
			statusText: "Network Error",
			headers: new Headers(),
			error: message + (stackMsg && message === baseMessage && !/<|DOCTYPE/.test(stackMsg) ? "" : ""),
			contentType: null
		};
	}
	const status = res.status;
	const statusText = res.statusText || "";
	const headers = res.headers;
	const contentType = headers.get("content-type");
	const trimmed = (await res.text().catch(() => "")).trim();
	if (!trimmed) {
		if (res.ok) {
			if (status === 204 || tolerateEmptyBody) return {
				ok: true,
				status,
				statusText,
				headers,
				data: tolerateEmptyBody ? {} : void 0
			};
			return {
				ok: false,
				status,
				statusText,
				headers,
				error: "Something went wrong. Please try again later.",
				contentType
			};
		}
		return {
			ok: false,
			status,
			statusText,
			headers,
			error: describeHttpStatus(status, statusText),
			contentType
		};
	}
	if (trimmed.slice(0, 9).toUpperCase().startsWith("<!DOCTYPE") || /<html[\s>]/i.test(trimmed.slice(0, 512))) {
		const generic = describeHttpStatus(status, statusText);
		const title = extractHtmlBodyTitle(trimmed);
		let suffix = "";
		if (title && !/<!DOCTYPE|<html/i.test(title) && title !== generic) suffix = title.match(/404|500|502|503|forbidden|not found|error/i) ? ` — ${title.replace(/\s*[–|-]\s*(Hostinger|Vercel|Apache|Nginx|LiteSpeed|cPanel|Cloudflare)\s*$/i, "")}` : "";
		return {
			ok: false,
			status,
			statusText,
			headers,
			error: generic + suffix,
			contentType
		};
	}
	const isJsonLike = contentTypeIsJsonLike(contentType);
	let parsed = void 0;
	let parseFailed = false;
	if (isJsonLike || /^[\[{]/.test(trimmed)) try {
		parsed = JSON.parse(trimmed);
	} catch {
		parsed = void 0;
		parseFailed = true;
	}
	if (!isJsonLike && parsed === void 0 && !parseFailed) {
		if (res.ok) return {
			ok: false,
			status,
			statusText,
			headers,
			error: "Something went wrong. Please try again later.",
			contentType
		};
		return {
			ok: false,
			status,
			statusText,
			headers,
			error: describeHttpStatus(status, statusText),
			contentType
		};
	}
	if (parseFailed) return {
		ok: false,
		status,
		statusText,
		headers,
		error: res.ok ? "Something went wrong. Please try again later." : describeHttpStatus(status, statusText),
		contentType
	};
	const payload = parsed;
	if (res.ok) return {
		ok: true,
		status,
		statusText,
		headers,
		data: payload
	};
	return {
		ok: false,
		status,
		statusText,
		headers,
		error: extractJsonError(payload) || describeHttpStatus(status, statusText),
		rawPayload: payload,
		contentType
	};
}
//#endregion
export { safeFetchJson as n, getApiUrl as t };
