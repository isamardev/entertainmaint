import { n as safeFetchJson, t as getApiUrl } from "./safe-fetch-Dfsgx9OJ.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/articleService-CLr-p8NN.js
var SEED_CATEGORIES = [
	{
		id: 1,
		name: "Celebrity",
		slug: "celebrity",
		description: "Celebrity news and gossip",
		sort_order: 1,
		created_at: "2026-07-01T00:00:00Z"
	},
	{
		id: 2,
		name: "Movies & TV",
		slug: "movies-tv",
		description: "Movie releases, reviews, and TV shows",
		sort_order: 2,
		created_at: "2026-07-01T00:00:00Z"
	},
	{
		id: 3,
		name: "Music",
		slug: "music",
		description: "Music charts, tours, and new tracks",
		sort_order: 3,
		created_at: "2026-07-01T00:00:00Z"
	},
	{
		id: 4,
		name: "Style",
		slug: "style",
		description: "Fashion, beauty, and red carpet looks",
		sort_order: 4,
		created_at: "2026-07-01T00:00:00Z"
	},
	{
		id: 5,
		name: "Royals",
		slug: "royals",
		description: "Royal family updates and appearances",
		sort_order: 5,
		created_at: "2026-07-01T00:00:00Z"
	},
	{
		id: 6,
		name: "Sports",
		slug: "sports",
		description: "Athletes, championships, and sports culture",
		sort_order: 6,
		created_at: "2026-07-01T00:00:00Z"
	}
];
var SEED_ARTICLES = [
	{
		id: 1,
		slug: "celebrity-spotlight-a-list-event",
		title: "A-Listers Turn Out For Star-Studded Premiere",
		dek: "Hollywood's biggest names walked the red carpet last night for the year's most anticipated film premiere.",
		body: `<p>Hollywood Boulevard was abuzz last night as A-list celebrities arrived for the world premiere of the summer's biggest blockbuster. Stars arrived in style, showcasing the latest fashion trends on the red carpet.</p><p>The film, which has been in production for over two years, is already generating massive buzz among critics and fans alike. With an all-star cast and a compelling storyline, it's set to be one of the biggest hits of the year.</p><p>After the screening, the cast and crew attended an exclusive after-party where they celebrated the successful premiere.</p>`,
		hero_image_hd: "https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=1200&auto=format&fit=crop&q=80",
		hero_image_lq: "https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=600&auto=format&fit=crop&q=80",
		hero_caption: "Stars arriving on the red carpet last night",
		embed_url: null,
		category_id: 1,
		author_id: null,
		status: "published",
		is_breaking: true,
		is_featured: true,
		view_count: 14200,
		published_at: (/* @__PURE__ */ new Date(Date.now() - 2 * 3600 * 1e3)).toISOString(),
		created_at: (/* @__PURE__ */ new Date(Date.now() - 3 * 3600 * 1e3)).toISOString(),
		updated_at: (/* @__PURE__ */ new Date(Date.now() - 2 * 3600 * 1e3)).toISOString(),
		category: SEED_CATEGORIES[0]
	},
	{
		id: 2,
		slug: "new-series-breaks-streaming-records",
		title: "New Streaming Series Shatters Records In First Week",
		dek: "The latest original series from the world's biggest streaming platform has broken all viewing records.",
		body: `<p>A new streaming series has taken the world by storm, breaking all previous viewing records in its first week of release. The show, which combines thrilling drama with stunning visuals, has captivated audiences around the globe.</p><p>Viewers have been raving about the incredible performances from the cast, the gripping storyline, and the high production values. Social media has been buzzing with discussions about the show, with fans sharing their favorite moments and theories about what might happen next.</p><p>The platform has already confirmed a second season is in development.</p>`,
		hero_image_hd: "https://images.unsplash.com/photo-1489599849927-2ee91cede3ba?w=1200&auto=format&fit=crop&q=80",
		hero_image_lq: "https://images.unsplash.com/photo-1489599849927-2ee91cede3ba?w=600&auto=format&fit=crop&q=80",
		hero_caption: "Behind the scenes on set",
		embed_url: null,
		category_id: 2,
		author_id: null,
		status: "published",
		is_breaking: false,
		is_featured: true,
		view_count: 9800,
		published_at: (/* @__PURE__ */ new Date(Date.now() - 14 * 3600 * 1e3)).toISOString(),
		created_at: (/* @__PURE__ */ new Date(Date.now() - 15 * 3600 * 1e3)).toISOString(),
		updated_at: (/* @__PURE__ */ new Date(Date.now() - 14 * 3600 * 1e3)).toISOString(),
		category: SEED_CATEGORIES[1]
	},
	{
		id: 3,
		slug: "chart-topping-artist-announces-world-tour",
		title: "Global Superstar Announces Massive 50-City World Tour",
		dek: "The biggest name in music is hitting the road with a world tour that will cover 50 cities across 6 continents.",
		body: `<p>Music fans around the world are celebrating today as the biggest artist on the planet announced an epic world tour that will visit 50 cities across 6 continents. The tour, which kicks off later this year, promises to be one of the most spectacular live shows ever seen.</p><p>Tickets go on sale next week, and fans are already preparing for what is expected to be one of the fastest-selling tours in history.</p>`,
		hero_image_hd: "https://images.unsplash.com/photo-1470225620780-dba8ba36b745?w=1200&auto=format&fit=crop&q=80",
		hero_image_lq: "https://images.unsplash.com/photo-1470225620780-dba8ba36b745?w=600&auto=format&fit=crop&q=80",
		hero_caption: "Electrifying live stadium performance",
		embed_url: null,
		category_id: 3,
		author_id: null,
		status: "published",
		is_breaking: true,
		is_featured: false,
		view_count: 18500,
		published_at: (/* @__PURE__ */ new Date(Date.now() - 26 * 3600 * 1e3)).toISOString(),
		created_at: (/* @__PURE__ */ new Date(Date.now() - 28 * 3600 * 1e3)).toISOString(),
		updated_at: (/* @__PURE__ */ new Date(Date.now() - 26 * 3600 * 1e3)).toISOString(),
		category: SEED_CATEGORIES[2]
	},
	{
		id: 4,
		slug: "fashion-week-highlights-top-trends",
		title: "Fashion Week Reveals Hottest Trends For The Season",
		dek: "The world's top fashion designers have unveiled their latest collections on the runway.",
		body: `<p>Fashion Week has come to a close, and the style world is buzzing about the incredible collections unveiled by top designers. From bold colors and dramatic silhouettes to minimalist elegance, this season's trends offer something for everyone.</p><p>Key trends include oversized outerwear, vibrant prints, sustainable materials, and a return to bold accessories.</p>`,
		hero_image_hd: "https://images.unsplash.com/photo-1509631179647-0177331693ae?w=1200&auto=format&fit=crop&q=80",
		hero_image_lq: "https://images.unsplash.com/photo-1509631179647-0177331693ae?w=600&auto=format&fit=crop&q=80",
		hero_caption: "Runway models presenting the spring collection",
		embed_url: null,
		category_id: 4,
		author_id: null,
		status: "published",
		is_breaking: false,
		is_featured: false,
		view_count: 6700,
		published_at: (/* @__PURE__ */ new Date(Date.now() - 36 * 3600 * 1e3)).toISOString(),
		created_at: (/* @__PURE__ */ new Date(Date.now() - 38 * 3600 * 1e3)).toISOString(),
		updated_at: (/* @__PURE__ */ new Date(Date.now() - 36 * 3600 * 1e3)).toISOString(),
		category: SEED_CATEGORIES[3]
	},
	{
		id: 5,
		slug: "royal-family-attends-charity-gala",
		title: "Royal Family Makes Glamorous Appearance At Charity Gala",
		dek: "Members of the royal family attended a star-studded charity gala last night to raise funds for important causes.",
		body: `<p>The royal family stepped out in style last night for a glamorous charity gala that raised millions for important causes. The event, which took place at a historic venue, brought together celebrities, philanthropists, and members of the public.</p><p>The evening featured a dinner, live auction, and performances from world-renowned artists.</p>`,
		hero_image_hd: "https://images.unsplash.com/photo-1519741497674-611481863552?w=1200&auto=format&fit=crop&q=80",
		hero_image_lq: "https://images.unsplash.com/photo-1519741497674-611481863552?w=600&auto=format&fit=crop&q=80",
		hero_caption: "Gala evening celebration",
		embed_url: null,
		category_id: 5,
		author_id: null,
		status: "published",
		is_breaking: false,
		is_featured: false,
		view_count: 11200,
		published_at: (/* @__PURE__ */ new Date(Date.now() - 48 * 3600 * 1e3)).toISOString(),
		created_at: (/* @__PURE__ */ new Date(Date.now() - 50 * 3600 * 1e3)).toISOString(),
		updated_at: (/* @__PURE__ */ new Date(Date.now() - 48 * 3600 * 1e3)).toISOString(),
		category: SEED_CATEGORIES[4]
	},
	{
		id: 6,
		slug: "championship-final-thriller",
		title: "Underdog Team Wins Championship In Stunning Upset",
		dek: "In a game for the ages, the underdog team came from behind to win the championship in a thrilling final.",
		body: `<p>Sports history was made last night as the underdog team pulled off one of the greatest upsets in championship history. Trailing by a significant margin at halftime, the team staged an incredible comeback in the second half.</p><p>This victory marks the team's first championship in decades and cements their place in sports history.</p>`,
		hero_image_hd: "https://images.unsplash.com/photo-1461896836934-ffe607ba8211?w=1200&auto=format&fit=crop&q=80",
		hero_image_lq: "https://images.unsplash.com/photo-1461896836934-ffe607ba8211?w=600&auto=format&fit=crop&q=80",
		hero_caption: "Celebrations after the final whistle",
		embed_url: null,
		category_id: 6,
		author_id: null,
		status: "published",
		is_breaking: true,
		is_featured: false,
		view_count: 15400,
		published_at: (/* @__PURE__ */ new Date(Date.now() - 54 * 3600 * 1e3)).toISOString(),
		created_at: (/* @__PURE__ */ new Date(Date.now() - 56 * 3600 * 1e3)).toISOString(),
		updated_at: (/* @__PURE__ */ new Date(Date.now() - 54 * 3600 * 1e3)).toISOString(),
		category: SEED_CATEGORIES[5]
	},
	{
		id: 7,
		slug: "celebrity-couple-spotted-vacation",
		title: "Celebrity Couple Spotted On Romantic Tropical Vacation",
		dek: "The hottest couple in Hollywood was seen enjoying a romantic getaway in paradise.",
		body: `<p>Love is in the air! The most talked-about celebrity couple was spotted enjoying a romantic vacation in a beautiful tropical location. The pair was seen walking hand in hand on the beach, enjoying sunset dinners, and looking very much in love.</p>`,
		hero_image_hd: "https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=1200&auto=format&fit=crop&q=80",
		hero_image_lq: "https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=600&auto=format&fit=crop&q=80",
		hero_caption: "Relaxing getaway in the sun",
		embed_url: null,
		category_id: 1,
		author_id: null,
		status: "published",
		is_breaking: false,
		is_featured: false,
		view_count: 8900,
		published_at: (/* @__PURE__ */ new Date(Date.now() - 60 * 3600 * 1e3)).toISOString(),
		created_at: (/* @__PURE__ */ new Date(Date.now() - 62 * 3600 * 1e3)).toISOString(),
		updated_at: (/* @__PURE__ */ new Date(Date.now() - 60 * 3600 * 1e3)).toISOString(),
		category: SEED_CATEGORIES[0]
	},
	{
		id: 8,
		slug: "music-festival-lineup-revealed",
		title: "Massive Summer Music Festival Reveals Epic Lineup",
		dek: "The annual music festival has just dropped its lineup, and it is even better than anticipated.",
		body: `<p>Summer music festival season is shaping up to be amazing, with the biggest festival of them all just revealing its incredible lineup. Featuring over 100 artists across multiple stages, this year's event is set to be the best one yet.</p>`,
		hero_image_hd: "https://images.unsplash.com/photo-1501386761578-eac5c94b800a?w=1200&auto=format&fit=crop&q=80",
		hero_image_lq: "https://images.unsplash.com/photo-1501386761578-eac5c94b800a?w=600&auto=format&fit=crop&q=80",
		hero_caption: "Crowds gathering at festival grounds",
		embed_url: null,
		category_id: 3,
		author_id: null,
		status: "published",
		is_breaking: false,
		is_featured: false,
		view_count: 7300,
		published_at: (/* @__PURE__ */ new Date(Date.now() - 72 * 3600 * 1e3)).toISOString(),
		created_at: (/* @__PURE__ */ new Date(Date.now() - 75 * 3600 * 1e3)).toISOString(),
		updated_at: (/* @__PURE__ */ new Date(Date.now() - 72 * 3600 * 1e3)).toISOString(),
		category: SEED_CATEGORIES[2]
	}
];
function normalizeMediaUrl(url) {
	if (!url || typeof url !== "string") return "";
	return url.replace(/^https?:\/\/aliceblue-goose-490382\.hostingersite\.com\/api\/uploads\//i, "/api/uploads/");
}
function normalizeArticleMedia(a) {
	if (!a) return a;
	const hd = a.hero_image_hd ? normalizeMediaUrl(a.hero_image_hd) : null;
	const lq = a.hero_image_lq ? normalizeMediaUrl(a.hero_image_lq) : null;
	let body = a.body;
	if (typeof body === "string" && body.includes("aliceblue-goose-490382.hostingersite.com/api/uploads/")) body = body.replace(/https?:\/\/aliceblue-goose-490382\.hostingersite\.com\/api\/uploads\//gi, "/api/uploads/");
	return {
		...a,
		hero_image_hd: hd,
		hero_image_lq: lq,
		body: body ?? ""
	};
}
var articleService = {
	async listPublished(opts = {}) {
		try {
			const params = new URLSearchParams();
			if (opts.limit) params.set("limit", opts.limit.toString());
			if (opts.offset) params.set("offset", opts.offset.toString());
			const result = await safeFetchJson(getApiUrl(`/articles/published?${params}`));
			let data = result.ok && Array.isArray(result.data) && result.data.length > 0 ? result.data.map(normalizeArticleMedia) : SEED_ARTICLES;
			if (opts.categorySlug) data = data.filter((a) => a.category?.slug === opts.categorySlug);
			if (opts.limit) {
				const offset = opts.offset || 0;
				data = data.slice(offset, offset + opts.limit);
			}
			return {
				data,
				count: data.length
			};
		} catch {
			let data = SEED_ARTICLES;
			if (opts.categorySlug) data = data.filter((a) => a.category?.slug === opts.categorySlug);
			return {
				data,
				count: data.length
			};
		}
	},
	async getBySlug(slug) {
		try {
			const result = await safeFetchJson(getApiUrl(`/articles/slug/${slug}`));
			if (result.ok && result.data) return normalizeArticleMedia(result.data);
			return SEED_ARTICLES.find((a) => a.slug === slug) ?? null;
		} catch {
			return SEED_ARTICLES.find((a) => a.slug === slug) ?? null;
		}
	},
	async listBreaking() {
		try {
			const result = await safeFetchJson(getApiUrl("/articles/published"));
			return (result.ok && Array.isArray(result.data) && result.data.length > 0 ? result.data.map(normalizeArticleMedia) : SEED_ARTICLES).filter((a) => a.is_breaking).slice(0, 6);
		} catch {
			return SEED_ARTICLES.filter((a) => a.is_breaking).slice(0, 6);
		}
	},
	async listTrending(limit = 6) {
		try {
			const result = await safeFetchJson(getApiUrl("/articles/published"));
			const list = result.ok && Array.isArray(result.data) && result.data.length > 0 ? result.data.map(normalizeArticleMedia) : SEED_ARTICLES;
			const seenSlugs = /* @__PURE__ */ new Set();
			return list.slice().sort((a, b) => {
				const aTime = a.published_at ? new Date(a.published_at).getTime() : new Date(a.created_at).getTime();
				const bTime = b.published_at ? new Date(b.published_at).getTime() : new Date(b.created_at).getTime();
				if (bTime !== aTime) return bTime - aTime;
				return (b.view_count ?? 0) - (a.view_count ?? 0);
			}).filter((a) => {
				const key = (a.slug || `${a.id}`).toLowerCase().trim();
				if (seenSlugs.has(key)) return false;
				seenSlugs.add(key);
				return true;
			}).slice(0, limit);
		} catch {
			return SEED_ARTICLES.slice(0, limit);
		}
	},
	async search(q) {
		try {
			const term = q.trim().toLowerCase();
			if (!term) return [];
			const result = await safeFetchJson(getApiUrl("/articles/published"));
			return (result.ok && Array.isArray(result.data) && result.data.length > 0 ? result.data.map(normalizeArticleMedia) : SEED_ARTICLES).filter((a) => a.title.toLowerCase().includes(term) || a.dek?.toLowerCase().includes(term));
		} catch {
			const term = q.trim().toLowerCase();
			return SEED_ARTICLES.filter((a) => a.title.toLowerCase().includes(term) || a.dek?.toLowerCase().includes(term));
		}
	},
	async related(article, limit = 4) {
		try {
			if (!article.category_id) return [];
			const result = await safeFetchJson(getApiUrl("/articles/published"));
			return (result.ok && Array.isArray(result.data) && result.data.length > 0 ? result.data.map(normalizeArticleMedia) : SEED_ARTICLES).filter((a) => a.category_id === article.category_id && a.id !== article.id).slice(0, limit);
		} catch {
			return SEED_ARTICLES.filter((a) => a.category_id === article.category_id && a.id !== article.id).slice(0, limit);
		}
	},
	async listAll() {
		const result = await safeFetchJson(getApiUrl("/articles?includeCategory=true"));
		if (!result.ok) throw new Error(result.error);
		return (Array.isArray(result.data) ? result.data : []).map(normalizeArticleMedia);
	},
	async create(input) {
		if (!input.title || !input.title.trim()) throw new Error("Article title is required.");
		if (!input.dek || !input.dek.trim()) throw new Error("Article description (dek) is required.");
		if (!input.category_id) throw new Error("Article category is required.");
		if (!input.hero_image_hd?.trim() && !input.hero_image_lq?.trim()) throw new Error("Article hero image is required.");
		const payload = {
			title: input.title.trim(),
			slug: input.slug || "",
			dek: input.dek.trim(),
			body: input.body || "",
			category_id: input.category_id || null,
			author_id: input.author_id || null,
			status: input.status || "draft",
			is_breaking: input.is_breaking || false,
			is_featured: input.is_featured || false,
			view_count: input.view_count || 0,
			published_at: input.published_at || null,
			hero_image_hd: input.hero_image_hd || null,
			hero_image_lq: input.hero_image_lq || null,
			hero_caption: input.hero_caption || null,
			embed_url: input.embed_url || null
		};
		const result = await safeFetchJson(getApiUrl("/articles"), {
			method: "POST",
			headers: { "Content-Type": "application/json" },
			body: JSON.stringify(payload)
		});
		if (!result.ok) throw new Error(result.error);
		return result.data;
	},
	async update(id, input) {
		if (input.title !== void 0 && !input.title.trim()) throw new Error("Article title cannot be empty.");
		if (input.dek !== void 0 && !input.dek.trim()) throw new Error("Article description (dek) cannot be empty.");
		if ((input.hero_image_hd !== void 0 || input.hero_image_lq !== void 0) && !input.hero_image_hd?.trim() && !input.hero_image_lq?.trim()) throw new Error("Article hero image cannot be empty.");
		const payload = { ...input };
		delete payload.created_at;
		delete payload.updated_at;
		delete payload.id;
		const result = await safeFetchJson(getApiUrl(`/articles/${id}`), {
			method: "PUT",
			headers: { "Content-Type": "application/json" },
			body: JSON.stringify(payload)
		});
		if (!result.ok) throw new Error(result.error);
		return result.data;
	},
	async remove(id) {
		const result = await safeFetchJson(getApiUrl(`/articles/${id}`), { method: "DELETE" });
		if (!result.ok) throw new Error(result.error);
	},
	async delete(id) {
		return this.remove(id);
	}
};
var categoryService = {
	async list() {
		try {
			const result = await safeFetchJson(getApiUrl("/categories"), { cache: "no-store" });
			if (result.ok && Array.isArray(result.data) && result.data.length > 0) return result.data;
			return SEED_CATEGORIES;
		} catch {
			return SEED_CATEGORIES;
		}
	},
	async create(input) {
		const result = await safeFetchJson(getApiUrl("/categories"), {
			method: "POST",
			headers: { "Content-Type": "application/json" },
			cache: "no-store",
			body: JSON.stringify({
				...input,
				created_at: (/* @__PURE__ */ new Date()).toISOString()
			})
		});
		if (!result.ok) throw new Error(result.error);
		return result.data;
	},
	async update(id, input) {
		const result = await safeFetchJson(getApiUrl(`/categories/${id}`), {
			method: "PUT",
			headers: { "Content-Type": "application/json" },
			body: JSON.stringify({ ...input })
		});
		if (!result.ok) throw new Error(result.error);
		return result.data;
	},
	async remove(id) {
		const result = await safeFetchJson(getApiUrl(`/categories/${id}`), { method: "DELETE" });
		if (!result.ok) throw new Error(result.error);
	},
	async delete(id) {
		return this.remove(id);
	}
};
//#endregion
export { categoryService as n, normalizeMediaUrl as r, articleService as t };
