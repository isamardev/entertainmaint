import { i as require_jsx_runtime, t as useQuery } from "../_libs/react+tanstack__react-query.mjs";
import { g as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as articleService } from "./articleService-UhMa44iK.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/Sidebar-DKeRiSHS.js
var import_jsx_runtime = require_jsx_runtime();
function TrendingSidebar() {
	const { data: trendingData = [] } = useQuery({
		queryKey: ["trending"],
		queryFn: () => articleService.listTrending(5),
		staleTime: 6e4
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("aside", {
		className: "space-y-6",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "border-t-4 border-black bg-white p-5",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "display mb-4 text-xl font-black uppercase tracking-wide",
				children: "Trending Now"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "space-y-4",
				children: trendingData.slice(0, 5).map((a) => {
					const img = a.hero_image_hd ?? a.hero_image_lq;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex gap-3 border-b border-gray-200 pb-4 last:border-0 last:pb-0",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex gap-3 min-w-0",
							children: [img && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/article/$slug",
								params: { slug: a.slug },
								className: "shrink-0",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
									src: img,
									alt: a.title,
									className: "h-16 w-20 object-cover"
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "min-w-0",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: "/article/$slug",
									params: { slug: a.slug },
									className: "display block text-sm font-bold leading-snug hover:text-black",
									children: a.title
								})
							})]
						})
					}, a.id);
				})
			})]
		})
	});
}
//#endregion
export { TrendingSidebar as t };
