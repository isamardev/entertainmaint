import { i as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { g as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { r as normalizeMediaUrl } from "./articleService-CLr-p8NN.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/ArticleCard-BgZT1eXg.js
var import_jsx_runtime = require_jsx_runtime();
function ArticleCard({ article, size = "md", horizontal = false, imageOverride }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: `group ${horizontal ? "flex gap-4" : ""}`,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
			to: "/article/$slug",
			params: { slug: article.slug },
			className: horizontal ? "block w-32 shrink-0 sm:w-40" : "block",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArticleMedia, {
				article,
				imageOverride,
				className: "relative aspect-[16/10] w-full overflow-hidden bg-surface",
				imgClassName: "h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: horizontal ? "min-w-0 flex-1" : "mt-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/article/$slug",
				params: { slug: article.slug },
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: `display font-black leading-snug group-hover:text-black line-clamp-3 ${size === "lg" ? "text-xl md:text-2xl" : size === "sm" ? "text-sm sm:text-[15px]" : "text-base sm:text-lg"}`,
					style: {
						display: "-webkit-box",
						WebkitLineClamp: 3,
						WebkitBoxOrient: "vertical",
						overflow: "hidden",
						textOverflow: "ellipsis"
					},
					children: article.title
				})
			}), size !== "sm" && article.dek && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1.5 line-clamp-2 text-xs sm:text-sm text-muted-foreground",
				children: article.dek
			})]
		})]
	});
}
function getEmbedPreview(url) {
	if (!url) return null;
	try {
		const parsed = new URL(url);
		const host = parsed.hostname.replace(/^www\./, "").toLowerCase();
		if (host.includes("youtu.be") || host.includes("youtube.com")) {
			const pathParts = parsed.pathname.split("/").filter(Boolean);
			const videoId = parsed.searchParams.get("v") ?? (pathParts[0] === "shorts" ? pathParts[1] : null) ?? (host.includes("youtu.be") ? pathParts[0] : null);
			if (videoId) return {
				label: "YouTube",
				image: `https://img.youtube.com/vi/${videoId}/hqdefault.jpg`,
				host
			};
		}
		if (host.includes("instagram.com")) return {
			label: "Instagram",
			image: null,
			host
		};
		if (host.includes("x.com") || host.includes("twitter.com")) return {
			label: "X",
			image: null,
			host
		};
		if (host.includes("tiktok.com")) return {
			label: "TikTok",
			image: null,
			host
		};
		return {
			label: "Link",
			image: null,
			host
		};
	} catch {
		return {
			label: "Link",
			image: null,
			host: ""
		};
	}
}
function ArticleMedia({ article, imageOverride, className, imgClassName }) {
	const hd = imageOverride ?? article.hero_image_hd ?? article.hero_image_lq ?? "";
	imageOverride ?? article.hero_image_lq;
	const preview = getEmbedPreview(article.embed_url);
	const imageSrc = normalizeMediaUrl(hd || preview?.image || "");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className,
		children: imageSrc ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("picture", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
			src: imageSrc,
			alt: article.title,
			loading: "lazy",
			decoding: "async",
			className: imgClassName
		}) }) : preview ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex h-full w-full flex-col justify-between border border-gray-200 bg-white p-4 text-black",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-xs font-black uppercase tracking-[0.25em]",
				children: preview.label
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-lg font-black leading-tight",
				children: "Open Story"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-xs text-muted-foreground",
				children: preview.host || "Embedded post"
			})] })]
		}) : null
	});
}
//#endregion
export { ArticleMedia as n, ArticleCard as t };
