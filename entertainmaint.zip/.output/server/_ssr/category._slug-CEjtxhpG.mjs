import { N as notFound, m as createFileRoute, p as lazyRouteComponent } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as categoryService } from "./articleService-UhMa44iK.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/category._slug-CEjtxhpG.js
var $$splitNotFoundComponentImporter = () => import("./category._slug-DxEsJ-oc.mjs");
var $$splitErrorComponentImporter = () => import("./category._slug-CKMZ-kgP.mjs");
var $$splitComponentImporter = () => import("./category._slug-BAC2nbY8.mjs");
var Route = createFileRoute("/category/$slug")({
	loader: async ({ params }) => {
		const cat = (await categoryService.list()).find((c) => c.slug === params.slug);
		if (!cat) throw notFound();
		return { category: cat };
	},
	head: ({ loaderData }) => ({
		meta: loaderData ? [{ title: `${loaderData.category.name} — Entertainment Trends` }, {
			name: "description",
			content: `Latest ${loaderData.category.name} news on Entertainment Trends.`
		}] : [{ title: "Category — Entertainment Trends" }],
		links: loaderData ? [{
			rel: "canonical",
			href: `/category/${loaderData.category.slug}`
		}] : []
	}),
	component: lazyRouteComponent($$splitComponentImporter, "component"),
	errorComponent: lazyRouteComponent($$splitErrorComponentImporter, "errorComponent"),
	notFoundComponent: lazyRouteComponent($$splitNotFoundComponentImporter, "notFoundComponent")
});
//#endregion
export { Route as t };
