import { r as __toESM } from "../_runtime.mjs";
import { a as require_react, i as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { n as useAuth } from "./AuthContext-0j4f6QBo.mjs";
import { g as Link, v as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/AdminLoginForm-CUEkuYXL.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function AdminLoginForm({ redirectTo = "/admin", showBackLink = true }) {
	const { signIn, user, loading, isAdmin } = useAuth();
	const navigate = useNavigate();
	const [email, setEmail] = (0, import_react.useState)("");
	const [password, setPassword] = (0, import_react.useState)("");
	const [remember, setRemember] = (0, import_react.useState)(true);
	const [err, setErr] = (0, import_react.useState)(null);
	const [busy, setBusy] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		if (loading) return;
		if (!user) return;
		navigate({
			to: isAdmin ? redirectTo : "/",
			replace: true
		});
	}, [
		user,
		loading,
		isAdmin,
		navigate,
		redirectTo
	]);
	async function submit(e) {
		e.preventDefault();
		setErr(null);
		setBusy(true);
		const r = await signIn(email, password, remember);
		setBusy(false);
		if (r.error) setErr(r.error);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto flex max-w-md flex-col px-4 py-16",
		children: [showBackLink && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
			to: "/",
			className: "eyebrow mb-4",
			children: "← Back to Entertainment Trends"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "border-t-4 border-yellow bg-surface p-6",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "display text-3xl font-black uppercase",
					children: "Admin sign in"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-muted-foreground",
					children: "Sign in to access the admin dashboard."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					onSubmit: submit,
					className: "mt-6 space-y-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "email",
							required: true,
							autoComplete: "username",
							value: email,
							onChange: (e) => setEmail(e.target.value),
							placeholder: "Username / Email",
							className: "w-full border border-border bg-background px-3 py-2 outline-none focus:border-yellow"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "password",
							required: true,
							minLength: 6,
							autoComplete: "current-password",
							value: password,
							onChange: (e) => setPassword(e.target.value),
							placeholder: "Password",
							className: "w-full border border-border bg-background px-3 py-2 outline-none focus:border-yellow"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "flex cursor-pointer items-center gap-2 pt-1 text-sm select-none",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "checkbox",
								checked: remember,
								onChange: (e) => setRemember(e.target.checked),
								className: "h-4 w-4 accent-yellow"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-muted-foreground",
								children: "Keep me signed in"
							})]
						}),
						err && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "border border-yellow bg-yellow/10 px-3 py-2 text-xs text-yellow",
							children: err
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							disabled: busy,
							className: "yellow-bar w-full py-2.5 font-black uppercase tracking-widest disabled:opacity-60",
							children: busy ? "Please wait…" : "Sign in"
						})
					]
				})
			]
		})]
	});
}
//#endregion
export { AdminLoginForm as t };
