import { m as createFileRoute, p as lazyRouteComponent } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/admin.edit._id-8l7sX5Pt.js
var $$splitComponentImporter = () => import("./admin.edit._id-Bii5TIV1.mjs");
var Route = createFileRoute("/admin/edit/$id")({ component: lazyRouteComponent($$splitComponentImporter, "component") });
//#endregion
export { Route as t };
