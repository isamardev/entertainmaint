import { r as __toESM } from "../_runtime.mjs";
import { a as require_react, i as require_jsx_runtime, t as useQuery } from "../_libs/react+tanstack__react-query.mjs";
import { g as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { S as LoaderCircle } from "../_libs/lucide-react.mjs";
import { t as articleService } from "./articleService-CLr-p8NN.mjs";
import { n as ArticleMedia, t as ArticleCard } from "./ArticleCard-BgZT1eXg.mjs";
import { t as TrendingSidebar } from "./Sidebar-wR4mzam-.mjs";
import { t as Helmet } from "../_libs/react-helmet-async+[...].mjs";
import { t as GridSkeleton } from "./Skeleton-CGTHVyfA.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-BC_lUBhk.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function articleImage(article, alt = false) {
	const primary = article.hero_image_hd ?? article.hero_image_lq ?? "";
	const secondary = article.hero_image_lq ?? article.hero_image_hd ?? "";
	if (!alt) return primary;
	if (secondary && secondary !== primary) return secondary;
	if (primary.includes("picsum.photos/seed/")) return primary.replace(/\/\d+\/\d+$/, "/1600/1200");
	return primary;
}
function Home() {
	const [visibleCount, setVisibleCount] = (0, import_react.useState)(18);
	const [isLoadingMore, setIsLoadingMore] = (0, import_react.useState)(false);
	const { data, isLoading } = useQuery({
		queryKey: ["home-articles"],
		queryFn: () => articleService.listPublished({ limit: 100 })
	});
	const allArticles = data?.data ?? [];
	const articles = allArticles.slice(0, visibleCount);
	const hasMore = visibleCount < allArticles.length;
	const handleShowMore = () => {
		setIsLoadingMore(true);
		setTimeout(() => {
			setVisibleCount((prev) => prev + 12);
			setIsLoadingMore(false);
		}, 200);
	};
	const mobileSections = [];
	let mobileIndex = 0;
	while (mobileIndex < articles.length) {
		const featured = articles[mobileIndex++];
		const list = articles.slice(mobileIndex, mobileIndex + 3);
		mobileIndex += list.length;
		mobileSections.push({
			featured,
			list
		});
	}
	const chunks = [];
	let i = 0;
	while (i < articles.length) {
		const chunk = {};
		chunk.large = articles[i++];
		chunk.grid = [];
		for (let j = 0; j < 3 && i < articles.length; j++) chunk.grid.push(articles[i++]);
		if (i + 2 < articles.length) chunk.split = {
			large: articles[i++],
			top: articles[i++],
			bottom: articles[i++]
		};
		else chunk.split = void 0;
		chunks.push(chunk);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Helmet, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("title", { children: "Entertainment Trends — The Pulse of Pop Culture" }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-10 lg:grid-cols-[minmax(0,1fr)_320px]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "min-w-0",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "md:hidden",
					children: isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "animate-pulse space-y-8",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "aspect-[16/9] bg-surface w-full" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "space-y-4",
								children: Array.from({ length: 3 }).map((_, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex gap-4",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "aspect-[16/10] w-32 shrink-0 bg-surface" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex-1 space-y-2 pt-1",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-5 w-full bg-surface" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-5 w-4/5 bg-surface" })]
									})]
								}, index))
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "aspect-[16/9] bg-surface w-full" })
						]
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "space-y-8",
						children: mobileSections.map((section, sectionIndex) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-5",
							children: [
								section.featured && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FeaturedArticle, {
									article: section.featured,
									isLoading,
									keySuffix: `mobile-${sectionIndex}`,
									useAltImage: sectionIndex % 2 !== 0
								}) }),
								section.list.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "space-y-4",
									children: section.list.map((article, articleIndex) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArticleCard, {
										article,
										horizontal: true,
										size: "sm",
										imageOverride: sectionIndex % 2 !== 0 ? articleImage(article, true) : void 0
									}), articleIndex < section.list.length - 1 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "mt-4 border-b border-gray-400",
										"aria-hidden": "true"
									})] }, `${article.id}-mobile-${articleIndex}`))
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "border-b border-gray-400",
									"aria-hidden": "true"
								})
							]
						}, section.featured?.id ?? sectionIndex))
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "hidden md:block",
					children: isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "animate-pulse space-y-10",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "aspect-[16/9] bg-surface w-full" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(GridSkeleton, {}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(GridSkeleton, {}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid gap-6 md:grid-cols-[2fr_3fr]",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "space-y-6",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "aspect-[16/10] bg-surface" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "aspect-[16/10] bg-surface" })]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "aspect-[16/9] bg-surface" })]
							})
						]
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [chunks.map((chunk, chunkIndex) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						chunk.large && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FeaturedArticle, {
							article: chunk.large,
							isLoading,
							keySuffix: `chunk-${chunkIndex}`,
							useAltImage: chunkIndex % 2 !== 0,
							centerTitle: chunkIndex === 0,
							hideDek: chunkIndex === 0
						}),
						chunk.grid.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArticleGrid, {
							articles: chunk.grid,
							isLoading,
							keySuffix: `chunk-${chunkIndex}`,
							useAltImage: chunkIndex % 2 !== 0
						}),
						chunk.split && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SplitArticleLayout, {
							largeArticle: chunk.split.large,
							topArticle: chunk.split.top,
							bottomArticle: chunk.split.bottom,
							largeOnLeft: chunkIndex % 2 === 0,
							useAltImage: chunkIndex % 2 !== 0
						})
					] }, chunkIndex)), chunks.flatMap((c) => [
						c.large,
						...c.grid,
						c.split?.large,
						c.split?.top,
						c.split?.bottom
					]).filter(Boolean).length < articles.length && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MoreStories, { articles: articles.slice(chunks.flatMap((c) => [
						c.large,
						...c.grid,
						c.split?.large,
						c.split?.top,
						c.split?.bottom
					]).filter(Boolean).length) })] })
				}),
				!isLoading && hasMore && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "my-10 flex justify-center",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: handleShowMore,
						disabled: isLoadingMore,
						className: "w-full max-w-md py-3.5 px-8 border-2 border-black bg-white hover:bg-black text-black hover:text-white font-black uppercase text-sm tracking-widest transition-all duration-200 flex items-center justify-center gap-2 shadow-xs disabled:opacity-50 cursor-pointer",
						children: isLoadingMore ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "w-4 h-4 animate-spin" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Loading Stories..." })] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Show More Stories" })
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-10 lg:hidden",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TrendingSidebar, {})
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "relative hidden lg:block",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "sticky top-24",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TrendingSidebar, {})
			})
		})]
	})] });
}
function FeaturedArticle({ article, isLoading, keySuffix = "", useAltImage = false, centerTitle = false, hideDek = false }) {
	if (isLoading && !article) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "aspect-[16/9] w-full animate-pulse bg-surface mb-10" });
	if (!article) return null;
	const img = articleImage(article, useAltImage);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "mb-10",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
			to: `/article/${article.slug}`,
			className: "group block",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArticleMedia, {
					article,
					imageOverride: img,
					className: "mb-4 aspect-[16/9] w-full overflow-hidden bg-surface",
					imgClassName: "h-full w-full object-cover transition-transform duration-700 group-hover:scale-105"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: `display text-xl sm:text-2xl md:text-[28px] lg:text-[32px] font-black leading-[1.15] group-hover:text-black text-center line-clamp-3`,
					style: {
						display: "-webkit-box",
						WebkitLineClamp: 3,
						WebkitBoxOrient: "vertical",
						overflow: "hidden",
						textOverflow: "ellipsis"
					},
					children: article.title
				}),
				article.dek && !hideDek && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm md:text-sm text-muted-foreground hidden md:block",
					children: article.dek
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-10 border-b border-gray-400",
			"aria-hidden": "true"
		})]
	}, `featured${keySuffix}`);
}
function ArticleGrid({ articles, isLoading, keySuffix = "", useAltImage = false }) {
	if (!articles.length && !isLoading) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mb-10",
		children: [isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GridSkeleton, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "relative",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid gap-y-8 gap-x-10 sm:grid-cols-2 sm:gap-y-10 sm:gap-x-10 lg:grid-cols-3 lg:gap-x-12",
					children: articles.map((a, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-col",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArticleCard, {
							article: a,
							imageOverride: useAltImage ? articleImage(a, true) : void 0
						}), i < articles.length - 1 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-8 block border-b border-gray-400 sm:hidden",
							"aria-hidden": "true"
						})]
					}, `${a.id}${keySuffix}-${i}`))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					"aria-hidden": "true",
					className: "pointer-events-none absolute inset-y-0 left-1/2 hidden -translate-x-1/2 w-px bg-gray-400 sm:block lg:hidden"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					"aria-hidden": "true",
					className: "pointer-events-none absolute inset-y-0 left-[33.3333%] hidden -translate-x-1/2 w-px bg-gray-400 lg:block"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					"aria-hidden": "true",
					className: "pointer-events-none absolute inset-y-0 left-[66.6666%] hidden -translate-x-1/2 w-px bg-gray-400 lg:block"
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-10 border-b border-gray-400",
			"aria-hidden": "true"
		})]
	});
}
function SplitArticleLayout({ largeArticle, topArticle, bottomArticle, largeOnLeft, useAltImage = false }) {
	const renderSmallArticle = (article, isLast) => {
		const img = articleImage(article, useAltImage);
		return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
			to: `/article/${article.slug}`,
			className: "group flex min-h-0 flex-1 flex-col " + (!isLast ? "pb-5 md:pb-6 border-b border-gray-400 mb-5 md:mb-6" : ""),
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArticleMedia, {
				article,
				imageOverride: img,
				className: "relative mb-3 min-h-[160px] flex-1 overflow-hidden bg-surface sm:min-h-[180px]",
				imgClassName: "absolute inset-0 h-full w-full object-cover transition-transform duration-700 group-hover:scale-105"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "shrink-0 text-left",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "display text-base sm:text-[17px] font-black leading-snug group-hover:text-black line-clamp-3",
					style: {
						display: "-webkit-box",
						WebkitLineClamp: 3,
						WebkitBoxOrient: "vertical",
						overflow: "hidden",
						textOverflow: "ellipsis"
					},
					children: article.title
				}), article.dek && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1.5 line-clamp-2 text-xs sm:text-sm text-muted-foreground",
					children: article.dek
				})]
			})]
		}, article.id);
	};
	const largeImg = articleImage(largeArticle, useAltImage);
	const largeBlock = /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
		to: `/article/${largeArticle.slug}`,
		className: "group flex h-full min-h-0 flex-col",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArticleMedia, {
			article: largeArticle,
			imageOverride: largeImg,
			className: "relative mb-4 min-h-[220px] flex-1 overflow-hidden bg-surface sm:min-h-[280px]",
			imgClassName: "absolute inset-0 h-full w-full object-cover transition-transform duration-700 group-hover:scale-105"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "shrink-0",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "display text-lg sm:text-xl md:text-2xl font-black leading-snug group-hover:text-black text-center line-clamp-3",
				style: {
					display: "-webkit-box",
					WebkitLineClamp: 3,
					WebkitBoxOrient: "vertical",
					overflow: "hidden",
					textOverflow: "ellipsis"
				},
				children: largeArticle.title
			}), largeArticle.dek && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 line-clamp-2 text-xs sm:text-sm text-muted-foreground",
				children: largeArticle.dek
			})]
		})]
	});
	const smallStack = /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex h-full min-h-0 flex-col md:gap-0",
		children: [renderSmallArticle(topArticle, false), renderSmallArticle(bottomArticle, true)]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mb-10",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: `grid gap-6 md:min-h-[560px] md:items-stretch md:gap-0 ${largeOnLeft ? "md:grid-cols-[3fr_2fr]" : "md:grid-cols-[2fr_3fr]"}`,
			children: largeOnLeft ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex h-full min-h-0 flex-col md:pr-5 md:border-r md:border-gray-400",
				children: largeBlock
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex h-full min-h-0 flex-col md:pl-5",
				children: smallStack
			})] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex h-full min-h-0 flex-col md:pr-5 md:border-r md:border-gray-400",
				children: smallStack
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex h-full min-h-0 flex-col md:pl-5",
				children: largeBlock
			})] })
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-4 border-b border-gray-400",
			"aria-hidden": "true"
		})]
	});
}
function MoreStories({ articles }) {
	if (!articles.length) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mt-10",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mb-6",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "display text-2xl font-black uppercase",
				children: "More Stories"
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "grid gap-6 sm:grid-cols-2",
			children: articles.map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArticleCard, {
				article: a,
				horizontal: true
			}, a.id))
		})]
	});
}
//#endregion
export { Home as component };
