import { i as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { t as AdminLoginForm } from "./AdminLoginForm-cnqECKQ2.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/admin.login-BGMlB1iE.js
var import_jsx_runtime = require_jsx_runtime();
function AdminLoginPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AdminLoginForm, {
		redirectTo: "/admin",
		showBackLink: true
	});
}
//#endregion
export { AdminLoginPage as component };
