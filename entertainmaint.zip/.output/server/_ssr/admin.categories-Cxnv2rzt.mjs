import { r as __toESM } from "../_runtime.mjs";
import { a as require_react, i as require_jsx_runtime, r as useQueryClient, t as useQuery } from "../_libs/react+tanstack__react-query.mjs";
import { n as useAuth } from "./AuthContext-0j4f6QBo.mjs";
import { n as categoryService } from "./articleService-UhMa44iK.mjs";
import { t as DeleteModal } from "./DeleteModal-DhnY0sX8.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { m as Pencil, s as Trash2 } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/admin.categories-Cxnv2rzt.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function CategoriesAdmin() {
	const { isSuperAdmin } = useAuth();
	const qc = useQueryClient();
	const { data = [], isLoading, error } = useQuery({
		queryKey: ["categories"],
		queryFn: categoryService.list
	});
	const [name, setName] = (0, import_react.useState)("");
	const [slug, setSlug] = (0, import_react.useState)("");
	const [editingId, setEditingId] = (0, import_react.useState)(null);
	const [err, setErr] = (0, import_react.useState)(null);
	const [deleteModal, setDeleteModal] = (0, import_react.useState)({
		isOpen: false,
		id: 0,
		name: ""
	});
	if (!isSuperAdmin) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "text-sm text-gray-600",
		children: "Super Admin only."
	});
	async function save(e) {
		e.preventDefault();
		setErr(null);
		try {
			const payload = {
				name,
				slug: slug || name.toLowerCase().replace(/\s+/g, "-")
			};
			if (editingId != null) {
				await categoryService.update(editingId, payload);
				toast.success("Category updated successfully!");
			} else {
				await categoryService.create(payload);
				toast.success("Category added successfully!");
			}
			setName("");
			setSlug("");
			setEditingId(null);
			qc.invalidateQueries({ queryKey: ["categories"] });
		} catch (e) {
			setErr(e.message);
			toast.error(editingId != null ? "Failed to update category." : "Failed to add category.");
		}
	}
	async function handleDelete() {
		try {
			await categoryService.remove(deleteModal.id);
			qc.invalidateQueries({ queryKey: ["categories"] });
			qc.invalidateQueries({ queryKey: ["admin-articles"] });
			toast.success("Category deleted successfully!");
		} catch (e) {
			toast.error(e?.message || "Failed to delete category.");
		} finally {
			setDeleteModal({
				isOpen: false,
				id: 0,
				name: ""
			});
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid h-full min-h-0 gap-8 lg:grid-cols-2",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex min-h-0 flex-col",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "display mb-4 shrink-0 text-xl font-black uppercase",
					children: "Categories"
				}), isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "text-sm text-black border border-gray-200 p-3",
					children: "Loading categories…"
				}) : error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "rounded-lg border border-red-200 bg-red-50 p-5",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-start justify-between gap-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "text-sm font-semibold text-red-800",
								children: "Unable to load categories"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-sm text-red-700",
								children: (() => {
									const raw = error?.message;
									if (!raw) return "Please refresh the page and try again.";
									if (raw.includes("<") || raw.includes("DOCTYPE") || raw.startsWith("Unexpected token")) return "Something went wrong. Please try again later.";
									if (raw.length > 220) return raw.slice(0, 220) + "…";
									return raw;
								})()
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => qc.invalidateQueries({ queryKey: ["categories"] }),
							className: "shrink-0 rounded-md border border-red-300 bg-white px-3 py-1.5 text-xs font-semibold uppercase tracking-wider text-red-700 hover:bg-red-100",
							children: "Retry"
						})]
					})
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "min-h-0 flex-1 overflow-auto border border-gray-200",
					children: data.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between gap-3 border-b border-gray-200 p-3 last:border-0",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "truncate font-semibold",
								children: c.name
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "truncate text-xs text-black",
								children: c.slug
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => {
									setEditingId(c.id);
									setName(c.name);
									setSlug(c.slug);
									setErr(null);
								},
								className: "p-1 text-black hover:text-gray-700",
								"aria-label": "Edit category",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pencil, { size: 18 })
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => setDeleteModal({
									isOpen: true,
									id: c.id,
									name: c.name
								}),
								className: "p-1 text-red-600 hover:text-red-800",
								"aria-label": "Delete category",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { size: 18 })
							})]
						})]
					}, c.id))
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				onSubmit: save,
				className: "space-y-3 border border-gray-200 bg-gray-50 p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-xs font-black uppercase tracking-widest text-black",
						children: editingId != null ? "Update Category" : "Add Category"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						required: true,
						value: name,
						onChange: (e) => setName(e.target.value),
						placeholder: "Name",
						className: "w-full border border-gray-300 bg-white px-3 py-2 outline-none focus:border-black"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						value: slug,
						onChange: (e) => setSlug(e.target.value),
						placeholder: "slug (optional)",
						className: "w-full border border-gray-300 bg-white px-3 py-2 outline-none focus:border-black"
					}),
					err && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-xs text-red-600",
						children: err
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-2 gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							className: "py-2 font-black uppercase tracking-widest bg-black text-white hover:bg-gray-800",
							children: editingId != null ? "Update" : "Add"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => {
								setEditingId(null);
								setName("");
								setSlug("");
								setErr(null);
							},
							className: "py-2 font-black uppercase tracking-widest border border-gray-300 text-black hover:bg-gray-100",
							children: "Cancel"
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DeleteModal, {
				isOpen: deleteModal.isOpen,
				title: "Delete Category",
				message: `Delete "${deleteModal.name}" category? If this category has articles, those articles will be deleted first.`,
				onConfirm: handleDelete,
				onCancel: () => setDeleteModal({
					isOpen: false,
					id: 0,
					name: ""
				})
			})
		]
	});
}
//#endregion
export { CategoriesAdmin as component };
