import { t as getApiUrl } from "./safe-fetch-Dfsgx9OJ.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/adminAuthService-LlBhLIGz.js
var TOKEN_KEY_LS = "admin_auth_token";
var TOKEN_KEY_SS = "admin_auth_token_session";
var REMEMBER_KEY = "admin_auth_remember";
function isRememberFlagSet() {
	if (typeof window === "undefined") return true;
	return localStorage.getItem(REMEMBER_KEY) === "1";
}
function readTokenAnywhere() {
	if (typeof window === "undefined") return null;
	const ss = sessionStorage.getItem(TOKEN_KEY_SS);
	if (ss) return ss;
	const ls = localStorage.getItem(TOKEN_KEY_LS);
	if (ls) return ls;
	return null;
}
var SESSION_MAX_DURATION_MS = 1200 * 1e3;
var LAST_ACTIVITY_KEY = "admin_auth_last_activity";
var SESSION_START_KEY = "admin_auth_session_start";
function isSessionExpired() {
	if (typeof window === "undefined") return false;
	if (!readTokenAnywhere()) return false;
	const lastActivity = Number(localStorage.getItem(LAST_ACTIVITY_KEY) || 0);
	if (!lastActivity) return false;
	return Date.now() - lastActivity >= SESSION_MAX_DURATION_MS;
}
function touchAdminSession() {
	if (typeof window === "undefined") return;
	if (!readTokenAnywhere()) return;
	if (isSessionExpired()) {
		clearAdminToken();
		return;
	}
	localStorage.setItem(LAST_ACTIVITY_KEY, String(Date.now()));
}
function getAdminToken() {
	if (isSessionExpired()) {
		clearAdminToken();
		return null;
	}
	return readTokenAnywhere();
}
function setAdminToken(token, remember = true) {
	if (typeof window === "undefined") return;
	const now = String(Date.now());
	localStorage.setItem(SESSION_START_KEY, now);
	localStorage.setItem(LAST_ACTIVITY_KEY, now);
	if (remember) {
		localStorage.setItem(TOKEN_KEY_LS, token);
		sessionStorage.removeItem(TOKEN_KEY_SS);
		localStorage.setItem(REMEMBER_KEY, "1");
	} else {
		sessionStorage.setItem(TOKEN_KEY_SS, token);
		localStorage.removeItem(TOKEN_KEY_LS);
		localStorage.removeItem(REMEMBER_KEY);
	}
	clearLegacyAdminStorage();
}
function clearAdminToken() {
	if (typeof window !== "undefined") {
		localStorage.removeItem(TOKEN_KEY_LS);
		sessionStorage.removeItem(TOKEN_KEY_SS);
		localStorage.removeItem(REMEMBER_KEY);
		localStorage.removeItem(SESSION_START_KEY);
		localStorage.removeItem(LAST_ACTIVITY_KEY);
	}
	clearLegacyAdminStorage();
}
var LEGACY_KEYS = [
	"admin_auth_secure",
	"admin_auth_session",
	"dev_admin_email",
	"dev_admin_password",
	"dev_admin"
];
function clearLegacyAdminStorage() {
	for (const key of LEGACY_KEYS) localStorage.removeItem(key);
}
async function parseAdminResponseInner(text, status, headers) {
	const trimmed = text.trim();
	if (!trimmed) {
		if (status >= 200 && status < 300) return {};
		if (status === 404) throw new Error("The requested page or action is currently unavailable. Please try again later.");
		throw new Error("Something went wrong. Please try again later.");
	}
	if (trimmed.slice(0, 9).toUpperCase().startsWith("<!DOCTYPE") || /<html[\s>]/i.test(trimmed.slice(0, 512))) {
		if (status === 404) throw new Error("The requested page or action is currently unavailable. Please try again later.");
		throw new Error("Something went wrong. Please try again later.");
	}
	const ct = headers.get("content-type");
	const isJsonLike = !!ct && (/application\/json/i.test(ct) || /application\/.*\+json/i.test(ct) || /text\/json/i.test(ct));
	let parsed;
	if (isJsonLike || /^[\[{]/.test(trimmed)) try {
		parsed = JSON.parse(trimmed);
	} catch {
		throw new Error("Something went wrong. Please try again later.");
	}
	else throw new Error("Something went wrong. Please try again later.");
	const payload = parsed || {};
	if (status >= 200 && status < 300) return payload;
	const errorText = payload && typeof payload === "object" ? payload.error || payload.message : void 0;
	if (typeof errorText === "string" && errorText.trim()) throw new Error(errorText.trim().replace(/[<>]/g, ""));
	if (status === 401) throw new Error("Your session has expired. Please sign in again.");
	if (status === 403) throw new Error("You do not have permission to perform this action.");
	throw new Error("Something went wrong. Please try again later.");
}
function networkErrorText(error) {
	if (error instanceof TypeError && /failed to fetch|networkerror|load failed/i.test(error.message)) return "Unable to reach the server. Please check your internet connection and try again.";
	if (error instanceof Error && error.message && !/<|DOCTYPE/i.test(error.message)) return error.message;
	return "Network error. Please try again.";
}
async function adminApiRequest(url, init = {}) {
	const token = getAdminToken();
	if (token) touchAdminSession();
	const headers = new Headers(init.headers ?? {});
	if (token) headers.set("Authorization", `Bearer ${token}`);
	if (!headers.has("Content-Type") && init.body !== void 0 && typeof init.body === "string" && !(init.body instanceof FormData)) try {
		JSON.parse(init.body);
		headers.set("Content-Type", "application/json");
	} catch {}
	try {
		const res = await fetch(url, {
			...init,
			headers
		});
		if (res.status === 401) {
			const text = await res.clone().text().catch(() => "");
			if (/session|Invalid or expired/i.test(text) || /expired/i.test(text)) clearAdminToken();
		}
		return res;
	} catch (err) {
		throw new Error(networkErrorText(err));
	}
}
var adminAuthService = {
	async login(email, password, remember = true) {
		try {
			const res = await fetch(getApiUrl("/admin/login"), {
				method: "POST",
				headers: { "Content-Type": "application/json" },
				body: JSON.stringify({
					email,
					password
				})
			});
			const data = await parseAdminResponseInner(await res.text(), res.status, res.headers);
			if (data.token) setAdminToken(data.token, remember);
			return { email: data.email };
		} catch (error) {
			return { error: error instanceof Error && error.message ? error.message : "Unable to sign in. Please try again." };
		}
	},
	async me() {
		const token = getAdminToken();
		if (!token) return { ok: false };
		try {
			const res = await fetch(getApiUrl("/admin/me"), { headers: { Authorization: `Bearer ${token}` } });
			return {
				ok: true,
				email: (await parseAdminResponseInner(await res.text(), res.status, res.headers)).email
			};
		} catch {
			clearAdminToken();
			return { ok: false };
		}
	},
	async updateEmail(newEmail, currentPassword) {
		try {
			const res = await adminApiRequest(getApiUrl("/admin/email"), {
				method: "PUT",
				body: JSON.stringify({
					newEmail,
					currentPassword
				})
			});
			const data = await parseAdminResponseInner(await res.text(), res.status, res.headers);
			if (data.token) setAdminToken(data.token, isRememberFlagSet());
			return {
				email: data.email,
				token: data.token
			};
		} catch (error) {
			return { error: error instanceof Error && error.message ? error.message : "Failed to update username." };
		}
	},
	async updatePassword(newPassword, currentPassword) {
		try {
			const res = await adminApiRequest(getApiUrl("/admin/password"), {
				method: "PUT",
				body: JSON.stringify({
					newPassword,
					currentPassword
				})
			});
			const data = await parseAdminResponseInner(await res.text(), res.status, res.headers);
			if (data.token) setAdminToken(data.token, isRememberFlagSet());
			return { token: data.token };
		} catch (error) {
			return { error: error instanceof Error && error.message ? error.message : "Failed to update password." };
		}
	}
};
//#endregion
export { isSessionExpired as a, clearLegacyAdminStorage as i, adminAuthService as n, touchAdminSession as o, clearAdminToken as r, adminApiRequest as t };
