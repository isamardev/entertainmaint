import { i as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { g as Link } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/privacy-policy-CZ0pVl2f.js
var import_jsx_runtime = require_jsx_runtime();
function PrivacyPolicyPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "mx-auto max-w-4xl px-4 py-10",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
			className: "mb-10 border-b-4 border-yellow pb-6",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "eyebrow",
					children: "Legal"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "display text-4xl font-black uppercase md:text-6xl",
					children: "Privacy Policy"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "meta mt-4 text-sm text-muted-foreground",
					children: ["Last updated: ", "1 August 2026"]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-muted-foreground md:text-lg",
					children: "This Privacy Policy explains how Entertainment Trends (“we”, “us”, or “our”) collects, uses, and protects information when you visit entertainmenttrends.example (the “Site”)."
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "prose max-w-none space-y-8 text-foreground/90",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "display mb-3 text-2xl font-black uppercase",
						children: "1. Information we collect"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "We collect two categories of information: (a) information you voluntarily provide, and (b) information automatically collected as you browse the Site." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
						className: "list-disc pl-6 space-y-1 text-muted-foreground",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "Voluntary information:" }), " name, email address or message body when you submit a contact form or email us."] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "Automatic information:" }), " your IP address, browser type, device type, referring website, pages visited, and approximate country/region via standard web server logs."] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "Cookies & storage:" }), " small text files stored in your browser to remember preferences, anonymised analytics sessions, and ad serving settings."] })
						]
					})
				] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "display mb-3 text-2xl font-black uppercase",
					children: "2. How we use information"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
					className: "list-disc pl-6 space-y-1 text-muted-foreground",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "To operate, maintain and improve the Site and our editorial output." }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "To respond to your enquiries, feedback or tips submitted via email or contact forms." }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "To measure anonymous audience engagement with stories and pages." }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "To personalise advertisements and content where permitted by applicable law." }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "To detect, prevent and address security, spam or abuse issues." })
					]
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "display mb-3 text-2xl font-black uppercase",
						children: "3. Cookies & similar technologies"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "We use both first-party and third-party cookies and similar technologies (e.g. local storage, web beacons) to:" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
						className: "list-disc pl-6 space-y-1 text-muted-foreground",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Remember your preferences such as cookie consent." }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Understand how readers engage with the Site via analytics tools." }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Serve and measure relevant advertisements through our advertising partners." })
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-muted-foreground",
						children: "You can control or disable cookies through your browser settings. Doing so may limit some features of the Site."
					})
				] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "display mb-3 text-2xl font-black uppercase",
					children: "4. Third-party services"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-muted-foreground",
					children: "Portions of the Site are served through trusted third-party providers including hosting companies, analytics providers, CDNs, and ad networks. These providers may process your information under their own privacy policies; we only share information with contractual protections for confidentiality and data minimisation. Where required by law, we rely on legitimate interest, consent or other legal bases for such transfers."
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "display mb-3 text-2xl font-black uppercase",
					children: "5. Children under 16"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-muted-foreground",
					children: "The Site is intended for a general audience and is not directed to children under the age of 16. We do not knowingly collect personal information from children under 16. If you believe such information has been provided, please contact us so we can delete it."
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "display mb-3 text-2xl font-black uppercase",
						children: "6. Your rights"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Depending on where you live, you may have rights to:" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
						className: "list-disc pl-6 space-y-1 text-muted-foreground",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Request access to the personal information we hold about you." }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Request correction or deletion of your personal information." }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Object to or restrict certain processing of your information." }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Withdraw consent previously provided at any time." }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Lodge a complaint with a supervisory authority." })
						]
					})
				] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "display mb-3 text-2xl font-black uppercase",
					children: "7. Data retention"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-muted-foreground",
					children: "Contact correspondence is retained for a maximum of 24 months after the last communication unless longer retention is required by law or contractual obligation. Anonymised analytics data is kept in aggregate form indefinitely."
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "display mb-3 text-2xl font-black uppercase",
					children: "8. Changes to this policy"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-muted-foreground",
					children: "We may update this Privacy Policy from time to time in response to legal, regulatory, technical or operational changes. Material changes will be flagged with an updated “Last updated” date at the top of this page, and — where appropriate — a notice on the Site. Your continued use of the Site after changes become effective constitutes acceptance of the revised policy."
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "display mb-3 text-2xl font-black uppercase",
					children: "9. Contact"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
					"If you have any questions, concerns, or requests regarding this policy or how your data is handled, write to us at",
					" ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						className: "text-black underline underline-offset-2 hover:text-yellow",
						href: "mailto:privacy@entertainmenttrends.example",
						children: "privacy@entertainmenttrends.example"
					}),
					", or use the form on our ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						className: "text-black underline underline-offset-2 hover:text-yellow",
						to: "/contact",
						children: "Contact"
					}),
					" page. We will respond within 30 days of a valid request."
				] })] })
			]
		})]
	});
}
//#endregion
export { PrivacyPolicyPage as component };
