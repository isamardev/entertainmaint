import { t as supabase } from "./client-CFA_939g.mjs";
import { i as require_jsx_runtime, r as useQueryClient, t as useQuery } from "../_libs/react+tanstack__react-query.mjs";
import { n as useAuth } from "./AuthContext-0j4f6QBo.mjs";
import { n as toast } from "../_libs/sonner.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/admin.users-Bl9BPxBW.js
var import_jsx_runtime = require_jsx_runtime();
function UsersAdmin() {
	const { isSuperAdmin } = useAuth();
	const qc = useQueryClient();
	const { data = [], isLoading, error } = useQuery({
		queryKey: ["admin-users"],
		queryFn: async () => {
			const { data, error } = await supabase.from("user_roles").select("user_id, role, profile:profiles(display_name, avatar_url)").order("created_at", { ascending: false });
			if (error) throw error;
			return data;
		},
		enabled: isSuperAdmin
	});
	if (!isSuperAdmin) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "text-sm text-black",
		children: "Super Admin only."
	});
	async function setRole(userId, role, add) {
		try {
			if (add) await supabase.from("user_roles").insert({
				user_id: userId,
				role
			});
			else await supabase.from("user_roles").delete().eq("user_id", userId).eq("role", role);
			qc.invalidateQueries({ queryKey: ["admin-users"] });
			toast.success(`Role ${add ? "added" : "removed"} successfully!`);
		} catch (e) {
			toast.error("Failed to update role.");
		}
	}
	const byUser = /* @__PURE__ */ new Map();
	for (const r of data) {
		const cur = byUser.get(r.user_id) ?? {
			roles: [],
			profile: r.profile
		};
		cur.roles.push(r.role);
		byUser.set(r.user_id, cur);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "display mb-4 text-xl font-black uppercase",
			children: "Users & Roles"
		}),
		isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "text-sm text-black border border-gray-200 p-3",
			children: "Loading users…"
		}) : error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "rounded-lg border border-red-200 bg-red-50 p-5",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-start justify-between gap-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "text-sm font-semibold text-red-800",
						children: "Unable to load users"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm text-red-700",
						children: (() => {
							const raw = error?.message;
							if (!raw) return "Please refresh the page and try again.";
							if (raw.length > 220) return raw.slice(0, 220) + "…";
							return raw;
						})()
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => qc.invalidateQueries({ queryKey: ["admin-users"] }),
					className: "shrink-0 rounded-md border border-red-300 bg-white px-3 py-1.5 text-xs font-semibold uppercase tracking-wider text-red-700 hover:bg-red-100",
					children: "Retry"
				})]
			})
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "border border-gray-200",
			children: [[...byUser.entries()].map(([uid, u]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center gap-3 border-b border-gray-200 p-3 last:border-0",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0 flex-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "font-semibold",
						children: u.profile?.display_name ?? uid.slice(0, 8)
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-xs text-black truncate",
						children: uid
					})]
				}), [
					"reader",
					"admin",
					"super_admin"
				].map((r) => {
					const on = u.roles.includes(r);
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => setRole(uid, r, !on),
						className: `px-2 py-1 text-[0.65rem] font-black uppercase tracking-widest ${on ? "bg-black text-white" : "border border-gray-300 text-black hover:border-black"}`,
						children: r.replace("_", " ")
					}, r);
				})]
			}, uid)), byUser.size === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "p-8 text-center text-black",
				children: "No users yet."
			})]
		}),
		!isLoading && !error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-xs text-black mt-4",
			children: "Click a role tag to toggle it for that user."
		})
	] });
}
//#endregion
export { UsersAdmin as component };
