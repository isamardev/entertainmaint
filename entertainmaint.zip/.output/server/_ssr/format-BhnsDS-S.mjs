//#region node_modules/.nitro/vite/services/ssr/assets/format-BhnsDS-S.js
function fullDate(iso) {
	if (!iso) return "";
	return new Date(iso).toLocaleString(void 0, {
		weekday: "short",
		month: "short",
		day: "numeric",
		year: "numeric",
		hour: "numeric",
		minute: "2-digit"
	});
}
function shortDate(iso) {
	if (!iso) return "";
	return new Date(iso).toLocaleDateString(void 0, {
		month: "short",
		day: "numeric",
		year: "numeric"
	});
}
//#endregion
export { shortDate as n, fullDate as t };
