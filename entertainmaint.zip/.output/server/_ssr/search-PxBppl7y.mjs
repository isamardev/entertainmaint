import { m as createFileRoute, p as lazyRouteComponent } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as objectType, r as stringType } from "../_libs/zod.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/search-PxBppl7y.js
var $$splitComponentImporter = () => import("./search-C44gayPw.mjs");
var searchSchema = objectType({ q: stringType().optional().default("") });
var Route = createFileRoute("/search")({
	validateSearch: (s) => searchSchema.parse(s),
	head: () => ({ meta: [{ title: "Search — Entertainment Trends" }, {
		name: "robots",
		content: "noindex"
	}] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
