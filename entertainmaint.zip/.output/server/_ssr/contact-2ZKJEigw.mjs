import { i as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { t as SocialFollowLinks } from "./SocialFollowLinks-DDV9_bnh.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/contact-2ZKJEigw.js
var import_jsx_runtime = require_jsx_runtime();
function ContactPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "mx-auto max-w-4xl px-4 py-10",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
			className: "mb-10 border-b-4 border-yellow pb-6",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "eyebrow",
					children: "Pages"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "display text-4xl font-black uppercase md:text-6xl",
					children: "Contact Us"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-muted-foreground md:text-lg",
					children: "Questions, corrections, story tips, or partnership enquiries? We'd love to hear from you."
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-8 md:grid-cols-[2fr_1fr]",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "prose max-w-none",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "mb-8",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "display mb-3 text-2xl font-black uppercase",
							children: "General Enquiries"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-muted-foreground",
							children: [
								"For general questions, corrections, or feedback about a story, email our editors at",
								" ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
									className: "text-black underline underline-offset-2 hover:text-yellow",
									href: "mailto:editorial@entertainmenttrends.example",
									children: "editorial@entertainmenttrends.example"
								}),
								". We endeavour to respond within 2–3 business days."
							]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "mb-8",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "display mb-3 text-2xl font-black uppercase",
							children: "Story Tips"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-muted-foreground",
							children: [
								"Got a lead or a tip worth covering? Send it to",
								" ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
									className: "text-black underline underline-offset-2 hover:text-yellow",
									href: "mailto:tips@entertainmenttrends.example",
									children: "tips@entertainmenttrends.example"
								}),
								". We treat anonymous submissions with the highest level of confidentiality."
							]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "mb-8",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "display mb-3 text-2xl font-black uppercase",
							children: "Press & Partnerships"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-muted-foreground",
							children: [
								"For brand partnerships, affiliate enquiries, press access, or advertising opportunities, please write to",
								" ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
									className: "text-black underline underline-offset-2 hover:text-yellow",
									href: "mailto:partners@entertainmenttrends.example",
									children: "partners@entertainmenttrends.example"
								}),
								" ",
								"and a member of our commercial team will get back to you within one business day."
							]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "mb-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "display mb-3 text-2xl font-black uppercase",
							children: "Mail"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("address", {
							className: "not-italic text-muted-foreground",
							children: [
								"Entertainment Trends Ltd.",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
								"221B Fleet Street",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
								"London, EC4A 2DY",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
								"United Kingdom"
							]
						})]
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
				className: "space-y-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "border border-border bg-surface p-5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "eyebrow mb-2",
							children: "Follow"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mb-3 text-sm text-muted-foreground",
							children: "Stay connected with Entertainment Trends on your favourite social platform."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SocialFollowLinks, {})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "border border-border bg-surface p-5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "eyebrow mb-2",
						children: "Response times"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
						className: "space-y-1 text-sm text-muted-foreground",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Editorial: 2–3 business days" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Press / Commercial: 1 business day" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Technical issues: 24 hours" })
						]
					})]
				})]
			})]
		})]
	});
}
//#endregion
export { ContactPage as component };
