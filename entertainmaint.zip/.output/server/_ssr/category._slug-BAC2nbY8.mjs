import { i as require_jsx_runtime, t as useQuery } from "../_libs/react+tanstack__react-query.mjs";
import { g as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as articleService } from "./articleService-UhMa44iK.mjs";
import { n as shortDate } from "./format-BhnsDS-S.mjs";
import { t as TrendingSidebar } from "./Sidebar-DKeRiSHS.mjs";
import { t as Route } from "./category._slug-CEjtxhpG.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/category._slug-BAC2nbY8.js
var import_jsx_runtime = require_jsx_runtime();
function LargeCard({ article }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
		to: "/article/$slug",
		params: { slug: article.slug },
		className: "group flex h-full w-full flex-col",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mb-4 aspect-[4/3] w-full overflow-hidden bg-gray-100 border border-gray-100",
				children: article.hero_image_hd || article.hero_image_lq ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: article.hero_image_hd ?? article.hero_image_lq ?? "",
					alt: article.title,
					loading: "lazy",
					decoding: "async",
					className: "h-full w-full object-cover transition-transform duration-700 group-hover:scale-105"
				}) : null
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "display text-2xl font-black uppercase leading-tight group-hover:text-black md:text-3xl",
				children: article.title
			}),
			article.dek ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm text-muted-foreground md:text-base",
				children: article.dek
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "meta mt-3 text-xs text-muted-foreground",
				children: shortDate(article.published_at ?? article.updated_at ?? article.created_at)
			})
		]
	});
}
function SmallCard({ article }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
		to: "/article/$slug",
		params: { slug: article.slug },
		className: "group flex h-full w-full flex-col",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "aspect-[16/10] mb-3 w-full overflow-hidden bg-gray-100 border border-gray-100 md:aspect-[4/3]",
			children: article.hero_image_hd || article.hero_image_lq ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: article.hero_image_hd ?? article.hero_image_lq ?? "",
				alt: article.title,
				loading: "lazy",
				decoding: "async",
				className: "h-full w-full object-cover transition-transform duration-700 group-hover:scale-105"
			}) : null
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex min-w-0 flex-1 flex-col justify-start",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "display text-base font-bold uppercase leading-tight group-hover:text-black md:text-lg",
				children: article.title
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "meta mt-2 text-xs text-muted-foreground",
				children: shortDate(article.published_at ?? article.updated_at ?? article.created_at)
			})]
		})]
	});
}
function LatestHorizontal({ article }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
		to: "/article/$slug",
		params: { slug: article.slug },
		className: "group flex w-full flex-col sm:items-stretch sm:flex-row sm:gap-5",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "aspect-[16/10] mb-3 w-full overflow-hidden bg-gray-100 border border-gray-100 sm:mb-0 sm:w-2/5 sm:shrink-0 md:w-1/3",
			children: article.hero_image_hd || article.hero_image_lq ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: article.hero_image_hd ?? article.hero_image_lq ?? "",
				alt: article.title,
				loading: "lazy",
				decoding: "async",
				className: "h-full w-full object-cover transition-transform duration-700 group-hover:scale-105"
			}) : null
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "flex min-w-0 flex-1 sm:items-center",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "min-h-0 w-full",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "display text-xl font-black uppercase leading-tight group-hover:text-black md:text-2xl",
					children: article.title
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "meta mt-3 text-xs text-muted-foreground md:text-sm",
					children: shortDate(article.published_at ?? article.updated_at ?? article.created_at)
				})]
			})
		})]
	});
}
function SplitGroup({ index, three }) {
	if (index % 2 === 0) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "relative pb-10",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-col gap-6 md:min-h-[560px] md:grid md:items-stretch md:gap-5 md:grid-cols-[3fr_2fr]",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex h-full min-h-0 flex-col",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LargeCard, { article: three[0] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-6 block border-b border-gray-400 md:hidden",
					"aria-hidden": "true"
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex h-full min-h-0 flex-col justify-between gap-6 md:gap-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "min-h-0 flex-1 flex items-stretch pb-6 md:pb-5 border-b border-gray-400",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "w-full",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SmallCard, { article: three[1] })
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "min-h-0 flex-1 flex items-stretch",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "w-full",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SmallCard, { article: three[2] })
					})
				})]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "col-span-full mt-6 border-b border-gray-400",
			"aria-hidden": "true"
		})]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "relative pb-10",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-col gap-6 md:min-h-[560px] md:grid md:items-stretch md:gap-5 md:grid-cols-[2fr_3fr]",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex h-full min-h-0 flex-col justify-between gap-6 md:gap-5 md:order-1 order-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "min-h-0 flex-1 flex items-stretch pb-6 md:pb-5 border-b border-gray-400",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "w-full",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SmallCard, { article: three[0] })
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "min-h-0 flex-1 flex items-stretch",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "w-full",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SmallCard, { article: three[1] })
					})
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex h-full min-h-0 flex-col md:order-2 order-1",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LargeCard, { article: three[2] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-6 block border-b border-gray-400 md:hidden",
					"aria-hidden": "true"
				})]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "col-span-full mt-6 border-b border-gray-400",
			"aria-hidden": "true"
		})]
	});
}
function CategoryPage() {
	const { category } = Route.useLoaderData();
	const { data, isLoading } = useQuery({
		queryKey: ["category-page-full", category.slug],
		queryFn: () => articleService.listPublished({
			categorySlug: category.slug,
			limit: 200,
			offset: 0
		}),
		staleTime: 6e4
	});
	const all = data?.data ?? [];
	const fullGroups = [];
	let i = 0;
	while (i + 2 < all.length) {
		fullGroups.push([
			all[i],
			all[i + 1],
			all[i + 2]
		]);
		i += 3;
	}
	const latest = all.slice(i);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
		className: "mb-10 border-b-4 border-yellow pb-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "eyebrow",
				children: "Section"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "display text-4xl font-black uppercase md:text-6xl",
				children: category.name
			}),
			category.description && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-muted-foreground",
				children: category.description
			})
		]
	}), isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-10 lg:grid-cols-[minmax(0,1fr)_320px]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "space-y-10",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-[620px] animate-pulse bg-surface" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-[620px] animate-pulse bg-surface" })]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "hidden h-[600px] animate-pulse bg-surface lg:block" })]
	}) : all.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-10 lg:grid-cols-[minmax(0,1fr)_320px]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "border border-border bg-surface p-10 text-center text-muted-foreground",
			children: [
				"No stories in ",
				category.name,
				" yet."
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "hidden lg:block",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "sticky top-24",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TrendingSidebar, {})
			})
		})]
	}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-10 lg:grid-cols-[minmax(0,1fr)_320px]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "min-w-0",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "space-y-10",
				children: fullGroups.map((three, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SplitGroup, {
					index: idx,
					three
				}, `grp-${three[0].id}-${idx}`))
			}), latest.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "pt-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mb-6 border-b-4 border-yellow pb-2",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "display text-2xl font-black uppercase md:text-3xl",
						children: "Latest"
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid grid-cols-1",
					children: latest.map((a, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: idx < latest.length - 1 ? "py-6 border-b border-gray-400" : "py-6",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LatestHorizontal, { article: a })
					}, a.id))
				})]
			}) : null]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "hidden lg:block",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "sticky top-24",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TrendingSidebar, {})
			})
		})]
	})] });
}
//#endregion
export { CategoryPage as component };
