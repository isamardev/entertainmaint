import { i as require_jsx_runtime, t as useQuery } from "../_libs/react+tanstack__react-query.mjs";
import { r as getPublicPrivacyPolicy, t as DEFAULT_PRIVACY_POLICY } from "./privacyService-DHCqyMEH.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/privacy-policy-CkeKZCcq.js
var import_jsx_runtime = require_jsx_runtime();
function PrivacyPolicyPage() {
	const { data: policy = DEFAULT_PRIVACY_POLICY } = useQuery({
		queryKey: ["privacy-policy"],
		queryFn: getPublicPrivacyPolicy,
		staleTime: 6e4
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "mx-auto max-w-4xl px-4 py-10",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
			className: "mb-10 border-b-4 border-yellow pb-6",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "eyebrow",
					children: "Legal"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "article-headline font-serif text-3xl sm:text-4xl md:text-5xl font-bold leading-tight text-neutral-900 mt-2",
					children: policy.title || "Privacy Policy"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "meta mt-4 text-xs text-muted-foreground",
					children: ["Last updated: ", policy.last_updated || "October 2026"]
				}),
				policy.intro && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 text-neutral-700 md:text-lg leading-relaxed font-sans",
					children: policy.intro
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "article-body prose max-w-none space-y-6 text-[16px] md:text-[16.5px] leading-[1.7] text-neutral-900 font-sans prose-headings:font-bold prose-headings:font-serif prose-headings:text-neutral-900 prose-h2:text-2xl prose-h2:mt-8 prose-h2:mb-3 prose-p:my-4 prose-ul:list-disc prose-ul:pl-6 prose-li:my-1.5",
			dangerouslySetInnerHTML: { __html: policy.content }
		})]
	});
}
//#endregion
export { PrivacyPolicyPage as component };
