globalThis.__nitro_main__ = import.meta.url;
import { a as toEventHandler, c as NodeResponse, i as defineLazyEventHandler, l as serve, n as HTTPError, r as defineHandler, t as H3Core } from "./_libs/h3+rou3+srvx.mjs";
import { i as withoutTrailingSlash, n as joinURL, r as withLeadingSlash, t as decodePath } from "./_libs/ufo.mjs";
import { promises } from "node:fs";
import { fileURLToPath } from "node:url";
import { dirname, resolve } from "node:path";
//#region #nitro-vite-setup
function lazyService(loader) {
	let promise, mod;
	return { fetch(req) {
		if (mod) return mod.fetch(req);
		if (!promise) promise = loader().then((_mod) => mod = _mod.default || _mod);
		return promise.then((mod) => mod.fetch(req));
	} };
}
var services = { ["ssr"]: lazyService(() => import("./_ssr/ssr.mjs")) };
globalThis.__nitro_vite_envs__ = services;
//#endregion
//#region node_modules/nitro/dist/runtime/internal/route-rules.mjs
var headers = ((m) => function headersRouteRule(event) {
	for (const [key, value] of Object.entries(m.options || {})) event.res.headers.set(key, value);
});
//#endregion
//#region #nitro/virtual/public-assets-data
var public_assets_data_default = {
	"/favicon.ico": {
		"type": "image/vnd.microsoft.icon",
		"etag": "\"4f95-3RXc3p2mhEAs1WBwaIvE0Y0uu0Y\"",
		"mtime": "2026-07-03T00:51:12.000Z",
		"size": 20373,
		"path": "../public/favicon.ico"
	},
	"/assets/admin-wBpiBSV8.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"41d-qgf4wa2nXkUZCuOy4NDwzQ7PLWI\"",
		"mtime": "2026-08-23T15:42:45.680Z",
		"size": 1053,
		"path": "../public/assets/admin-wBpiBSV8.js"
	},
	"/assets/admin.categories-CURjIDsQ.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"12bc-kNCV5vFueOViOWCMCs+OFm3Kh20\"",
		"mtime": "2026-08-23T15:42:45.792Z",
		"size": 4796,
		"path": "../public/assets/admin.categories-CURjIDsQ.js"
	},
	"/assets/admin.edit._id-CLn2Kxkr.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"5ee-z/tvaKjXgv4tvb43pORhVqS+5SE\"",
		"mtime": "2026-08-23T15:42:45.823Z",
		"size": 1518,
		"path": "../public/assets/admin.edit._id-CLn2Kxkr.js"
	},
	"/logo.png": {
		"type": "image/png",
		"etag": "\"53b7-zukX+b6ie3tcWsO5MKPTu53xOkU\"",
		"mtime": "2025-01-17T06:23:26.000Z",
		"size": 21431,
		"path": "../public/logo.png"
	},
	"/assets/admin.index-TEYN73H_.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1076-S7orss49umzotBrt8F27f2va19w\"",
		"mtime": "2026-08-23T15:42:45.825Z",
		"size": 4214,
		"path": "../public/assets/admin.index-TEYN73H_.js"
	},
	"/assets/admin.login-CPw4oFea.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"c1-rh+igyqg1kYfMVTh9ZBT2oNk9Sk\"",
		"mtime": "2026-08-23T15:42:45.827Z",
		"size": 193,
		"path": "../public/assets/admin.login-CPw4oFea.js"
	},
	"/assets/admin.new-DpOfC_yl.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"244-k0FRzpK88d1uLOgqov89vgQHfeQ\"",
		"mtime": "2026-08-23T15:42:45.829Z",
		"size": 580,
		"path": "../public/assets/admin.new-DpOfC_yl.js"
	},
	"/assets/admin.settings-DKxfFZ3s.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"10f9-h3iu2MtwooHC8q7gZMA1b1rI1HE\"",
		"mtime": "2026-08-23T15:42:45.834Z",
		"size": 4345,
		"path": "../public/assets/admin.settings-DKxfFZ3s.js"
	},
	"/assets/admin.socials-m-Eoljyv.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"d99-Bookt+0XeeFGHz4lYNNL8R6gJVE\"",
		"mtime": "2026-08-23T15:42:45.837Z",
		"size": 3481,
		"path": "../public/assets/admin.socials-m-Eoljyv.js"
	},
	"/assets/admin.users-yNua0Ghi.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"b65-ygEOD6vCzioBGfn+w1QoDHny33A\"",
		"mtime": "2026-08-23T15:42:45.839Z",
		"size": 2917,
		"path": "../public/assets/admin.users-yNua0Ghi.js"
	},
	"/assets/AdminLoginForm-DcDxbEKW.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"8d9-0OW/blbiYUVBA6N/1GVqPggM9n4\"",
		"mtime": "2026-08-23T15:42:45.663Z",
		"size": 2265,
		"path": "../public/assets/AdminLoginForm-DcDxbEKW.js"
	},
	"/assets/article._slug-B6mtXd1n.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"439d-v9rCnvdbAhaThKYgfPcu62FpObo\"",
		"mtime": "2026-08-23T15:42:45.841Z",
		"size": 17309,
		"path": "../public/assets/article._slug-B6mtXd1n.js"
	},
	"/assets/article._slug-DdG22EH4.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"198-rLrtE4IYlv86tWPBJvku3pETJEs\"",
		"mtime": "2026-08-23T15:42:45.842Z",
		"size": 408,
		"path": "../public/assets/article._slug-DdG22EH4.js"
	},
	"/assets/article._slug-Dz6kTjYA.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"a5-fRNbX9cp3iFyD1pX9fG3W1faqAQ\"",
		"mtime": "2026-08-23T15:42:45.844Z",
		"size": 165,
		"path": "../public/assets/article._slug-Dz6kTjYA.js"
	},
	"/assets/ArticleCard-DMKeuwEl.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"98d-yK0sneGT7Ua4wTfk1bLii3KEuE4\"",
		"mtime": "2026-08-23T15:42:45.669Z",
		"size": 2445,
		"path": "../public/assets/ArticleCard-DMKeuwEl.js"
	},
	"/assets/category._slug-C9GJtnL7.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1bbd-C77XK+b3B1j04zBfmQmmSLJh5kA\"",
		"mtime": "2026-08-23T15:42:45.847Z",
		"size": 7101,
		"path": "../public/assets/category._slug-C9GJtnL7.js"
	},
	"/assets/ArticleForm-D6lZs8yE.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"6f56-UcJuv8Xcyg4iGSpTId8eRj8S1MM\"",
		"mtime": "2026-08-23T15:42:45.673Z",
		"size": 28502,
		"path": "../public/assets/ArticleForm-D6lZs8yE.js"
	},
	"/assets/category._slug-CoYcrX9_.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"ab-st4BkYYTAI9lSNgOKdhaIE5SZcg\"",
		"mtime": "2026-08-23T15:42:45.848Z",
		"size": 171,
		"path": "../public/assets/category._slug-CoYcrX9_.js"
	},
	"/assets/auth-5ifUq3oF.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"101-PbJ1kDd9bFhTi4vvgZQhehM3Bmw\"",
		"mtime": "2026-08-23T15:42:45.845Z",
		"size": 257,
		"path": "../public/assets/auth-5ifUq3oF.js"
	},
	"/assets/category._slug-Dz6kTjYA.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"a5-fRNbX9cp3iFyD1pX9fG3W1faqAQ\"",
		"mtime": "2026-08-23T15:42:45.851Z",
		"size": 165,
		"path": "../public/assets/category._slug-Dz6kTjYA.js"
	},
	"/assets/contact-DM6uhWOj.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"df4-NP5T2PSBWd6Z+zed/9nbWbhyfgI\"",
		"mtime": "2026-08-23T15:42:45.853Z",
		"size": 3572,
		"path": "../public/assets/contact-DM6uhWOj.js"
	},
	"/assets/createLucideIcon-BM57YfsK.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"4cc-DUqSTsig1NpDR4+QaUysMUweQLQ\"",
		"mtime": "2026-08-23T15:42:45.855Z",
		"size": 1228,
		"path": "../public/assets/createLucideIcon-BM57YfsK.js"
	},
	"/assets/DeleteModal-CwxW5hEg.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"57b-Uav8RDunBUA7Qr9HzEIlAnA5AME\"",
		"mtime": "2026-08-23T15:42:45.675Z",
		"size": 1403,
		"path": "../public/assets/DeleteModal-CwxW5hEg.js"
	},
	"/assets/format-Cgz7pC5i.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"11e-wPunfWijhpwRrvLPvgZUvL0YwOE\"",
		"mtime": "2026-08-23T15:42:45.856Z",
		"size": 286,
		"path": "../public/assets/format-Cgz7pC5i.js"
	},
	"/assets/jsx-runtime-B6jttwkn.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1b3-RCFZqooc64bULOL98nC1ZOsYIUA\"",
		"mtime": "2026-08-23T15:42:45.858Z",
		"size": 435,
		"path": "../public/assets/jsx-runtime-B6jttwkn.js"
	},
	"/assets/link-1uhwThZ0.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"5970-JwgkywUK09d0QU/YxHkpxEa6Wjc\"",
		"mtime": "2026-08-23T15:42:45.859Z",
		"size": 22896,
		"path": "../public/assets/link-1uhwThZ0.js"
	},
	"/assets/react-CES6V0Ih.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1d6c-KAzDNZE7meu8CgSmgzeb9tRgDSk\"",
		"mtime": "2026-08-23T15:42:45.895Z",
		"size": 7532,
		"path": "../public/assets/react-CES6V0Ih.js"
	},
	"/assets/react-dom-DWuVlKIp.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"dfb-QEoVYsL2hmnMGv010An3ZidnyG8\"",
		"mtime": "2026-08-23T15:42:45.898Z",
		"size": 3579,
		"path": "../public/assets/react-dom-DWuVlKIp.js"
	},
	"/assets/rolldown-runtime-Bh1tDfsg.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"237-RWMfWL++Hyx/oSoFmTJgBJkEveY\"",
		"mtime": "2026-08-23T15:42:45.907Z",
		"size": 567,
		"path": "../public/assets/rolldown-runtime-Bh1tDfsg.js"
	},
	"/assets/privacy-policy-DdKUqQsO.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1b66-YMZtnMDWyWPQVYeiqtJVvRBl6NU\"",
		"mtime": "2026-08-23T15:42:45.893Z",
		"size": 7014,
		"path": "../public/assets/privacy-policy-DdKUqQsO.js"
	},
	"/assets/matchContext-8PLJ5guC.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"32b-zxnE91z9ZPaCfXAQMYGvpLRyc6k\"",
		"mtime": "2026-08-23T15:42:45.861Z",
		"size": 811,
		"path": "../public/assets/matchContext-8PLJ5guC.js"
	},
	"/assets/safe-fetch-N9uVjNP5.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1009-8htghhr1843Syr4LNVwJKBUa1pQ\"",
		"mtime": "2026-08-23T15:42:45.914Z",
		"size": 4105,
		"path": "../public/assets/safe-fetch-N9uVjNP5.js"
	},
	"/assets/search-P5WFNT03.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"710-POpn7pyS9icUsNRPFIEVL27aMrc\"",
		"mtime": "2026-08-23T15:42:45.924Z",
		"size": 1808,
		"path": "../public/assets/search-P5WFNT03.js"
	},
	"/assets/Skeleton-Bwrne7TY.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"224-HxEuB32coaeFqB7mx0GCsRXGUh8\"",
		"mtime": "2026-08-23T15:42:45.678Z",
		"size": 548,
		"path": "../public/assets/Skeleton-Bwrne7TY.js"
	},
	"/assets/styles-BITXpHSC.css": {
		"type": "text/css; charset=utf-8",
		"etag": "\"14f0f-nERFTrHIOAcQoteLS2iNQJfME/c\"",
		"mtime": "2026-08-23T15:42:45.928Z",
		"size": 85775,
		"path": "../public/assets/styles-BITXpHSC.css"
	},
	"/assets/index-C6Faaqev.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"a28a9-L5SEJXGzPNraPoLYf17bZzxgUNk\"",
		"mtime": "2026-08-23T15:42:45.662Z",
		"size": 665769,
		"path": "../public/assets/index-C6Faaqev.js"
	},
	"/assets/Sidebar-4OqjeOwP.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"479-29zHbqSvBpepyyt97bPX2LR0jCw\"",
		"mtime": "2026-08-23T15:42:45.676Z",
		"size": 1145,
		"path": "../public/assets/Sidebar-4OqjeOwP.js"
	},
	"/assets/routes-DxZHbxta.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"21de-7O+2iXOkZjn6oZ0CSOoZY3GKRnE\"",
		"mtime": "2026-08-23T15:42:45.910Z",
		"size": 8670,
		"path": "../public/assets/routes-DxZHbxta.js"
	},
	"/assets/useRouter-vFGG9jIg.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2d3-knbzZI70tM5zD9bAqwcnOrMp0TE\"",
		"mtime": "2026-08-23T15:42:45.926Z",
		"size": 723,
		"path": "../public/assets/useRouter-vFGG9jIg.js"
	}
};
//#endregion
//#region #nitro/virtual/public-assets-node
function readAsset(id) {
	const serverDir = dirname(fileURLToPath(globalThis.__nitro_main__));
	return promises.readFile(resolve(serverDir, public_assets_data_default[id].path));
}
//#endregion
//#region #nitro/virtual/public-assets
var publicAssetBases = {};
function isPublicAssetURL(id = "") {
	if (public_assets_data_default[id]) return true;
	for (const base in publicAssetBases) if (id.startsWith(base)) return true;
	return false;
}
function getAsset(id) {
	return public_assets_data_default[id];
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/static.mjs
var METHODS = /* @__PURE__ */ new Set(["HEAD", "GET"]);
var EncodingMap = {
	gzip: ".gz",
	br: ".br",
	zstd: ".zst"
};
var static_default = defineHandler((event) => {
	if (event.req.method && !METHODS.has(event.req.method)) return;
	let id = decodePath(withLeadingSlash(withoutTrailingSlash(event.url.pathname)));
	let asset;
	const encodings = [...(event.req.headers.get("accept-encoding") || "").split(",").map((e) => EncodingMap[e.trim()]).filter(Boolean).sort(), ""];
	for (const encoding of encodings) for (const _id of [id + encoding, joinURL(id, "index.html" + encoding)]) {
		const _asset = getAsset(_id);
		if (_asset) {
			asset = _asset;
			id = _id;
			break;
		}
	}
	if (!asset) {
		if (isPublicAssetURL(id)) {
			event.res.headers.delete("Cache-Control");
			throw new HTTPError({ status: 404 });
		}
		return;
	}
	if (encodings.length > 1) event.res.headers.append("Vary", "Accept-Encoding");
	if (event.req.headers.get("if-none-match") === asset.etag) {
		event.res.status = 304;
		event.res.statusText = "Not Modified";
		return "";
	}
	const ifModifiedSinceH = event.req.headers.get("if-modified-since");
	const mtimeDate = new Date(asset.mtime);
	if (ifModifiedSinceH && asset.mtime && new Date(ifModifiedSinceH) >= mtimeDate) {
		event.res.status = 304;
		event.res.statusText = "Not Modified";
		return "";
	}
	if (asset.type) event.res.headers.set("Content-Type", asset.type);
	if (asset.etag && !event.res.headers.has("ETag")) event.res.headers.set("ETag", asset.etag);
	if (asset.mtime && !event.res.headers.has("Last-Modified")) event.res.headers.set("Last-Modified", mtimeDate.toUTCString());
	if (asset.encoding && !event.res.headers.has("Content-Encoding")) event.res.headers.set("Content-Encoding", asset.encoding);
	if (asset.size > 0 && !event.res.headers.has("Content-Length")) event.res.headers.set("Content-Length", asset.size.toString());
	return readAsset(id);
});
//#endregion
//#region #nitro/virtual/routing
var findRouteRules = /* @__PURE__ */ (() => {
	const $0 = [{
		name: "headers",
		route: "/assets/**",
		handler: headers,
		options: { "cache-control": "public, max-age=31536000, immutable" }
	}];
	return (m, p) => {
		let r = [];
		if (p.charCodeAt(p.length - 1) === 47) p = p.slice(0, -1) || "/";
		let s = p.split("/");
		if (s.length > 1) {
			if (s[1] === "assets") r.unshift({
				data: $0,
				params: { "_": s.slice(2).join("/") }
			});
		}
		return r;
	};
})();
var _lazy_bZpehs = defineLazyEventHandler(() => import("./_chunks/ssr-renderer.mjs"));
var findRoute = /* @__PURE__ */ (() => {
	const data = {
		route: "/**",
		handler: _lazy_bZpehs
	};
	return ((_m, p) => {
		return {
			data,
			params: { "_": p.slice(1) }
		};
	});
})();
var globalMiddleware = [toEventHandler(static_default)].filter(Boolean);
//#endregion
//#region node_modules/nitro/dist/runtime/internal/error/prod.mjs
var errorHandler = (error, event) => {
	const res = defaultHandler(error, event);
	return new NodeResponse(typeof res.body === "string" ? res.body : JSON.stringify(res.body, null, 2), res);
};
function defaultHandler(error, event) {
	const unhandled = error.unhandled ?? !HTTPError.isError(error);
	const { status = 500, statusText = "" } = unhandled ? {} : error;
	if (status === 404) {
		const url = event.url || new URL(event.req.url);
		const baseURL = "/";
		if (/^\/[^/]/.test(baseURL) && !url.pathname.startsWith(baseURL)) return {
			status: 302,
			headers: new Headers({ location: `${baseURL}${url.pathname.slice(1)}${url.search}` })
		};
	}
	const headers = new Headers(unhandled ? {} : error.headers);
	headers.set("content-type", "application/json; charset=utf-8");
	return {
		status,
		statusText,
		headers,
		body: {
			error: true,
			...unhandled ? {
				status,
				unhandled: true
			} : typeof error.toJSON === "function" ? error.toJSON() : {
				status,
				statusText,
				message: error.message
			}
		}
	};
}
//#endregion
//#region #nitro/virtual/error-handler
var errorHandlers = [errorHandler];
async function error_handler_default(error, event) {
	for (const handler of errorHandlers) try {
		const response = await handler(error, event, { defaultHandler });
		if (response) return response;
	} catch (error) {
		console.error(error);
	}
}
//#endregion
//#region #nitro/virtual/app
function createNitroApp() {
	const captureError = (error, errorCtx) => {
		if (errorCtx?.event) {
			const errors = errorCtx.event.req.context?.nitro?.errors;
			if (errors) errors.push({
				error,
				context: errorCtx
			});
		}
	};
	const h3App = createH3App({ onError(error, event) {
		return error_handler_default(error, event);
	} });
	let appHandler = (req) => {
		req.context ||= {};
		req.context.nitro = req.context.nitro || { errors: [] };
		return h3App.fetch(req);
	};
	return {
		fetch: appHandler,
		h3: h3App,
		hooks: void 0,
		captureError
	};
}
function createH3App(config) {
	const h3App = new H3Core(config);
	h3App["~findRoute"] = (event) => findRoute(event.req.method, event.url.pathname);
	h3App["~middleware"].push(...globalMiddleware);
	h3App["~getMiddleware"] = (event, route) => {
		const pathname = event.url.pathname;
		const method = event.req.method;
		const middleware = [];
		const routeRules = getRouteRules(method, pathname);
		event.context.routeRules = routeRules?.routeRules;
		if (routeRules?.routeRuleMiddleware.length) middleware.push(...routeRules.routeRuleMiddleware);
		middleware.push(...h3App["~middleware"]);
		if (route?.data?.middleware?.length) middleware.push(...route.data.middleware);
		return middleware;
	};
	return h3App;
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/app.mjs
var APP_ID = "default";
function useNitroApp() {
	let instance = useNitroApp._instance;
	if (instance) return instance;
	instance = useNitroApp._instance = createNitroApp();
	globalThis.__nitro__ = globalThis.__nitro__ || {};
	globalThis.__nitro__[APP_ID] = instance;
	return instance;
}
function getRouteRules(method, pathname) {
	const m = findRouteRules(method, pathname);
	if (!m?.length) return { routeRuleMiddleware: [] };
	const routeRules = {};
	for (const layer of m) for (const rule of layer.data) {
		const currentRule = routeRules[rule.name];
		if (currentRule) {
			if (rule.options === false) {
				delete routeRules[rule.name];
				continue;
			}
			if (typeof currentRule.options === "object" && typeof rule.options === "object") currentRule.options = {
				...currentRule.options,
				...rule.options
			};
			else currentRule.options = rule.options;
			currentRule.route = rule.route;
			currentRule.params = {
				...currentRule.params,
				...layer.params
			};
		} else if (rule.options !== false) routeRules[rule.name] = {
			...rule,
			params: layer.params
		};
	}
	const middleware = [];
	const orderedRules = Object.values(routeRules).sort((a, b) => (a.handler?.order || 0) - (b.handler?.order || 0));
	for (const rule of orderedRules) {
		if (rule.options === false || !rule.handler) continue;
		middleware.push(rule.handler(rule));
	}
	return {
		routeRules,
		routeRuleMiddleware: middleware
	};
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/error/hooks.mjs
function _captureError(error, type) {
	console.error(`[${type}]`, error);
	useNitroApp().captureError?.(error, { tags: [type] });
}
function trapUnhandledErrors() {
	process.on("unhandledRejection", (error) => _captureError(error, "unhandledRejection"));
	process.on("uncaughtException", (error) => _captureError(error, "uncaughtException"));
}
//#endregion
//#region #nitro/virtual/tracing
var tracingSrvxPlugins = [];
//#endregion
//#region node_modules/nitro/dist/presets/node/runtime/node-server.mjs
var _parsedPort = Number.parseInt(process.env.NITRO_PORT ?? process.env.PORT ?? "");
var port = Number.isNaN(_parsedPort) ? 3e3 : _parsedPort;
var host = process.env.NITRO_HOST || process.env.HOST;
var cert = process.env.NITRO_SSL_CERT;
var key = process.env.NITRO_SSL_KEY;
var nitroApp = useNitroApp();
serve({
	port,
	hostname: host,
	tls: cert && key ? {
		cert,
		key
	} : void 0,
	fetch: nitroApp.fetch,
	plugins: [...tracingSrvxPlugins]
});
trapUnhandledErrors();
var node_server_default = {};
//#endregion
export { node_server_default as default };
