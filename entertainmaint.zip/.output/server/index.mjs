globalThis.__nitro_main__ = import.meta.url;
import { a as toEventHandler, c as NodeResponse, i as defineLazyEventHandler, l as serve, n as HTTPError, r as defineHandler, t as H3Core } from "./_libs/h3+rou3+srvx.mjs";
import { i as withoutTrailingSlash, n as joinURL, r as withLeadingSlash, t as decodePath } from "./_libs/ufo.mjs";
import { promises } from "node:fs";
import { fileURLToPath } from "node:url";
import { dirname, resolve } from "node:path";
//#region #nitro-vite-setup
function lazyService(loader) {
	let promise, mod;
	return { fetch(req) {
		if (mod) return mod.fetch(req);
		if (!promise) promise = loader().then((_mod) => mod = _mod.default || _mod);
		return promise.then((mod) => mod.fetch(req));
	} };
}
var services = { ["ssr"]: lazyService(() => import("./_ssr/ssr.mjs")) };
globalThis.__nitro_vite_envs__ = services;
//#endregion
//#region node_modules/nitro/dist/runtime/internal/route-rules.mjs
var headers = ((m) => function headersRouteRule(event) {
	for (const [key, value] of Object.entries(m.options || {})) event.res.headers.set(key, value);
});
//#endregion
//#region #nitro/virtual/public-assets-data
var public_assets_data_default = {
	"/assets/admin-GLjW4H2Y.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"41d-fT87eR/1s+IUAnW1smDYlO0pLWg\"",
		"mtime": "2026-10-07T16:13:02.218Z",
		"size": 1053,
		"path": "../public/assets/admin-GLjW4H2Y.js"
	},
	"/assets/admin.categories-ChjCagDd.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"12bc-Ehs3SPxdUGJbaxkQon47YxvhH4o\"",
		"mtime": "2026-10-07T16:13:02.219Z",
		"size": 4796,
		"path": "../public/assets/admin.categories-ChjCagDd.js"
	},
	"/assets/admin.edit._id-DxwimH1K.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"5ee-EPvygUJgDvljDk+YheqDEr9fIHs\"",
		"mtime": "2026-10-07T16:13:02.221Z",
		"size": 1518,
		"path": "../public/assets/admin.edit._id-DxwimH1K.js"
	},
	"/assets/admin.login-DreXjj_l.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"c1-28P/Peoug3LKPtTlRbgwFrcXQCM\"",
		"mtime": "2026-10-07T16:13:02.225Z",
		"size": 193,
		"path": "../public/assets/admin.login-DreXjj_l.js"
	},
	"/logo.png": {
		"type": "image/png",
		"etag": "\"53b7-zukX+b6ie3tcWsO5MKPTu53xOkU\"",
		"mtime": "2025-01-17T06:23:26.000Z",
		"size": 21431,
		"path": "../public/logo.png"
	},
	"/assets/admin.index-DTUHw5CY.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"107e-HAN6lmE3ovTcYg7DX5a9BBTn9DA\"",
		"mtime": "2026-10-07T16:13:02.222Z",
		"size": 4222,
		"path": "../public/assets/admin.index-DTUHw5CY.js"
	},
	"/assets/admin.new-BTVHSdAJ.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"244-QEBflq0la3LF1fn/GSWWJEewqZ4\"",
		"mtime": "2026-10-07T16:13:02.226Z",
		"size": 580,
		"path": "../public/assets/admin.new-BTVHSdAJ.js"
	},
	"/assets/admin.privacy-Cx12HreD.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"29ad-+1umrXWIUsw0iXqhH0BF4+V6mlA\"",
		"mtime": "2026-10-07T16:13:02.227Z",
		"size": 10669,
		"path": "../public/assets/admin.privacy-Cx12HreD.js"
	},
	"/assets/admin.settings-Dlj8gQ8J.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"16f1-SraXDXP8TkG4+7qODBwVSuMa4Wk\"",
		"mtime": "2026-10-07T16:13:02.229Z",
		"size": 5873,
		"path": "../public/assets/admin.settings-Dlj8gQ8J.js"
	},
	"/assets/admin.socials-yIxocHOA.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"d99-m/H5O1S/3owfj/GXgH9RZSPT8sU\"",
		"mtime": "2026-10-07T16:13:02.230Z",
		"size": 3481,
		"path": "../public/assets/admin.socials-yIxocHOA.js"
	},
	"/assets/admin.users-CQCs1IYt.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"b65-k8FoH2AsIGS37oVEhrmXNoc8Kgc\"",
		"mtime": "2026-10-07T16:13:02.231Z",
		"size": 2917,
		"path": "../public/assets/admin.users-CQCs1IYt.js"
	},
	"/assets/AdminLoginForm-Dorsuw4N.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"aa0-qfmpZmfjbLPLmV1CrQkWSR+TLcQ\"",
		"mtime": "2026-10-07T16:13:02.119Z",
		"size": 2720,
		"path": "../public/assets/AdminLoginForm-Dorsuw4N.js"
	},
	"/assets/article._slug-C0lX8U47.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"8455-+WmyqAW76lmHlcvaRAyObeVycs0\"",
		"mtime": "2026-10-07T16:13:02.236Z",
		"size": 33877,
		"path": "../public/assets/article._slug-C0lX8U47.js"
	},
	"/assets/article._slug-DdG22EH4.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"198-rLrtE4IYlv86tWPBJvku3pETJEs\"",
		"mtime": "2026-10-07T16:13:02.237Z",
		"size": 408,
		"path": "../public/assets/article._slug-DdG22EH4.js"
	},
	"/assets/article._slug-Dz6kTjYA.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"a5-fRNbX9cp3iFyD1pX9fG3W1faqAQ\"",
		"mtime": "2026-10-07T16:13:02.238Z",
		"size": 165,
		"path": "../public/assets/article._slug-Dz6kTjYA.js"
	},
	"/assets/ArticleCard-BXoO-lbw.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"a5f-wO3JnGN01aER5ADIET/epqumLKg\"",
		"mtime": "2026-10-07T16:13:02.131Z",
		"size": 2655,
		"path": "../public/assets/ArticleCard-BXoO-lbw.js"
	},
	"/assets/ArticleForm-BvhF6kJN.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"b56e-iTunpCv7zgf4WiqP4BldP5NyBAk\"",
		"mtime": "2026-10-07T16:13:02.133Z",
		"size": 46446,
		"path": "../public/assets/ArticleForm-BvhF6kJN.js"
	},
	"/assets/auth-4mRWZzXR.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"101-WUznzriKjMBpDUaYv846DPC59Wo\"",
		"mtime": "2026-10-07T16:13:02.247Z",
		"size": 257,
		"path": "../public/assets/auth-4mRWZzXR.js"
	},
	"/assets/category._slug-B9laFqzT.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1bb8-ZBYvHqURhXpe7LHZhdO8NnOgUpI\"",
		"mtime": "2026-10-07T16:13:02.304Z",
		"size": 7096,
		"path": "../public/assets/category._slug-B9laFqzT.js"
	},
	"/assets/category._slug-CoYcrX9_.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"ab-st4BkYYTAI9lSNgOKdhaIE5SZcg\"",
		"mtime": "2026-10-07T16:13:02.305Z",
		"size": 171,
		"path": "../public/assets/category._slug-CoYcrX9_.js"
	},
	"/assets/category._slug-Dz6kTjYA.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"a5-fRNbX9cp3iFyD1pX9fG3W1faqAQ\"",
		"mtime": "2026-10-07T16:13:02.312Z",
		"size": 165,
		"path": "../public/assets/category._slug-Dz6kTjYA.js"
	},
	"/assets/contact-BKCPpU1b.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"df4-Z11m+HkU1DnuYJnc/VgF9sawWv0\"",
		"mtime": "2026-10-07T16:13:02.313Z",
		"size": 3572,
		"path": "../public/assets/contact-BKCPpU1b.js"
	},
	"/assets/createLucideIcon-BM57YfsK.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"4cc-DUqSTsig1NpDR4+QaUysMUweQLQ\"",
		"mtime": "2026-10-07T16:13:02.316Z",
		"size": 1228,
		"path": "../public/assets/createLucideIcon-BM57YfsK.js"
	},
	"/assets/DeleteModal-CwxW5hEg.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"57b-Uav8RDunBUA7Qr9HzEIlAnA5AME\"",
		"mtime": "2026-10-07T16:13:02.137Z",
		"size": 1403,
		"path": "../public/assets/DeleteModal-CwxW5hEg.js"
	},
	"/favicon.ico": {
		"type": "image/vnd.microsoft.icon",
		"etag": "\"4f95-3RXc3p2mhEAs1WBwaIvE0Y0uu0Y\"",
		"mtime": "2026-07-03T00:51:12.000Z",
		"size": 20373,
		"path": "../public/favicon.ico"
	},
	"/assets/eye-AibCmblC.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"100-hypu7agvTUlGH16XicCN48mc1cc\"",
		"mtime": "2026-10-07T16:13:02.317Z",
		"size": 256,
		"path": "../public/assets/eye-AibCmblC.js"
	},
	"/assets/eye-off-C4vg9YkO.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1ae-DLuuT9ei7o9Ztv70pjp5F2gyFn8\"",
		"mtime": "2026-10-07T16:13:02.318Z",
		"size": 430,
		"path": "../public/assets/eye-off-C4vg9YkO.js"
	},
	"/assets/format-Cgz7pC5i.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"11e-wPunfWijhpwRrvLPvgZUvL0YwOE\"",
		"mtime": "2026-10-07T16:13:02.319Z",
		"size": 286,
		"path": "../public/assets/format-Cgz7pC5i.js"
	},
	"/assets/jsx-runtime-B6jttwkn.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1b3-RCFZqooc64bULOL98nC1ZOsYIUA\"",
		"mtime": "2026-10-07T16:13:02.321Z",
		"size": 435,
		"path": "../public/assets/jsx-runtime-B6jttwkn.js"
	},
	"/assets/link-1uhwThZ0.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"5970-JwgkywUK09d0QU/YxHkpxEa6Wjc\"",
		"mtime": "2026-10-07T16:13:02.322Z",
		"size": 22896,
		"path": "../public/assets/link-1uhwThZ0.js"
	},
	"/assets/loader-circle-BZisfdKO.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"90-clK5hpt7Co+sWdCUzN+zG0C9GLM\"",
		"mtime": "2026-10-07T16:13:02.326Z",
		"size": 144,
		"path": "../public/assets/loader-circle-BZisfdKO.js"
	},
	"/assets/matchContext-8PLJ5guC.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"32b-zxnE91z9ZPaCfXAQMYGvpLRyc6k\"",
		"mtime": "2026-10-07T16:13:02.327Z",
		"size": 811,
		"path": "../public/assets/matchContext-8PLJ5guC.js"
	},
	"/assets/privacy-policy-DTQSawQP.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"4f5-bs9/nZdO0br6xmcgE4yQp7h0rM4\"",
		"mtime": "2026-10-07T16:13:02.387Z",
		"size": 1269,
		"path": "../public/assets/privacy-policy-DTQSawQP.js"
	},
	"/assets/privacyService-DxrXWEpK.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1109-LBQHTSHGChixHXFf2EJEln2+kR0\"",
		"mtime": "2026-10-07T16:13:02.398Z",
		"size": 4361,
		"path": "../public/assets/privacyService-DxrXWEpK.js"
	},
	"/assets/react-CES6V0Ih.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1d6c-KAzDNZE7meu8CgSmgzeb9tRgDSk\"",
		"mtime": "2026-10-07T16:13:02.400Z",
		"size": 7532,
		"path": "../public/assets/react-CES6V0Ih.js"
	},
	"/assets/react-dom-DWuVlKIp.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"dfb-QEoVYsL2hmnMGv010An3ZidnyG8\"",
		"mtime": "2026-10-07T16:13:02.402Z",
		"size": 3579,
		"path": "../public/assets/react-dom-DWuVlKIp.js"
	},
	"/assets/rolldown-runtime-Bh1tDfsg.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"237-RWMfWL++Hyx/oSoFmTJgBJkEveY\"",
		"mtime": "2026-10-07T16:13:02.405Z",
		"size": 567,
		"path": "../public/assets/rolldown-runtime-Bh1tDfsg.js"
	},
	"/assets/routes-CFfWxTq0.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2702-kDKIhU1jtyEs8w21FlYcXH+NaEk\"",
		"mtime": "2026-10-07T16:13:02.413Z",
		"size": 9986,
		"path": "../public/assets/routes-CFfWxTq0.js"
	},
	"/assets/safe-fetch-ituBjceh.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"105f-JVlOpM+qEAZWva9R76SQ/C7r5aU\"",
		"mtime": "2026-10-07T16:13:02.415Z",
		"size": 4191,
		"path": "../public/assets/safe-fetch-ituBjceh.js"
	},
	"/assets/search-JLAWnESH.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"710-cT4Zr7Y9oDPdsAuWXrVjR3bjlQM\"",
		"mtime": "2026-10-07T16:13:02.417Z",
		"size": 1808,
		"path": "../public/assets/search-JLAWnESH.js"
	},
	"/assets/Sidebar-Cc9WHy1r.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"4fb-P88iKkX/YR3/GTFu2yFQO3MIZV0\"",
		"mtime": "2026-10-07T16:13:02.215Z",
		"size": 1275,
		"path": "../public/assets/Sidebar-Cc9WHy1r.js"
	},
	"/assets/Skeleton-Bwrne7TY.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"224-HxEuB32coaeFqB7mx0GCsRXGUh8\"",
		"mtime": "2026-10-07T16:13:02.216Z",
		"size": 548,
		"path": "../public/assets/Skeleton-Bwrne7TY.js"
	},
	"/assets/useRouter-vFGG9jIg.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2d3-knbzZI70tM5zD9bAqwcnOrMp0TE\"",
		"mtime": "2026-10-07T16:13:02.418Z",
		"size": 723,
		"path": "../public/assets/useRouter-vFGG9jIg.js"
	},
	"/assets/styles-CeLlRHjC.css": {
		"type": "text/css; charset=utf-8",
		"etag": "\"18192-RAMSnh0/x+w3NmtxSwvQJRzqbFI\"",
		"mtime": "2026-10-07T16:13:02.419Z",
		"size": 98706,
		"path": "../public/assets/styles-CeLlRHjC.css"
	},
	"/assets/index-CTo3G3Di.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"a5ebc-5d8GMrNLol1h38dyw4KBc9V9Jnc\"",
		"mtime": "2026-10-07T16:13:02.117Z",
		"size": 679612,
		"path": "../public/assets/index-CTo3G3Di.js"
	}
};
//#endregion
//#region #nitro/virtual/public-assets-node
function readAsset(id) {
	const serverDir = dirname(fileURLToPath(globalThis.__nitro_main__));
	return promises.readFile(resolve(serverDir, public_assets_data_default[id].path));
}
//#endregion
//#region #nitro/virtual/public-assets
var publicAssetBases = {};
function isPublicAssetURL(id = "") {
	if (public_assets_data_default[id]) return true;
	for (const base in publicAssetBases) if (id.startsWith(base)) return true;
	return false;
}
function getAsset(id) {
	return public_assets_data_default[id];
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/static.mjs
var METHODS = /* @__PURE__ */ new Set(["HEAD", "GET"]);
var EncodingMap = {
	gzip: ".gz",
	br: ".br",
	zstd: ".zst"
};
var static_default = defineHandler((event) => {
	if (event.req.method && !METHODS.has(event.req.method)) return;
	let id = decodePath(withLeadingSlash(withoutTrailingSlash(event.url.pathname)));
	let asset;
	const encodings = [...(event.req.headers.get("accept-encoding") || "").split(",").map((e) => EncodingMap[e.trim()]).filter(Boolean).sort(), ""];
	for (const encoding of encodings) for (const _id of [id + encoding, joinURL(id, "index.html" + encoding)]) {
		const _asset = getAsset(_id);
		if (_asset) {
			asset = _asset;
			id = _id;
			break;
		}
	}
	if (!asset) {
		if (isPublicAssetURL(id)) {
			event.res.headers.delete("Cache-Control");
			throw new HTTPError({ status: 404 });
		}
		return;
	}
	if (encodings.length > 1) event.res.headers.append("Vary", "Accept-Encoding");
	if (event.req.headers.get("if-none-match") === asset.etag) {
		event.res.status = 304;
		event.res.statusText = "Not Modified";
		return "";
	}
	const ifModifiedSinceH = event.req.headers.get("if-modified-since");
	const mtimeDate = new Date(asset.mtime);
	if (ifModifiedSinceH && asset.mtime && new Date(ifModifiedSinceH) >= mtimeDate) {
		event.res.status = 304;
		event.res.statusText = "Not Modified";
		return "";
	}
	if (asset.type) event.res.headers.set("Content-Type", asset.type);
	if (asset.etag && !event.res.headers.has("ETag")) event.res.headers.set("ETag", asset.etag);
	if (asset.mtime && !event.res.headers.has("Last-Modified")) event.res.headers.set("Last-Modified", mtimeDate.toUTCString());
	if (asset.encoding && !event.res.headers.has("Content-Encoding")) event.res.headers.set("Content-Encoding", asset.encoding);
	if (asset.size > 0 && !event.res.headers.has("Content-Length")) event.res.headers.set("Content-Length", asset.size.toString());
	return readAsset(id);
});
//#endregion
//#region #nitro/virtual/routing
var findRouteRules = /* @__PURE__ */ (() => {
	const $0 = [{
		name: "headers",
		route: "/assets/**",
		handler: headers,
		options: { "cache-control": "public, max-age=31536000, immutable" }
	}];
	return (m, p) => {
		let r = [];
		if (p.charCodeAt(p.length - 1) === 47) p = p.slice(0, -1) || "/";
		let s = p.split("/");
		if (s.length > 1) {
			if (s[1] === "assets") r.unshift({
				data: $0,
				params: { "_": s.slice(2).join("/") }
			});
		}
		return r;
	};
})();
var _lazy_bZpehs = defineLazyEventHandler(() => import("./_chunks/ssr-renderer.mjs"));
var findRoute = /* @__PURE__ */ (() => {
	const data = {
		route: "/**",
		handler: _lazy_bZpehs
	};
	return ((_m, p) => {
		return {
			data,
			params: { "_": p.slice(1) }
		};
	});
})();
var globalMiddleware = [toEventHandler(static_default)].filter(Boolean);
//#endregion
//#region node_modules/nitro/dist/runtime/internal/error/prod.mjs
var errorHandler = (error, event) => {
	const res = defaultHandler(error, event);
	return new NodeResponse(typeof res.body === "string" ? res.body : JSON.stringify(res.body, null, 2), res);
};
function defaultHandler(error, event) {
	const unhandled = error.unhandled ?? !HTTPError.isError(error);
	const { status = 500, statusText = "" } = unhandled ? {} : error;
	if (status === 404) {
		const url = event.url || new URL(event.req.url);
		const baseURL = "/";
		if (/^\/[^/]/.test(baseURL) && !url.pathname.startsWith(baseURL)) return {
			status: 302,
			headers: new Headers({ location: `${baseURL}${url.pathname.slice(1)}${url.search}` })
		};
	}
	const headers = new Headers(unhandled ? {} : error.headers);
	headers.set("content-type", "application/json; charset=utf-8");
	return {
		status,
		statusText,
		headers,
		body: {
			error: true,
			...unhandled ? {
				status,
				unhandled: true
			} : typeof error.toJSON === "function" ? error.toJSON() : {
				status,
				statusText,
				message: error.message
			}
		}
	};
}
//#endregion
//#region #nitro/virtual/error-handler
var errorHandlers = [errorHandler];
async function error_handler_default(error, event) {
	for (const handler of errorHandlers) try {
		const response = await handler(error, event, { defaultHandler });
		if (response) return response;
	} catch (error) {
		console.error(error);
	}
}
//#endregion
//#region #nitro/virtual/app
function createNitroApp() {
	const captureError = (error, errorCtx) => {
		if (errorCtx?.event) {
			const errors = errorCtx.event.req.context?.nitro?.errors;
			if (errors) errors.push({
				error,
				context: errorCtx
			});
		}
	};
	const h3App = createH3App({ onError(error, event) {
		return error_handler_default(error, event);
	} });
	let appHandler = (req) => {
		req.context ||= {};
		req.context.nitro = req.context.nitro || { errors: [] };
		return h3App.fetch(req);
	};
	return {
		fetch: appHandler,
		h3: h3App,
		hooks: void 0,
		captureError
	};
}
function createH3App(config) {
	const h3App = new H3Core(config);
	h3App["~findRoute"] = (event) => findRoute(event.req.method, event.url.pathname);
	h3App["~middleware"].push(...globalMiddleware);
	h3App["~getMiddleware"] = (event, route) => {
		const pathname = event.url.pathname;
		const method = event.req.method;
		const middleware = [];
		const routeRules = getRouteRules(method, pathname);
		event.context.routeRules = routeRules?.routeRules;
		if (routeRules?.routeRuleMiddleware.length) middleware.push(...routeRules.routeRuleMiddleware);
		middleware.push(...h3App["~middleware"]);
		if (route?.data?.middleware?.length) middleware.push(...route.data.middleware);
		return middleware;
	};
	return h3App;
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/app.mjs
var APP_ID = "default";
function useNitroApp() {
	let instance = useNitroApp._instance;
	if (instance) return instance;
	instance = useNitroApp._instance = createNitroApp();
	globalThis.__nitro__ = globalThis.__nitro__ || {};
	globalThis.__nitro__[APP_ID] = instance;
	return instance;
}
function getRouteRules(method, pathname) {
	const m = findRouteRules(method, pathname);
	if (!m?.length) return { routeRuleMiddleware: [] };
	const routeRules = {};
	for (const layer of m) for (const rule of layer.data) {
		const currentRule = routeRules[rule.name];
		if (currentRule) {
			if (rule.options === false) {
				delete routeRules[rule.name];
				continue;
			}
			if (typeof currentRule.options === "object" && typeof rule.options === "object") currentRule.options = {
				...currentRule.options,
				...rule.options
			};
			else currentRule.options = rule.options;
			currentRule.route = rule.route;
			currentRule.params = {
				...currentRule.params,
				...layer.params
			};
		} else if (rule.options !== false) routeRules[rule.name] = {
			...rule,
			params: layer.params
		};
	}
	const middleware = [];
	const orderedRules = Object.values(routeRules).sort((a, b) => (a.handler?.order || 0) - (b.handler?.order || 0));
	for (const rule of orderedRules) {
		if (rule.options === false || !rule.handler) continue;
		middleware.push(rule.handler(rule));
	}
	return {
		routeRules,
		routeRuleMiddleware: middleware
	};
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/error/hooks.mjs
function _captureError(error, type) {
	console.error(`[${type}]`, error);
	useNitroApp().captureError?.(error, { tags: [type] });
}
function trapUnhandledErrors() {
	process.on("unhandledRejection", (error) => _captureError(error, "unhandledRejection"));
	process.on("uncaughtException", (error) => _captureError(error, "uncaughtException"));
}
//#endregion
//#region #nitro/virtual/tracing
var tracingSrvxPlugins = [];
//#endregion
//#region node_modules/nitro/dist/presets/node/runtime/node-server.mjs
var _parsedPort = Number.parseInt(process.env.NITRO_PORT ?? process.env.PORT ?? "");
var port = Number.isNaN(_parsedPort) ? 3e3 : _parsedPort;
var host = process.env.NITRO_HOST || process.env.HOST;
var cert = process.env.NITRO_SSL_CERT;
var key = process.env.NITRO_SSL_KEY;
var nitroApp = useNitroApp();
serve({
	port,
	hostname: host,
	tls: cert && key ? {
		cert,
		key
	} : void 0,
	fetch: nitroApp.fetch,
	plugins: [...tracingSrvxPlugins]
});
trapUnhandledErrors();
var node_server_default = {};
//#endregion
export { node_server_default as default };
