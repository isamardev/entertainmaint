//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-BjJkkI1e.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "C:/Users/HP/Documents/GitHub/entertainmaint/src/routes/__root.tsx",
		children: [
			"/",
			"/admin",
			"/auth",
			"/contact",
			"/privacy-policy",
			"/search",
			"/article/$slug",
			"/category/$slug"
		],
		preloads: [
			"/assets/index-C6Faaqev.js",
			"/assets/rolldown-runtime-Bh1tDfsg.js",
			"/assets/react-CES6V0Ih.js",
			"/assets/react-dom-DWuVlKIp.js",
			"/assets/link-1uhwThZ0.js",
			"/assets/matchContext-8PLJ5guC.js",
			"/assets/useRouter-vFGG9jIg.js",
			"/assets/jsx-runtime-B6jttwkn.js",
			"/assets/safe-fetch-N9uVjNP5.js",
			"/assets/createLucideIcon-BM57YfsK.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-C6Faaqev.js"
		} }]
	},
	"/": {
		filePath: "C:/Users/HP/Documents/GitHub/entertainmaint/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-DxZHbxta.js",
			"/assets/ArticleCard-DMKeuwEl.js",
			"/assets/Sidebar-4OqjeOwP.js",
			"/assets/Skeleton-Bwrne7TY.js"
		]
	},
	"/admin": {
		filePath: "C:/Users/HP/Documents/GitHub/entertainmaint/src/routes/admin.tsx",
		children: [
			"/admin/categories",
			"/admin/login",
			"/admin/new",
			"/admin/settings",
			"/admin/socials",
			"/admin/users",
			"/admin/",
			"/admin/edit/$id"
		],
		preloads: ["/assets/admin-wBpiBSV8.js", "/assets/AdminLoginForm-DcDxbEKW.js"]
	},
	"/auth": {
		filePath: "C:/Users/HP/Documents/GitHub/entertainmaint/src/routes/auth.tsx",
		children: void 0,
		preloads: ["/assets/auth-5ifUq3oF.js"]
	},
	"/contact": {
		filePath: "C:/Users/HP/Documents/GitHub/entertainmaint/src/routes/contact.tsx",
		children: void 0,
		preloads: ["/assets/contact-DM6uhWOj.js"]
	},
	"/privacy-policy": {
		filePath: "C:/Users/HP/Documents/GitHub/entertainmaint/src/routes/privacy-policy.tsx",
		children: void 0,
		preloads: ["/assets/privacy-policy-DdKUqQsO.js"]
	},
	"/search": {
		filePath: "C:/Users/HP/Documents/GitHub/entertainmaint/src/routes/search.tsx",
		children: void 0,
		preloads: [
			"/assets/search-P5WFNT03.js",
			"/assets/ArticleCard-DMKeuwEl.js",
			"/assets/Skeleton-Bwrne7TY.js"
		]
	},
	"/admin/categories": {
		filePath: "C:/Users/HP/Documents/GitHub/entertainmaint/src/routes/admin.categories.tsx",
		children: void 0,
		preloads: ["/assets/admin.categories-CURjIDsQ.js", "/assets/DeleteModal-CwxW5hEg.js"]
	},
	"/admin/login": {
		filePath: "C:/Users/HP/Documents/GitHub/entertainmaint/src/routes/admin.login.tsx",
		children: void 0,
		preloads: ["/assets/admin.login-CPw4oFea.js"]
	},
	"/admin/new": {
		filePath: "C:/Users/HP/Documents/GitHub/entertainmaint/src/routes/admin.new.tsx",
		children: void 0,
		preloads: ["/assets/admin.new-DpOfC_yl.js", "/assets/ArticleForm-D6lZs8yE.js"]
	},
	"/admin/settings": {
		filePath: "C:/Users/HP/Documents/GitHub/entertainmaint/src/routes/admin.settings.tsx",
		children: void 0,
		preloads: ["/assets/admin.settings-DKxfFZ3s.js"]
	},
	"/admin/socials": {
		filePath: "C:/Users/HP/Documents/GitHub/entertainmaint/src/routes/admin.socials.tsx",
		children: void 0,
		preloads: ["/assets/admin.socials-m-Eoljyv.js"]
	},
	"/admin/users": {
		filePath: "C:/Users/HP/Documents/GitHub/entertainmaint/src/routes/admin.users.tsx",
		children: void 0,
		preloads: ["/assets/admin.users-yNua0Ghi.js"]
	},
	"/article/$slug": {
		filePath: "C:/Users/HP/Documents/GitHub/entertainmaint/src/routes/article.$slug.tsx",
		children: void 0,
		preloads: [
			"/assets/article._slug-B6mtXd1n.js",
			"/assets/format-Cgz7pC5i.js",
			"/assets/ArticleCard-DMKeuwEl.js",
			"/assets/Sidebar-4OqjeOwP.js",
			"/assets/article._slug-DdG22EH4.js",
			"/assets/article._slug-Dz6kTjYA.js"
		]
	},
	"/category/$slug": {
		filePath: "C:/Users/HP/Documents/GitHub/entertainmaint/src/routes/category.$slug.tsx",
		children: void 0,
		preloads: [
			"/assets/category._slug-C9GJtnL7.js",
			"/assets/format-Cgz7pC5i.js",
			"/assets/Sidebar-4OqjeOwP.js",
			"/assets/category._slug-CoYcrX9_.js",
			"/assets/category._slug-Dz6kTjYA.js"
		]
	},
	"/admin/": {
		filePath: "C:/Users/HP/Documents/GitHub/entertainmaint/src/routes/admin.index.tsx",
		children: void 0,
		preloads: [
			"/assets/admin.index-TEYN73H_.js",
			"/assets/DeleteModal-CwxW5hEg.js",
			"/assets/format-Cgz7pC5i.js"
		]
	},
	"/admin/edit/$id": {
		filePath: "C:/Users/HP/Documents/GitHub/entertainmaint/src/routes/admin.edit.$id.tsx",
		children: void 0,
		preloads: ["/assets/admin.edit._id-CLn2Kxkr.js", "/assets/ArticleForm-D6lZs8yE.js"]
	}
} });
//#endregion
export { tsrStartManifest };
