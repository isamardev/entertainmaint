//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-CtxEGio_.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "C:/Users/HP/Documents/GitHub/entertainmaint/src/routes/__root.tsx",
		children: [
			"/",
			"/admin",
			"/auth",
			"/contact",
			"/privacy-policy",
			"/search",
			"/article/$slug",
			"/category/$slug"
		],
		preloads: [
			"/assets/index-CTo3G3Di.js",
			"/assets/rolldown-runtime-Bh1tDfsg.js",
			"/assets/react-CES6V0Ih.js",
			"/assets/react-dom-DWuVlKIp.js",
			"/assets/link-1uhwThZ0.js",
			"/assets/matchContext-8PLJ5guC.js",
			"/assets/useRouter-vFGG9jIg.js",
			"/assets/jsx-runtime-B6jttwkn.js",
			"/assets/safe-fetch-ituBjceh.js",
			"/assets/createLucideIcon-BM57YfsK.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-CTo3G3Di.js"
		} }]
	},
	"/": {
		filePath: "C:/Users/HP/Documents/GitHub/entertainmaint/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-CFfWxTq0.js",
			"/assets/loader-circle-BZisfdKO.js",
			"/assets/ArticleCard-BXoO-lbw.js",
			"/assets/Sidebar-Cc9WHy1r.js",
			"/assets/Skeleton-Bwrne7TY.js"
		]
	},
	"/admin": {
		filePath: "C:/Users/HP/Documents/GitHub/entertainmaint/src/routes/admin.tsx",
		children: [
			"/admin/categories",
			"/admin/login",
			"/admin/new",
			"/admin/privacy",
			"/admin/settings",
			"/admin/socials",
			"/admin/users",
			"/admin/",
			"/admin/edit/$id"
		],
		preloads: ["/assets/admin-GLjW4H2Y.js", "/assets/AdminLoginForm-Dorsuw4N.js"]
	},
	"/auth": {
		filePath: "C:/Users/HP/Documents/GitHub/entertainmaint/src/routes/auth.tsx",
		children: void 0,
		preloads: ["/assets/auth-4mRWZzXR.js"]
	},
	"/contact": {
		filePath: "C:/Users/HP/Documents/GitHub/entertainmaint/src/routes/contact.tsx",
		children: void 0,
		preloads: ["/assets/contact-BKCPpU1b.js"]
	},
	"/privacy-policy": {
		filePath: "C:/Users/HP/Documents/GitHub/entertainmaint/src/routes/privacy-policy.tsx",
		children: void 0,
		preloads: ["/assets/privacy-policy-DTQSawQP.js", "/assets/privacyService-DxrXWEpK.js"]
	},
	"/search": {
		filePath: "C:/Users/HP/Documents/GitHub/entertainmaint/src/routes/search.tsx",
		children: void 0,
		preloads: [
			"/assets/search-JLAWnESH.js",
			"/assets/ArticleCard-BXoO-lbw.js",
			"/assets/Skeleton-Bwrne7TY.js"
		]
	},
	"/admin/categories": {
		filePath: "C:/Users/HP/Documents/GitHub/entertainmaint/src/routes/admin.categories.tsx",
		children: void 0,
		preloads: ["/assets/admin.categories-ChjCagDd.js", "/assets/DeleteModal-CwxW5hEg.js"]
	},
	"/admin/login": {
		filePath: "C:/Users/HP/Documents/GitHub/entertainmaint/src/routes/admin.login.tsx",
		children: void 0,
		preloads: ["/assets/admin.login-DreXjj_l.js"]
	},
	"/admin/new": {
		filePath: "C:/Users/HP/Documents/GitHub/entertainmaint/src/routes/admin.new.tsx",
		children: void 0,
		preloads: ["/assets/admin.new-BTVHSdAJ.js", "/assets/ArticleForm-BvhF6kJN.js"]
	},
	"/admin/privacy": {
		filePath: "C:/Users/HP/Documents/GitHub/entertainmaint/src/routes/admin.privacy.tsx",
		children: void 0,
		preloads: [
			"/assets/admin.privacy-Cx12HreD.js",
			"/assets/eye-AibCmblC.js",
			"/assets/loader-circle-BZisfdKO.js",
			"/assets/privacyService-DxrXWEpK.js"
		]
	},
	"/admin/settings": {
		filePath: "C:/Users/HP/Documents/GitHub/entertainmaint/src/routes/admin.settings.tsx",
		children: void 0,
		preloads: [
			"/assets/admin.settings-Dlj8gQ8J.js",
			"/assets/eye-off-C4vg9YkO.js",
			"/assets/eye-AibCmblC.js"
		]
	},
	"/admin/socials": {
		filePath: "C:/Users/HP/Documents/GitHub/entertainmaint/src/routes/admin.socials.tsx",
		children: void 0,
		preloads: ["/assets/admin.socials-yIxocHOA.js"]
	},
	"/admin/users": {
		filePath: "C:/Users/HP/Documents/GitHub/entertainmaint/src/routes/admin.users.tsx",
		children: void 0,
		preloads: ["/assets/admin.users-CQCs1IYt.js"]
	},
	"/article/$slug": {
		filePath: "C:/Users/HP/Documents/GitHub/entertainmaint/src/routes/article.$slug.tsx",
		children: void 0,
		preloads: [
			"/assets/article._slug-C0lX8U47.js",
			"/assets/format-Cgz7pC5i.js",
			"/assets/ArticleCard-BXoO-lbw.js",
			"/assets/Sidebar-Cc9WHy1r.js",
			"/assets/article._slug-DdG22EH4.js",
			"/assets/article._slug-Dz6kTjYA.js"
		]
	},
	"/category/$slug": {
		filePath: "C:/Users/HP/Documents/GitHub/entertainmaint/src/routes/category.$slug.tsx",
		children: void 0,
		preloads: [
			"/assets/category._slug-B9laFqzT.js",
			"/assets/format-Cgz7pC5i.js",
			"/assets/Sidebar-Cc9WHy1r.js",
			"/assets/category._slug-CoYcrX9_.js",
			"/assets/category._slug-Dz6kTjYA.js"
		]
	},
	"/admin/": {
		filePath: "C:/Users/HP/Documents/GitHub/entertainmaint/src/routes/admin.index.tsx",
		children: void 0,
		preloads: [
			"/assets/admin.index-DTUHw5CY.js",
			"/assets/DeleteModal-CwxW5hEg.js",
			"/assets/format-Cgz7pC5i.js"
		]
	},
	"/admin/edit/$id": {
		filePath: "C:/Users/HP/Documents/GitHub/entertainmaint/src/routes/admin.edit.$id.tsx",
		children: void 0,
		preloads: ["/assets/admin.edit._id-DxwimH1K.js", "/assets/ArticleForm-BvhF6kJN.js"]
	}
} });
//#endregion
export { tsrStartManifest };
