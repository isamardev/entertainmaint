const DEFAULT_BACKEND_API = "/api";

// Production backend absolute origin — used if VITE_API_BASE_URL is relative
// and we're in SSR (no window) during PRODUCTION. Hard-coded (not env) because
// it's the fixed Hostinger Node.js backend subdomain used in production
// regardless of build env — and SSR under Nitro needs to reach it when no
// dev proxy / same-origin path exists.
const PROD_BACKEND_ORIGIN = "https://aliceblue-goose-490382.hostingersite.com";

const rawApiBase = (import.meta as any).env?.VITE_API_BASE_URL;
const rawDevApiBase = (import.meta as any).env?.VITE_DEV_API_BASE_URL;

const normalizedProdBase =
  typeof rawApiBase === "string" && rawApiBase.trim()
    ? rawApiBase.trim().replace(/\/+$/, "")
    : DEFAULT_BACKEND_API;
const normalizedDevBase =
  typeof rawDevApiBase === "string" && rawDevApiBase.trim()
    ? rawDevApiBase.trim().replace(/\/+$/, "")
    : DEFAULT_BACKEND_API;

const isDev = Boolean((import.meta as any).env?.DEV);
const IS_PROD_BUILD = Boolean((import.meta as any).env?.PROD);

export const API_BASE = isDev ? normalizedDevBase : normalizedProdBase;

function looksLikeOrigin(value: string): boolean {
  return /^https?:\/\//i.test(value);
}

export function getApiUrl(path: string) {
  const base = API_BASE || DEFAULT_BACKEND_API;
  const normalizedPath = path.startsWith("/") ? path : `/${path}`;

  if (typeof window === "undefined") {
    if (looksLikeOrigin(base)) {
      return `${base}${normalizedPath}`;
    }
    // SSR: NO window / browser context.
    //  - Local dev (vite dev, npm run dev) → Vite proxy on port 3000
    //  - Prod SSR (Nitro/Node) → absolute production backend origin,
    //    because localhost:3000 may have nothing listening on Hostinger
    //    Node container and there is no reverse proxy.
    const fallbackOrigin = isDev || !IS_PROD_BUILD ? "http://localhost:3000" : PROD_BACKEND_ORIGIN;
    return `${fallbackOrigin}${base}${normalizedPath}`;
  }

  if (looksLikeOrigin(base)) {
    return `${base}${normalizedPath}`;
  }
  return `${base}${normalizedPath}`;
}

export function getApiOrigin(): string {
  const base = API_BASE || DEFAULT_BACKEND_API;
  if (looksLikeOrigin(base)) return base.replace(/\/api$/, "").replace(/\/+$/, "");
  if (typeof window !== "undefined") return window.location.origin;
  return isDev || !IS_PROD_BUILD ? "http://localhost:3000" : PROD_BACKEND_ORIGIN;
}
