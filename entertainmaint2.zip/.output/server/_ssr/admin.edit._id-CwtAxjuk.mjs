import { r as __toESM } from "../_runtime.mjs";
import { a as require_react, i as require_jsx_runtime, t as useQuery } from "../_libs/react+tanstack__react-query.mjs";
import { v as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as articleService } from "./articleService-UhMa44iK.mjs";
import { t as Route } from "./admin.edit._id-t3yMW7Qq.mjs";
import { t as ArticleForm } from "./ArticleForm-BueT-fkK.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/admin.edit._id-CwtAxjuk.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function EditArticle() {
	const { id } = Route.useParams();
	const navigate = useNavigate();
	const numericId = Number(id);
	const [uploading, setUploading] = (0, import_react.useState)(false);
	const [progress, setProgress] = (0, import_react.useState)(null);
	const { data, isLoading, error } = useQuery({
		queryKey: ["admin-article", numericId],
		queryFn: async () => {
			try {
				return await articleService.listAll().then((all) => {
					const found = all.find((a) => a.id === numericId);
					if (!found) throw new Error(`The requested article (ID ${numericId}) does not exist or has been deleted.`);
					return found;
				});
			} catch (err) {
				throw new Error(err instanceof Error && err.message ? err.message : "Unable to load the article. Please try again later.");
			}
		}
	});
	if (error) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "display text-xl font-black uppercase",
				children: "Edit Article"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "border border-red-200 bg-red-50 text-red-700 rounded px-3 py-2 text-sm",
				children: error.message
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => navigate({ to: "/admin" }),
				className: "px-4 py-2 bg-black text-white font-bold uppercase tracking-widest",
				children: "Back to articles"
			})
		]
	});
	if (isLoading || !data) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "meta",
		children: "Loading article…"
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
		className: "display mb-4 text-xl font-black uppercase",
		children: "Edit Article"
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArticleForm, {
		initial: data,
		onSaved: () => navigate({ to: "/admin" }),
		uploadingState: {
			uploading,
			progress,
			setUploading,
			setProgress
		}
	})] });
}
//#endregion
export { EditArticle as component };
