import { r as __toESM } from "../_runtime.mjs";
import { a as require_react, i as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { v as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as ArticleForm } from "./ArticleForm-BueT-fkK.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/admin.new-DPq_Rr8E.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function NewArticle() {
	const navigate = useNavigate();
	const [uploading, setUploading] = (0, import_react.useState)(false);
	const [progress, setProgress] = (0, import_react.useState)(null);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
		className: "display mb-4 text-xl font-black uppercase",
		children: "New Article"
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArticleForm, {
		onSaved: () => navigate({ to: "/admin" }),
		uploadingState: {
			uploading,
			progress,
			setUploading,
			setProgress
		}
	})] });
}
//#endregion
export { NewArticle as component };
