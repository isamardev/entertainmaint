//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-BMatZbo2.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "C:/Users/HP/Documents/GitHub/entertainmaint/src/routes/__root.tsx",
		children: [
			"/",
			"/admin",
			"/auth",
			"/contact",
			"/privacy-policy",
			"/search",
			"/article/$slug",
			"/category/$slug"
		],
		preloads: [
			"/assets/index-BSPZPbc_.js",
			"/assets/rolldown-runtime-Bh1tDfsg.js",
			"/assets/react-CES6V0Ih.js",
			"/assets/react-dom-DWuVlKIp.js",
			"/assets/link-1uhwThZ0.js",
			"/assets/matchContext-8PLJ5guC.js",
			"/assets/useRouter-vFGG9jIg.js",
			"/assets/jsx-runtime-B6jttwkn.js",
			"/assets/safe-fetch-N9uVjNP5.js",
			"/assets/createLucideIcon-BM57YfsK.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-BSPZPbc_.js"
		} }]
	},
	"/": {
		filePath: "C:/Users/HP/Documents/GitHub/entertainmaint/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-DVy-2TIt.js",
			"/assets/ArticleCard-DMKeuwEl.js",
			"/assets/Sidebar-DmuH4e3K.js",
			"/assets/Skeleton-Bwrne7TY.js"
		]
	},
	"/admin": {
		filePath: "C:/Users/HP/Documents/GitHub/entertainmaint/src/routes/admin.tsx",
		children: [
			"/admin/categories",
			"/admin/login",
			"/admin/new",
			"/admin/settings",
			"/admin/socials",
			"/admin/users",
			"/admin/",
			"/admin/edit/$id"
		],
		preloads: ["/assets/admin-C0I4uwDM.js", "/assets/AdminLoginForm-CJKKwTf8.js"]
	},
	"/auth": {
		filePath: "C:/Users/HP/Documents/GitHub/entertainmaint/src/routes/auth.tsx",
		children: void 0,
		preloads: ["/assets/auth-CEroigu1.js"]
	},
	"/contact": {
		filePath: "C:/Users/HP/Documents/GitHub/entertainmaint/src/routes/contact.tsx",
		children: void 0,
		preloads: ["/assets/contact-UVGcuWBX.js"]
	},
	"/privacy-policy": {
		filePath: "C:/Users/HP/Documents/GitHub/entertainmaint/src/routes/privacy-policy.tsx",
		children: void 0,
		preloads: ["/assets/privacy-policy-DdKUqQsO.js"]
	},
	"/search": {
		filePath: "C:/Users/HP/Documents/GitHub/entertainmaint/src/routes/search.tsx",
		children: void 0,
		preloads: [
			"/assets/search-DWcIzzw8.js",
			"/assets/ArticleCard-DMKeuwEl.js",
			"/assets/Skeleton-Bwrne7TY.js"
		]
	},
	"/admin/categories": {
		filePath: "C:/Users/HP/Documents/GitHub/entertainmaint/src/routes/admin.categories.tsx",
		children: void 0,
		preloads: ["/assets/admin.categories-DD8ODNYl.js", "/assets/DeleteModal-CwxW5hEg.js"]
	},
	"/admin/login": {
		filePath: "C:/Users/HP/Documents/GitHub/entertainmaint/src/routes/admin.login.tsx",
		children: void 0,
		preloads: ["/assets/admin.login-CNdWkwpZ.js"]
	},
	"/admin/new": {
		filePath: "C:/Users/HP/Documents/GitHub/entertainmaint/src/routes/admin.new.tsx",
		children: void 0,
		preloads: ["/assets/admin.new-CS4yVsp8.js", "/assets/ArticleForm-KekUk5vE.js"]
	},
	"/admin/settings": {
		filePath: "C:/Users/HP/Documents/GitHub/entertainmaint/src/routes/admin.settings.tsx",
		children: void 0,
		preloads: ["/assets/admin.settings--62M6vD4.js"]
	},
	"/admin/socials": {
		filePath: "C:/Users/HP/Documents/GitHub/entertainmaint/src/routes/admin.socials.tsx",
		children: void 0,
		preloads: ["/assets/admin.socials-yuHJRyhb.js"]
	},
	"/admin/users": {
		filePath: "C:/Users/HP/Documents/GitHub/entertainmaint/src/routes/admin.users.tsx",
		children: void 0,
		preloads: ["/assets/admin.users-BA5sRrAx.js"]
	},
	"/article/$slug": {
		filePath: "C:/Users/HP/Documents/GitHub/entertainmaint/src/routes/article.$slug.tsx",
		children: void 0,
		preloads: [
			"/assets/article._slug-Bv9vJ9we.js",
			"/assets/format-Cgz7pC5i.js",
			"/assets/ArticleCard-DMKeuwEl.js",
			"/assets/Sidebar-DmuH4e3K.js",
			"/assets/article._slug-DdG22EH4.js",
			"/assets/article._slug-Dz6kTjYA.js"
		]
	},
	"/category/$slug": {
		filePath: "C:/Users/HP/Documents/GitHub/entertainmaint/src/routes/category.$slug.tsx",
		children: void 0,
		preloads: [
			"/assets/category._slug-CoYcrX9_.js",
			"/assets/category._slug-DCcCY9QJ.js",
			"/assets/format-Cgz7pC5i.js",
			"/assets/Sidebar-DmuH4e3K.js",
			"/assets/category._slug-Dz6kTjYA.js"
		]
	},
	"/admin/": {
		filePath: "C:/Users/HP/Documents/GitHub/entertainmaint/src/routes/admin.index.tsx",
		children: void 0,
		preloads: [
			"/assets/admin.index-CZ0CDNuQ.js",
			"/assets/DeleteModal-CwxW5hEg.js",
			"/assets/format-Cgz7pC5i.js"
		]
	},
	"/admin/edit/$id": {
		filePath: "C:/Users/HP/Documents/GitHub/entertainmaint/src/routes/admin.edit.$id.tsx",
		children: void 0,
		preloads: ["/assets/admin.edit._id-DGvmA3CR.js", "/assets/ArticleForm-KekUk5vE.js"]
	}
} });
//#endregion
export { tsrStartManifest };
