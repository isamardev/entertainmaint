import { r as __toESM } from "../_runtime.mjs";
import { a as require_react, i as require_jsx_runtime, t as useQuery } from "../_libs/react+tanstack__react-query.mjs";
import { g as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as articleService } from "./articleService-UhMa44iK.mjs";
import { E as Facebook, S as Link2, h as MessageCircle, o as Twitter } from "../_libs/lucide-react.mjs";
import { n as shortDate } from "./format-BhnsDS-S.mjs";
import { t as Route } from "./article._slug-DIA6ldNl.mjs";
import { t as ArticleCard } from "./ArticleCard-D4zUftx1.mjs";
import { t as TrendingSidebar } from "./Sidebar-DKeRiSHS.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/article._slug-ByZDUjW4.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function ShareButtons({ url, title }) {
	const [copied, setCopied] = (0, import_react.useState)(false);
	const enc = encodeURIComponent;
	const links = [
		{
			icon: Twitter,
			label: "X",
			href: `https://twitter.com/intent/tweet?url=${enc(url)}&text=${enc(title)}`
		},
		{
			icon: Facebook,
			label: "Facebook",
			href: `https://www.facebook.com/sharer/sharer.php?u=${enc(url)}`
		},
		{
			icon: MessageCircle,
			label: "WhatsApp",
			href: `https://api.whatsapp.com/send?text=${enc(title + " " + url)}`
		}
	];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-wrap items-center gap-2",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "eyebrow mr-2",
				children: "Share"
			}),
			links.map((l) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
				href: l.href,
				target: "_blank",
				rel: "noopener noreferrer",
				className: "inline-flex items-center gap-1 border border-border px-3 py-1.5 text-xs font-bold uppercase tracking-wider hover:border-black hover:text-black",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(l.icon, { size: 14 }),
					" ",
					l.label
				]
			}, l.label)),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				onClick: () => {
					navigator.clipboard.writeText(url);
					setCopied(true);
					setTimeout(() => setCopied(false), 1500);
				},
				className: "inline-flex items-center gap-1 border border-border px-3 py-1.5 text-xs font-bold uppercase tracking-wider hover:border-black hover:text-black",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link2, { size: 14 }),
					" ",
					copied ? "Copied" : "Copy link"
				]
			})
		]
	});
}
function ArticlePage() {
	const { article } = Route.useLoaderData();
	const proseRef = (0, import_react.useRef)(null);
	const { data: related = [] } = useQuery({
		queryKey: ["related", article.id],
		queryFn: () => articleService.related(article)
	});
	const { data: trending = [] } = useQuery({
		queryKey: ["trending-article"],
		queryFn: () => articleService.listTrending(9),
		staleTime: 6e4
	});
	const url = typeof window !== "undefined" ? window.location.href : `/article/${article.slug}`;
	const articleBodyHtml = formatArticleBody(article.body);
	(0, import_react.useEffect)(() => {
		if (!proseRef.current || typeof document === "undefined") return;
		const root = proseRef.current;
		const hasTwitter = !!root.querySelector("blockquote.twitter-tweet");
		const hasInstagram = !!root.querySelector("blockquote.instagram-media");
		const hasTiktok = !!root.querySelector("blockquote.tiktok-embed");
		const hasFacebook = !!root.querySelector("blockquote.fb-post");
		if (hasTwitter) {
			const load = () => {
				try {
					const w = window;
					if (w.twttr?.widgets?.load) w.twttr.widgets.load(root);
				} catch {}
			};
			const existing = document.querySelector("script[src=\"https://platform.twitter.com/widgets.js\"]");
			if (existing && window.twttr?.widgets?.load) setTimeout(load, 0);
			else {
				const s = existing ?? document.createElement("script");
				s.async = true;
				s.defer = true;
				s.src = "https://platform.twitter.com/widgets.js";
				s.onload = () => setTimeout(load, 60);
				s.onerror = () => {};
				if (!existing) document.body.appendChild(s);
			}
		}
		if (hasInstagram) {
			const process = () => {
				try {
					const w = window;
					if (w.instgrm?.Embeds?.process) w.instgrm.Embeds.process();
				} catch {}
			};
			const existing = document.querySelector("script[src=\"https://www.instagram.com/embed.js\"]");
			if (existing && window.instgrm?.Embeds?.process) setTimeout(process, 0);
			else {
				const s = existing ?? document.createElement("script");
				s.async = true;
				s.defer = true;
				s.src = "https://www.instagram.com/embed.js";
				s.onload = () => setTimeout(process, 60);
				s.onerror = () => {};
				if (!existing) document.body.appendChild(s);
			}
		}
		if (hasTiktok) {
			if (!document.querySelector("script[src=\"https://www.tiktok.com/embed.js\"]")) {
				const s = document.createElement("script");
				s.async = true;
				s.defer = true;
				s.src = "https://www.tiktok.com/embed.js";
				s.onerror = () => {};
				document.body.appendChild(s);
			}
		}
		if (hasFacebook) {
			const ensureRoot = () => {
				if (!document.getElementById("fb-root")) {
					const r = document.createElement("div");
					r.id = "fb-root";
					document.body.prepend(r);
				}
			};
			const parse = () => {
				try {
					const w = window;
					if (w.FB?.XFBML?.parse) w.FB.XFBML.parse(root);
				} catch {}
			};
			ensureRoot();
			const existing = document.querySelector("script[src=\"https://connect.facebook.net/en_US/sdk.js\"]");
			if (existing && window.FB?.XFBML?.parse) setTimeout(parse, 0);
			else {
				const s = existing ?? document.createElement("script");
				s.async = true;
				s.defer = true;
				s.src = "https://connect.facebook.net/en_US/sdk.js#xfbml=1&version=v18.0";
				s.crossOrigin = "anonymous";
				s.onload = () => setTimeout(parse, 80);
				s.onerror = () => {};
				if (!existing) document.body.appendChild(s);
			}
		}
	}, [articleBodyHtml]);
	const readNext = trending.slice(0, 3);
	const nineGrid = trending.slice(0, 9);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-10 lg:grid-cols-[minmax(0,1fr)_320px]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "max-w-4xl min-w-0",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
					className: "mb-6",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "display text-3xl font-black uppercase leading-[0.95] md:text-5xl lg:text-6xl",
							children: article.title
						}),
						article.dek && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-4 text-lg text-muted-foreground md:text-xl",
							children: article.dek
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "meta mt-4 flex flex-wrap gap-x-4 gap-y-1",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "By Entertainment Trends Staff" }),
								article.category?.name && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: "/category/$slug",
									params: { slug: article.category.slug },
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "eyebrow",
										children: article.category.name
									})
								}),
								(() => {
									const published = article.published_at ? new Date(article.published_at).getTime() : 0;
									const updated = article.updated_at ? new Date(article.updated_at).getTime() : 0;
									if (published && updated - published > 5e3) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["Updated ", shortDate(article.updated_at)] });
									return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: shortDate(article.published_at) });
								})()
							]
						})
					]
				}),
				article.embed_url && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmbeddedPost, { url: article.embed_url }),
				article.hero_image_hd && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("figure", {
					className: "mb-8",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: article.hero_image_hd,
						alt: article.title,
						className: "w-full"
					}), article.hero_caption && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("figcaption", {
						className: "meta mt-2",
						children: article.hero_caption
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					ref: proseRef,
					className: "prose prose-lg max-w-none text-lg leading-relaxed prose-headings:font-black prose-headings:uppercase prose-a:text-blue-700 prose-a:no-underline hover:prose-a:underline prose-a:font-semibold prose-strong:text-black",
					dangerouslySetInnerHTML: { __html: articleBodyHtml }
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "my-10 border-y border-border py-4",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShareButtons, {
						url,
						title: article.title
					})
				}),
				nineGrid.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "mt-16",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mb-6 border-b-2 border-black pb-2",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "display text-2xl font-black uppercase",
							children: "More Stories"
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid gap-8 sm:grid-cols-2 lg:grid-cols-3",
						children: nineGrid.map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArticleCard, { article: a }, a.id))
					})]
				}),
				related.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "mt-16",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mb-6 border-b-2 border-black pb-2",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "display text-2xl font-black uppercase",
							children: "Related Stories"
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex gap-6 overflow-x-auto pb-4",
						children: related.map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "min-w-[280px] max-w-xs flex-1",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArticleCard, { article: a })
						}, a.id))
					})]
				}),
				readNext.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "mt-16",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mb-6 border-b-2 border-black pb-2",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "display text-2xl font-black uppercase",
							children: "Read Next"
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "space-y-6",
						children: readNext.map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArticleCard, {
							article: a,
							horizontal: true
						}, a.id))
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-10 lg:hidden",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TrendingSidebar, {})
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "relative hidden lg:block",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "sticky top-24",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TrendingSidebar, {})
			})
		})]
	}) });
}
function formatArticleBody(body) {
	const trimmed = (body || "").trim();
	if (!trimmed) return "<p></p>";
	let enriched = trimmed;
	if (/<[a-z][\s\S]*>/i.test(trimmed)) enriched = sanitizeRichText(trimmed);
	else enriched = trimmed.split(/\n\n+/).map((para) => `<p>${escapeHtml(para).replace(/\n/g, "<br />")}</p>`).join("");
	enriched = enriched.replace(/(<iframe\b[^>]*><\/iframe>)/gi, (_m, iframe) => {
		if (/<figure[\s\S]*<\/figure>/i.test(iframe)) return iframe;
		if (/<div[^>]*aspect-video/i.test(iframe)) return iframe;
		return `<figure class="my-8 w-full max-w-none"><div class="aspect-video w-full overflow-hidden rounded border border-gray-200 bg-black">${iframe}</div></figure>`;
	});
	enriched = enriched.replace(/(<video\b[^>]*>(?:[\s\S]*?<\/video>|<video\b[^>]*\/>))/gi, (_m, videoTag) => {
		if (/<figure[\s\S]*<\/figure>/i.test(videoTag)) return videoTag;
		return `<figure class="my-8 w-full max-w-none"><div class="w-full overflow-hidden rounded border border-gray-200 bg-black">${videoTag}</div></figure>`;
	});
	const embedBQRe = /<figure[^>]*>\s*(<blockquote\s+class="(?:twitter-tweet|instagram-media|fb-post|tiktok-embed)"[^>]*>[\s\S]*?<\/blockquote>)\s*<\/figure>/gi;
	const standaloneBQRe = /(<blockquote\s+class="(?:twitter-tweet|instagram-media|fb-post|tiktok-embed)"[^>]*>[\s\S]*?<\/blockquote>)(?!\s*<\/figure>)/gi;
	const wrapEmbed = (bq) => `<figure class="inline-embed my-8 w-full max-w-none overflow-hidden rounded border border-gray-200 bg-white p-3">${bq}</figure>`;
	enriched = enriched.replace(embedBQRe, (_m, bq) => wrapEmbed(bq));
	enriched = enriched.replace(standaloneBQRe, (_m, bq) => wrapEmbed(bq));
	enriched = enriched.replace(/(<img\b[^>]*>)(?!\s*<\/figcaption>|<\/a><\/figure>|<\/source>|<\/video>)/gi, (_m, img) => {
		if (/class="[^"]*w-full/.test(img) || /<figure[\s\S]*$/i.test(img)) return img;
		return `<figure class="my-6 flex flex-col items-center">${img.replace(/^<img\b/i, "<img class=\"w-full max-w-full rounded border border-gray-200 bg-gray-50\" loading=\"lazy\"")}</figure>`;
	});
	enriched = enriched.replace(/<figcaption\b[^>]*>[\s\S]*?<\/figcaption>/gi, "");
	return enriched;
}
function sanitizeRichText(html) {
	let safe = html;
	safe = safe.replace(/<!--[\s\S]*?-->/g, "");
	safe = safe.replace(/&lt;script[\s\S]*?&gt;[\s\S]*?&lt;\/script&gt;/gi, "");
	safe = safe.replace(/&lt;style[\s\S]*?&gt;[\s\S]*?&lt;\/style&gt;/gi, "");
	safe = safe.replace(/&lt;noscript[\s\S]*?&gt;[\s\S]*?&lt;\/noscript&gt;/gi, "");
	safe = safe.replace(/&lt;template[\s\S]*?&gt;[\s\S]*?&lt;\/template&gt;/gi, "");
	safe = safe.replace(/&lt;svg[\s\S]*?&gt;[\s\S]*?&lt;\/svg&gt;/gi, "");
	safe = safe.replace(/<style[\s\S]*?>[\s\S]*?<\/style>/gi, "");
	safe = safe.replace(/<noscript[\s\S]*?>[\s\S]*?<\/noscript>/gi, "");
	safe = safe.replace(/<template[\s\S]*?>[\s\S]*?<\/template>/gi, "");
	safe = safe.replace(/<svg[\s\S]*?>[\s\S]*?<\/svg>/gi, "");
	safe = safe.replace(/<object[\s\S]*?>[\s\S]*?<\/object>/gi, "");
	safe = safe.replace(/<embed[\s\S]*?\/?>/gi, "");
	safe = safe.replace(/<applet[\s\S]*?>[\s\S]*?<\/applet>/gi, "");
	safe = safe.replace(/<form[\s\S]*?>[\s\S]*?<\/form>/gi, "");
	safe = safe.replace(/<input[\s\S]*?\/?>/gi, "");
	safe = safe.replace(/<button[\s\S]*?>[\s\S]*?<\/button>/gi, "");
	safe = safe.replace(/<textarea[\s\S]*?>[\s\S]*?<\/textarea>/gi, "");
	safe = safe.replace(/<select[\s\S]*?>[\s\S]*?<\/select>/gi, "");
	safe = safe.replace(/<script[\s\S]*?>[\s\S]*?<\/script>/gi, "");
	safe = safe.replace(/\son\w+(\s)*=(\s)*"[^"]*"/gi, "");
	safe = safe.replace(/\son\w+(\s)*=(\s)*'[^']*'/gi, "");
	safe = safe.replace(/\son\w+(\s)*=(\s)*[^\s>]+/gi, "");
	safe = safe.replace(/javascript:/gi, "");
	safe = safe.replace(/vbscript:/gi, "");
	safe = safe.replace(/data:text\/html/gi, "");
	const allowedTags = /<\/?(div|p|span|br|strong|b|em|i|u|h2|h3|h4|ul|ol|li|blockquote|a|figure|figcaption|img|iframe|video|source|section)\b[^>]*>/gi;
	const isSelfClosing = (raw) => /\/\s*>$/.test(raw);
	return safe.replace(/<\/?[^>]+>/gi, (tag) => {
		if (!tag.match(allowedTags)) return "";
		if (/^<\//.test(tag)) return tag;
		if (/^<blockquote\b/i.test(tag)) {
			const attrs = [];
			const clazz = (tag.match(/\sclass="([^"]*)"/i) || [])[1];
			if (clazz && /^[\w\s-]+$/.test(clazz)) attrs.push(`class="${clazz}"`);
			const cite = (tag.match(/\scite="([^"]*)"/i) || tag.match(/\scite='([^']*)'/i) || [])[1];
			if (cite) try {
				const u = new URL(cite);
				if (u.protocol === "http:" || u.protocol === "https:") attrs.push(`cite="${u.toString().replace(/"/g, "&quot;")}"`);
			} catch {}
			const lang = (tag.match(/\slang="([^"]*)"/i) || [])[1];
			if (lang && /^[a-zA-Z0-9_-]+$/.test(lang)) attrs.push(`lang="${lang}"`);
			const dir = (tag.match(/\sdir="([^"]*)"/i) || [])[1];
			if (dir === "ltr" || dir === "rtl" || dir === "auto") attrs.push(`dir="${dir}"`);
			const dataRe = /\sdata-([a-zA-Z0-9_-]+)="([^"]*)"/g;
			let dm;
			while (dm = dataRe.exec(tag)) {
				const key = `data-${dm[1].toLowerCase()}`;
				if (attrs.some((a) => a.startsWith(`${key}="`))) continue;
				const val = String(dm[2]).replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
				attrs.push(`${key}="${val}"`);
			}
			const close = isSelfClosing(tag) ? " />" : ">";
			return `<blockquote${attrs.length ? " " + attrs.join(" ") : ""}${close}`;
		}
		if (/^<figure\b/i.test(tag)) {
			const attrs = [];
			const clazz = (tag.match(/\sclass="([^"]*)"/i) || [])[1];
			if (clazz && /^[\w\s-]+$/.test(clazz)) attrs.push(`class="${clazz}"`);
			const dataRe = /\sdata-([a-zA-Z0-9_-]+)="([^"]*)"/g;
			let dm;
			while (dm = dataRe.exec(tag)) {
				const key = `data-${dm[1].toLowerCase()}`;
				if (attrs.some((a) => a.startsWith(`${key}="`))) continue;
				const val = String(dm[2]).replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
				attrs.push(`${key}="${val}"`);
			}
			const close = isSelfClosing(tag) ? " />" : ">";
			return `<figure${attrs.length ? " " + attrs.join(" ") : ""}${close}`;
		}
		if (/^<(?:img|iframe|video|source|a)\b/i.test(tag)) {
			let clean = tag;
			clean = clean.replace(/\son\w+(\s)*=(\s)*"[^"]*"/gi, "");
			clean = clean.replace(/\son\w+(\s)*=(\s)*'[^']*'/gi, "");
			clean = clean.replace(/\son\w+(\s)*=(\s)*[^\s>]+/gi, "");
			clean = clean.replace(/javascript:/gi, "");
			if (!/>$/.test(clean)) clean = clean.replace(/\s*$/, ">");
			return clean;
		}
		if (/^<(figcaption|div|p|span|ul|ol|li|section|br|strong|b|em|i|u|h2|h3|h4)\b/i.test(tag)) {
			const m = tag.match(/^<(figcaption|div|p|span|ul|ol|li|section|br|strong|b|em|i|u|h2|h3|h4)\b/i);
			if (!m) return tag;
			const tagName = m[1].toLowerCase();
			const clazz = (tag.match(/\sclass="([^"]*)"/i) || [])[1];
			const close = isSelfClosing(tag) ? " />" : ">";
			if (clazz && /^[\w\s-]+$/.test(clazz)) return `<${tagName} class="${clazz}"${close}`;
			return `<${tagName}${close}`;
		}
		return tag;
	});
}
function escapeHtml(value) {
	return value.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#39;");
}
function EmbeddedPost({ url }) {
	const embed = getEmbedConfig(url);
	(0, import_react.useEffect)(() => {
		if (!embed || typeof document === "undefined") return;
		let cancelled = false;
		if (embed.type === "instagram") {
			const process = () => {
				if (cancelled) return;
				try {
					window.instgrm?.Embeds?.process?.();
				} catch {}
			};
			const existingScript = document.querySelector("script[src=\"https://www.instagram.com/embed.js\"]");
			if (existingScript && window.instgrm?.Embeds?.process) {
				setTimeout(process, 0);
				return;
			}
			const script = existingScript ?? document.createElement("script");
			script.async = true;
			script.defer = true;
			script.src = "https://www.instagram.com/embed.js";
			script.onload = () => setTimeout(process, 50);
			script.onerror = () => {};
			if (!existingScript) document.body.appendChild(script);
			return;
		}
		if (embed.type === "twitter") {
			const load = () => {
				if (cancelled) return;
				try {
					window.twttr?.widgets?.load?.();
				} catch {}
			};
			const existingScript = document.querySelector("script[src=\"https://platform.twitter.com/widgets.js\"]");
			if (existingScript && window.twttr?.widgets?.load) {
				setTimeout(load, 0);
				return;
			}
			const script = existingScript ?? document.createElement("script");
			script.async = true;
			script.defer = true;
			script.src = "https://platform.twitter.com/widgets.js";
			script.onload = () => setTimeout(load, 50);
			script.onerror = () => {};
			if (!existingScript) document.body.appendChild(script);
			return;
		}
		if (embed.type === "tiktok") {
			if (document.querySelector("script[src=\"https://www.tiktok.com/embed.js\"]")) return;
			const script = document.createElement("script");
			script.async = true;
			script.defer = true;
			script.src = "https://www.tiktok.com/embed.js";
			script.onerror = () => {};
			document.body.appendChild(script);
		}
		return () => {
			cancelled = true;
		};
	}, [embed]);
	if (!embed) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mb-8 border border-gray-200 bg-gray-50 p-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "display mb-2 text-lg font-black uppercase",
			children: "Related Post"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
			href: url,
			target: "_blank",
			rel: "noreferrer",
			className: "break-all text-sm font-bold text-black underline",
			children: url
		})]
	});
	if (embed.type === "instagram") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "mb-8",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "overflow-hidden rounded border border-gray-200 bg-white p-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("blockquote", {
				className: "instagram-media mx-auto w-full min-w-0",
				"data-instgrm-captioned": true,
				"data-instgrm-permalink": embed.permalink,
				"data-instgrm-version": "14",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
					href: embed.permalink,
					target: "_blank",
					rel: "noreferrer",
					children: "View this post on Instagram"
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("noscript", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("iframe", {
				src: `https://www.instagram.com/p/${embed.permalink.split("/").filter(Boolean).pop()}/embed/captioned/`,
				width: "100%",
				height: "720",
				frameBorder: "0",
				scrolling: "no",
				allowTransparency: true,
				title: "Instagram post",
				className: "w-full border-0"
			}) })]
		})
	});
	if (embed.type === "twitter") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "mb-8",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "overflow-hidden rounded border border-gray-200 bg-white p-3",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("blockquote", {
				className: "twitter-tweet mx-auto",
				"data-conversation": "none",
				"data-dnt": "true",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
					href: embed.permalink,
					target: "_blank",
					rel: "noreferrer",
					children: embed.permalink
				})
			})
		})
	});
	if (embed.type === "youtube") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "mb-8",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "overflow-hidden rounded border border-gray-200 bg-white",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "aspect-video w-full",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("iframe", {
					src: embed.src,
					title: "Embedded YouTube video",
					className: "h-full w-full",
					allow: "accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share",
					referrerPolicy: "strict-origin-when-cross-origin",
					allowFullScreen: true,
					loading: "lazy"
				})
			})
		})
	});
	if (embed.type === "facebook") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "mb-8",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "overflow-hidden rounded border border-gray-200 bg-white p-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("iframe", {
				src: `https://www.facebook.com/plugins/post.php?href=${encodeURIComponent(embed.href)}&show_text=true&width=500`,
				width: "100%",
				height: "560",
				style: {
					border: "none",
					overflow: "hidden"
				},
				scrolling: "no",
				frameBorder: "0",
				allow: "autoplay; clipboard-write; encrypted-media; picture-in-picture; web-share",
				allowFullScreen: true,
				title: "Facebook post"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-2",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
					href: embed.href,
					target: "_blank",
					rel: "noreferrer",
					className: "text-sm font-bold underline text-black break-all",
					children: embed.href
				})
			})]
		})
	});
	if (embed.type === "tiktok") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "mb-8",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "overflow-hidden rounded border border-gray-200 bg-white p-3",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("blockquote", {
				className: "tiktok-embed mx-auto",
				cite: embed.permalink,
				"data-video-id": embed.videoId,
				style: {
					maxWidth: "605px",
					minWidth: "325px"
				},
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
					href: embed.permalink,
					target: "_blank",
					rel: "noreferrer",
					children: embed.permalink
				}) })
			})
		})
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mb-8 border border-gray-200 bg-gray-50 p-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "display mb-2 text-lg font-black uppercase",
			children: "Embedded Post"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
			href: embed.href ?? url,
			target: "_blank",
			rel: "noreferrer",
			className: "break-all text-sm font-bold text-black underline",
			children: embed.href ?? url
		})]
	});
}
function getEmbedConfig(url) {
	try {
		const parsed = new URL(url.trim());
		const host = parsed.hostname.replace(/^www\./, "");
		if (host === "twitter.com" || host === "x.com" || host === "mobile.twitter.com" || host === "m.x.com") return {
			type: "twitter",
			permalink: `https://x.com${parsed.pathname.replace(/\/+$/, "") || "/"}`
		};
		if (host === "instagram.com" || host === "m.instagram.com" || host === "instagr.am") {
			const pathOnly = parsed.pathname.replace(/\/+$/, "") + "/";
			if (pathOnly.startsWith("/p/") || pathOnly.startsWith("/reel/") || pathOnly.startsWith("/tv/") || pathOnly.startsWith("/stories/")) return {
				type: "instagram",
				permalink: `https://www.instagram.com${pathOnly}`
			};
			return {
				type: "link",
				href: parsed.toString()
			};
		}
		if (host === "youtube.com" || host === "m.youtube.com" || host === "youtu.be" || host === "youtube-nocookie.com" || host === "music.youtube.com") {
			const videoId = getYouTubeVideoId(parsed);
			if (videoId) return {
				type: "youtube",
				src: `https://www.youtube-nocookie.com/embed/${videoId}?rel=0`
			};
		}
		if (host === "tiktok.com" || host.endsWith(".tiktok.com")) {
			const directId = getTikTokVideoId(parsed.pathname);
			if (directId) return {
				type: "tiktok",
				permalink: `https://www.tiktok.com${parsed.pathname.replace(/\/+$/, "")}`,
				videoId: directId
			};
			const shortMatch = parsed.pathname.match(/^\/v\/(\d+)/);
			if (shortMatch) return {
				type: "tiktok",
				permalink: `https://www.tiktok.com/v/${shortMatch[1]}`,
				videoId: shortMatch[1]
			};
			return {
				type: "link",
				href: parsed.toString()
			};
		}
		if (host === "facebook.com" || host.endsWith(".facebook.com") || host === "fb.watch" || host === "fb.com") return {
			type: "facebook",
			href: parsed.toString()
		};
		return {
			type: "link",
			href: parsed.toString()
		};
	} catch {
		return null;
	}
}
function getYouTubeVideoId(parsed) {
	const host = parsed.hostname.replace(/^www\./, "");
	if (host === "youtu.be") return parsed.pathname.split("/").filter(Boolean)[0] || null;
	if (host === "youtube.com" || host === "m.youtube.com") {
		if (parsed.pathname === "/watch") return parsed.searchParams.get("v");
		if (parsed.pathname.startsWith("/shorts/") || parsed.pathname.startsWith("/embed/")) return parsed.pathname.split("/").filter(Boolean)[1] || null;
	}
	return null;
}
function getTikTokVideoId(pathname) {
	const direct = pathname.match(/\/video\/(\d+)/);
	if (direct?.[1]) return direct[1];
	return pathname.match(/\/v\/(\d+)/)?.[1] ?? null;
}
//#endregion
export { ArticlePage as component };
