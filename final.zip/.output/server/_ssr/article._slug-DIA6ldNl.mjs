import { N as notFound, m as createFileRoute, p as lazyRouteComponent } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as articleService } from "./articleService-UhMa44iK.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/article._slug-DIA6ldNl.js
var $$splitComponentImporter = () => import("./article._slug-ByZDUjW4.mjs");
var $$splitNotFoundComponentImporter = () => import("./article._slug-bSVkwLXe.mjs");
var $$splitErrorComponentImporter = () => import("./article._slug-DB8k9IqC.mjs");
var Route = createFileRoute("/article/$slug")({
	loader: async ({ params }) => {
		const article = await articleService.getBySlug(params.slug);
		if (!article || article.status !== "published") throw notFound();
		return { article };
	},
	head: ({ loaderData, params }) => {
		if (!loaderData) return { meta: [{ title: "Article — Entertainment Trends" }, {
			name: "robots",
			content: "noindex"
		}] };
		const a = loaderData.article;
		const img = a.hero_image_hd ?? a.hero_image_lq;
		return {
			meta: [
				{ title: `${a.title} — Entertainment Trends` },
				{
					name: "description",
					content: a.dek ?? a.title
				},
				{
					property: "og:title",
					content: a.title
				},
				{
					property: "og:description",
					content: a.dek ?? ""
				},
				{
					property: "og:type",
					content: "article"
				},
				{
					property: "og:url",
					content: `/article/${params.slug}`
				},
				...img ? [{
					property: "og:image",
					content: img
				}, {
					name: "twitter:image",
					content: img
				}] : []
			],
			scripts: [{
				type: "application/ld+json",
				children: JSON.stringify({
					"@context": "https://schema.org",
					"@type": "NewsArticle",
					headline: a.title,
					description: a.dek,
					image: img ? [img] : void 0,
					datePublished: a.published_at,
					articleSection: a.category?.name
				})
			}]
		};
	},
	errorComponent: lazyRouteComponent($$splitErrorComponentImporter, "errorComponent"),
	notFoundComponent: lazyRouteComponent($$splitNotFoundComponentImporter, "notFoundComponent"),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
