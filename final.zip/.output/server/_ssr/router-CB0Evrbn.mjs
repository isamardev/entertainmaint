import { r as __toESM } from "../_runtime.mjs";
import { t as supabase } from "./client-CFA_939g.mjs";
import { a as require_react, i as require_jsx_runtime, n as QueryClientProvider, t as useQuery } from "../_libs/react+tanstack__react-query.mjs";
import { n as useAuth, t as AuthProvider } from "./AuthContext-0j4f6QBo.mjs";
import { c as HeadContent, d as createRouter, f as Outlet, g as Link, h as createRootRouteWithContext, l as useLocation, m as createFileRoute, p as lazyRouteComponent, s as Scripts, v as useNavigate, y as useRouter } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as categoryService, t as articleService } from "./articleService-UhMa44iK.mjs";
import { t as QueryClient } from "../_libs/tanstack__query-core.mjs";
import { t as Toaster } from "../_libs/sonner.mjs";
import { g as Menu, n as X, p as Search } from "../_libs/lucide-react.mjs";
import { t as Route$12 } from "./admin.edit._id-BvRRdGoK.mjs";
import { t as Route$13 } from "./admin.index-B6zmczWe.mjs";
import { t as Route$14 } from "./article._slug-DIA6ldNl.mjs";
import { t as Route$15 } from "./category._slug-CEjtxhpG.mjs";
import { t as SocialFollowLinks } from "./SocialFollowLinks-Ngoy-Hnm.mjs";
import { t as Route$16 } from "./search-PxBppl7y.mjs";
import { n as HelmetProvider } from "../_libs/react-helmet-async+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/router-CB0Evrbn.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var styles_default = "/assets/styles-BbOU7dt5.css";
function Navbar() {
	const { data: categories = [] } = useQuery({
		queryKey: ["categories"],
		queryFn: categoryService.list
	});
	const [open, setOpen] = (0, import_react.useState)(false);
	const [searching, setSearching] = (0, import_react.useState)(false);
	const [q, setQ] = (0, import_react.useState)("");
	const navigate = useNavigate();
	function submitSearch(e) {
		e.preventDefault();
		if (!q.trim()) return;
		navigate({
			to: "/search",
			search: { q }
		});
		setSearching(false);
		setQ("");
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
		className: "sticky top-0 z-40 bg-background/95 backdrop-blur border-b-0",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto flex max-w-7xl items-center gap-4 px-4 py-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						className: "md:hidden",
						onClick: () => setOpen((v) => !v),
						"aria-label": "Menu",
						children: open ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { size: 22 }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Menu, { size: 22 })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/",
						className: "flex shrink-0 items-center gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: "/logo.png",
							alt: "Entertainment Trends",
							className: "h-11 w-11 object-contain"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "display hidden text-lg font-black uppercase tracking-tight sm:inline",
							children: ["Entertainment ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-black",
								children: "Trends"
							})]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
						className: "ml-4 hidden flex-1 items-center gap-1 md:flex",
						children: [
							categories.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/category/$slug",
								params: { slug: c.slug },
								className: "display px-3 py-2 text-sm font-bold uppercase tracking-wider text-foreground/80 transition-colors hover:text-black",
								activeProps: { className: "text-black" },
								children: c.name
							}, c.id)),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mx-2 h-5 w-px bg-border/70",
								"aria-hidden": "true"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/contact",
								className: "display px-3 py-2 text-sm font-bold uppercase tracking-wider text-foreground/80 transition-colors hover:text-black",
								activeProps: { className: "text-black" },
								children: "Contact Us"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/privacy-policy",
								className: "display px-3 py-2 text-sm font-bold uppercase tracking-wider text-foreground/80 transition-colors hover:text-black",
								activeProps: { className: "text-black" },
								children: "Privacy Policy"
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "ml-auto flex items-center gap-2",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: () => setSearching((v) => !v),
							"aria-label": "Search",
							className: "p-2 hover:text-black",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { size: 20 })
						})
					})
				]
			}),
			searching && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("form", {
				onSubmit: submitSearch,
				className: "border-t border-border bg-surface px-4 py-3",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto flex max-w-3xl items-center gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, {
							size: 18,
							className: "text-black"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							autoFocus: true,
							value: q,
							onChange: (e) => setQ(e.target.value),
							placeholder: "Search Entertainment Trends…",
							className: "flex-1 bg-transparent text-lg outline-none placeholder:text-muted-foreground"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							className: "yellow-bar px-4 py-1.5 text-sm font-bold uppercase tracking-wider",
							children: "Go"
						})
					]
				})
			}),
			open && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "border-t border-border bg-surface px-4 py-3 md:hidden",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
					className: "grid gap-1",
					children: [
						categories.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/category/$slug",
							params: { slug: c.slug },
							onClick: () => setOpen(false),
							className: "display border-b border-border py-2 text-sm font-bold uppercase tracking-wider",
							children: c.name
						}, c.id)),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/contact",
							onClick: () => setOpen(false),
							className: "display border-b border-border py-2 text-sm font-bold uppercase tracking-wider",
							children: "Contact Us"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/privacy-policy",
							onClick: () => setOpen(false),
							className: "display border-b border-border py-2 text-sm font-bold uppercase tracking-wider",
							children: "Privacy Policy"
						})
					]
				})
			})
		]
	});
}
function Footer() {
	const { data: categories = [] } = useQuery({
		queryKey: ["footer-categories"],
		queryFn: categoryService.list,
		staleTime: 6e4
	});
	const { data: latestResponse } = useQuery({
		queryKey: ["footer-latest"],
		queryFn: () => articleService.listPublished({ limit: 4 }),
		staleTime: 6e4
	});
	const latestArticles = latestResponse?.data ?? [];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("footer", {
		className: "mt-16 border-t border-border bg-surface",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto grid max-w-7xl gap-8 px-4 py-12 md:grid-cols-5",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: "/logo.png",
						alt: "Entertainment Trends",
						className: "mb-3 h-12 w-12 object-contain"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "display text-2xl font-black uppercase",
						children: ["Entertainment ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-yellow",
							children: "Trends"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm text-muted-foreground",
						children: "The pulse of pop culture — celebrity, TV, music, style, royals, and sport."
					})
				] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "eyebrow mb-3",
					children: "Sections"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "space-y-1 text-sm",
					children: categories.map((category) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/category/$slug",
						params: { slug: category.slug },
						children: category.name
					}) }, category.id))
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "eyebrow mb-3",
					children: "Pages"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
					className: "space-y-1 text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/contact",
						children: "Contact Us"
					}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/privacy-policy",
						children: "Privacy Policy"
					}) })]
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "eyebrow mb-3",
					children: "Latest"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "space-y-2 text-sm",
					children: latestArticles.map((article) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/article/$slug",
						params: { slug: article.slug },
						className: "line-clamp-2",
						children: article.title
					}) }, article.id))
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "eyebrow mb-3",
					children: "Follow"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SocialFollowLinks, {})] })
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "border-t border-border py-4 text-center text-xs text-muted-foreground",
			children: [
				"© ",
				(/* @__PURE__ */ new Date()).getFullYear(),
				" Entertainment Trends. All rights reserved."
			]
		})]
	});
}
function TrendingBar() {
	const { data = [] } = useQuery({
		queryKey: ["trending-bar"],
		queryFn: () => articleService.listTrending(24),
		staleTime: 6e4
	});
	const rows = import_react.useMemo(() => {
		const seen = /* @__PURE__ */ new Set();
		return (data || []).filter((a) => {
			const slug = String(a.slug || a.id || Math.random()).toLowerCase().trim();
			if (seen.has(slug)) return false;
			seen.add(slug);
			return true;
		});
	}, [data]);
	if (!rows.length) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "border-b border-gray-300 bg-white",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "container !py-0",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col items-stretch gap-2 py-2 sm:flex-row sm:items-center sm:gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex shrink-0 items-center gap-3 sm:w-auto",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "display shrink-0 px-2 text-[11px] font-black uppercase tracking-[0.25em] text-black",
						children: "Trending Now"
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "min-w-0 flex-1 overflow-x-auto overflow-y-hidden pb-1 trending-scroll",
					style: {
						scrollbarGutter: "stable both-edges",
						WebkitOverflowScrolling: "touch"
					},
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex flex-nowrap items-center gap-x-5 gap-y-0 pr-3",
						style: { minWidth: "max-content" },
						children: rows.map((a) => {
							const img = a.hero_image_hd ?? a.hero_image_lq;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
								to: "/article/$slug",
								params: { slug: a.slug || "#" },
								className: "group flex shrink-0 items-center gap-2.5",
								style: {
									width: "210px",
									height: "40px"
								},
								children: [img && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "h-9 w-12 shrink-0 overflow-hidden bg-gray-100 border border-gray-100",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
										src: img,
										alt: a.title,
										loading: "lazy",
										decoding: "async",
										className: "h-full w-full object-cover"
									})
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "display inline-block flex-1 text-[11px] font-semibold leading-[1.3] text-black group-hover:text-black",
									style: {
										width: img ? "calc(210px - 48px - 10px)" : "100%",
										wordBreak: "break-word",
										overflow: "hidden",
										display: "-webkit-box",
										WebkitLineClamp: 2,
										WebkitBoxOrient: "vertical",
										lineClamp: 2,
										minHeight: "calc(11px * 1.3 * 2)",
										maxHeight: "calc(11px * 1.3 * 2)"
									},
									children: a.title
								})]
							}, a.id);
						})
					})
				})]
			})
		})
	});
}
var inactiveClass = "hover:bg-gray-100 hover:text-black text-black";
var activeClass = "bg-black text-white";
function AdminSidebar({ open = false, onClose }) {
	const location = useLocation();
	const { signOut, isSuperAdmin } = useAuth();
	const path = location.pathname;
	const rawSearch = location.search;
	const status = typeof rawSearch === "string" ? new URLSearchParams(rawSearch).get("status") ?? "all" : rawSearch?.status ?? "all";
	const isAllArticlesActive = path === "/admin" && status === "all" || path.startsWith("/admin/edit");
	const isPublishedActive = path === "/admin" && status === "published";
	const isDraftActive = path === "/admin" && status === "draft";
	const isArchivedActive = path === "/admin" && status === "archived";
	const isNewArticleActive = path === "/admin/new";
	const isCategoriesActive = path.startsWith("/admin/categories");
	const isSettingsActive = path.startsWith("/admin/settings");
	const isSocialsActive = path.startsWith("/admin/socials");
	(0, import_react.useEffect)(() => {
		onClose?.();
	}, [path]);
	const linkClass = (active) => `block px-4 py-2 rounded text-sm transition-colors font-bold uppercase tracking-wide ${active ? activeClass : inactiveClass}`;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
		className: `fixed inset-y-0 left-0 z-50 flex w-64 min-h-screen flex-col bg-white text-black border-r border-gray-200 transition-transform duration-300 ease-in-out md:relative md:z-auto md:translate-x-0 ${open ? "translate-x-0" : "-translate-x-full"}`,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between border-b border-gray-200 p-4 md:p-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/admin",
					className: "flex items-center gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: "/logo.png",
						alt: "Entertainment Trends",
						className: "h-9 w-9 object-contain"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "display text-base font-black uppercase text-black md:text-lg",
						children: "Entertainment Trends"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: onClose,
					className: "rounded p-1 text-black hover:text-black md:hidden",
					"aria-label": "Close admin menu",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { size: 22 })
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
				className: "flex-1 space-y-2 overflow-y-auto p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/admin/new",
						className: linkClass(isNewArticleActive),
						children: "Create Article"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/admin",
						search: { status: "all" },
						className: linkClass(isAllArticlesActive),
						children: "All Article"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/admin",
						search: { status: "published" },
						className: linkClass(isPublishedActive),
						children: "Publish Article"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/admin",
						search: { status: "draft" },
						className: linkClass(isDraftActive),
						children: "Draft Article"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/admin",
						search: { status: "archived" },
						className: linkClass(isArchivedActive),
						children: "Archived Article"
					}),
					isSuperAdmin && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/admin/categories",
						className: linkClass(isCategoriesActive),
						children: "Manage Categories"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "border-t border-gray-200 p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/admin/settings",
						className: `mb-2 block ${linkClass(isSettingsActive)}`,
						children: "Account Settings"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/admin/socials",
						className: `mb-2 block ${linkClass(isSocialsActive)}`,
						children: "Social Media Links"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/",
						className: `mb-2 block rounded px-4 py-2 font-bold uppercase tracking-wide text-sm transition-colors ${inactiveClass}`,
						children: "← Back to Site"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => signOut(),
						className: "w-full rounded px-4 py-2 text-left font-bold uppercase tracking-wide text-sm text-red-600 transition-colors hover:bg-red-50 hover:text-red-800",
						children: "Sign Out"
					})
				]
			})
		]
	});
}
function AdminShell({ children }) {
	const [sidebarOpen, setSidebarOpen] = (0, import_react.useState)(false);
	const { user, loading, isAdmin } = useAuth();
	if (loading || !user || !isAdmin) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "min-h-screen bg-white",
		children
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex h-screen overflow-hidden bg-white",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "fixed top-0 right-0 left-0 z-50 flex items-center gap-3 border-b border-gray-200 bg-white px-4 py-3 md:hidden",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => setSidebarOpen(true),
						className: "rounded p-1 text-black hover:text-black",
						"aria-label": "Open admin menu",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Menu, { size: 24 })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: "/logo.png",
						alt: "Entertainment Trends",
						className: "h-8 w-8 object-contain"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "display text-sm font-black uppercase tracking-wide text-black",
						children: "Admin Panel"
					})
				]
			}),
			sidebarOpen && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "fixed inset-0 z-40 bg-black/60 md:hidden",
				"aria-label": "Close admin menu",
				onClick: () => setSidebarOpen(false)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AdminSidebar, {
				open: sidebarOpen,
				onClose: () => setSidebarOpen(false)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
				className: "admin-panel min-w-0 flex-1 overflow-hidden bg-white",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex h-full min-h-0 flex-col p-4 pt-16 md:p-6 md:pt-6",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "min-h-0 flex-1 overflow-auto",
						children
					})
				})
			})
		]
	});
}
function reportLovableError(error, context = {}) {
	if (typeof window === "undefined") return;
	window.__lovableEvents?.captureException?.(error, {
		source: "react_error_boundary",
		route: window.location.pathname,
		...context
	}, {
		mechanism: "react_error_boundary",
		handled: false,
		severity: "error"
	});
}
/**
* useScrollDirection
* Returns scroll direction ('up' | 'down') plus whether the user is at/near the
* very top of the page (so the header is always pinned at top regardless of
* scroll direction — avoids the "can't see header when already at top" edge
* case common in naive hide-on-scroll implementations).
*
* Professional characteristics:
*  - Ignores sub-pixel iOS rubber-band and tiny 1-2px scroll jitter.
*  - Minimum delta threshold (default 8px) so trackpad micro-scrolls do not
*    flip-flop the state rapidly.
*  - rAF-throttled scroll listener (not per event) so 60fps friendly.
*  - Cleans listener on unmount.
*/
function useScrollDirection(threshold = 8) {
	const [direction, setDirection] = (0, import_react.useState)("up");
	const [atTop, setAtTop] = (0, import_react.useState)(true);
	(0, import_react.useEffect)(() => {
		if (typeof window === "undefined") return;
		let lastY = window.scrollY || window.pageYOffset || 0;
		let ticking = false;
		function update() {
			const y = window.scrollY || window.pageYOffset || 0;
			const diff = y - lastY;
			setAtTop(y <= 12);
			if (Math.abs(diff) >= threshold) {
				if (diff > 0) setDirection("down");
				else setDirection("up");
				lastY = y > 0 ? y : 0;
			}
			ticking = false;
		}
		function onScroll() {
			if (!ticking) {
				window.requestAnimationFrame(update);
				ticking = true;
			}
		}
		window.addEventListener("scroll", onScroll, { passive: true });
		return () => window.removeEventListener("scroll", onScroll);
	}, [threshold]);
	return {
		direction,
		atTop
	};
}
var Route$11 = createRootRouteWithContext()({
	head: () => ({
		meta: [
			{ charSet: "utf-8" },
			{
				name: "viewport",
				content: "width=device-width, initial-scale=1"
			},
			{ title: "Entertainment Trends — The Pulse of Pop Culture" },
			{
				name: "description",
				content: "Celebrity news, TV, music, style, royals and sport. Breaking entertainment stories, updated all day on Entertainment Trends."
			},
			{
				property: "og:title",
				content: "Entertainment Trends — The Pulse of Pop Culture"
			},
			{
				property: "og:description",
				content: "Celebrity news, TV, music, style, royals and sport. Breaking entertainment stories, updated all day on Entertainment Trends."
			},
			{
				property: "og:type",
				content: "website"
			},
			{
				property: "og:site_name",
				content: "Entertainment Trends"
			},
			{
				name: "twitter:card",
				content: "summary_large_image"
			},
			{
				name: "theme-color",
				content: "#000000"
			},
			{
				name: "twitter:title",
				content: "Entertainment Trends — The Pulse of Pop Culture"
			},
			{
				name: "twitter:description",
				content: "Celebrity news, TV, music, style, royals and sport. Breaking entertainment stories, updated all day on Entertainment Trends."
			},
			{
				property: "og:image",
				content: "https://pub-bb2e103a32db4e198524a2e9ed8f35b4.r2.dev/8877d541-1325-4aa9-9324-11d58997d58f/id-preview-e25dd483--5d7e3ee2-f4bf-491f-a637-6723bb781d6f.lovable.app-1783082550814.png"
			},
			{
				name: "twitter:image",
				content: "https://pub-bb2e103a32db4e198524a2e9ed8f35b4.r2.dev/8877d541-1325-4aa9-9324-11d58997d58f/id-preview-e25dd483--5d7e3ee2-f4bf-491f-a637-6723bb781d6f.lovable.app-1783082550814.png"
			}
		],
		links: [
			{
				rel: "stylesheet",
				href: styles_default
			},
			{
				rel: "icon",
				href: "/favicon.ico",
				type: "image/x-icon"
			},
			{
				rel: "preconnect",
				href: "https://fonts.googleapis.com"
			},
			{
				rel: "preconnect",
				href: "https://fonts.gstatic.com",
				crossOrigin: "anonymous"
			},
			{
				rel: "stylesheet",
				href: "https://fonts.googleapis.com/css2?family=Oswald:wght@500;600;700;800&family=Playfair+Display:wght@700;800;900&family=Inter:wght@400;500;600;700&display=swap"
			}
		]
	}),
	shellComponent: RootShell,
	component: RootComponent,
	notFoundComponent: NotFound,
	errorComponent: ErrorBoundary
});
function RootShell({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("html", {
		lang: "en",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("head", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeadContent, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("body", { children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scripts, {})] })]
	});
}
function RootComponent() {
	const { queryClient } = Route$11.useRouteContext();
	const router = useRouter();
	const location = useLocation();
	const isAdminRoute = location.pathname.startsWith("/admin");
	const isArticlePage = location.pathname.startsWith("/article/");
	(0, import_react.useEffect)(() => {
		const { data: sub } = supabase.auth.onAuthStateChange((event) => {
			if (event === "SIGNED_IN" || event === "SIGNED_OUT" || event === "USER_UPDATED") {
				router.invalidate();
				if (event !== "SIGNED_OUT") queryClient.invalidateQueries();
			}
		});
		return () => sub.subscription.unsubscribe();
	}, [router, queryClient]);
	if (isAdminRoute) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HelmetProvider, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QueryClientProvider, {
		client: queryClient,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuthProvider, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AdminShell, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toaster, {})] }) })
	}) });
	const showTrending = isArticlePage;
	const { direction, atTop } = useScrollDirection(10);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HelmetProvider, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QueryClientProvider, {
		client: queryClient,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuthProvider, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex min-h-screen flex-col",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					ref: (0, import_react.useRef)(null),
					className: "sticky top-0 z-50 w-full will-change-transform transition-transform duration-300 ease-in-out " + (direction === "down" && !atTop ? "-translate-y-full" : "translate-y-0"),
					style: { background: "transparent" },
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Navbar, {}),
						showTrending && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "hidden h-3 w-full bg-[var(--color-yellow)] border-0 md:block",
							role: "presentation"
						}),
						showTrending && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "hidden md:block",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TrendingBar, {})
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
					className: "flex-1",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "container py-6 md:py-10",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {})
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Footer, {})
			]
		}) })
	}) });
}
function NotFound() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-[60vh] items-center justify-center px-4 text-center",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "display text-7xl font-black text-yellow",
				children: "404"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-muted-foreground",
				children: "This page has vanished from the red carpet."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
				href: "/",
				className: "mt-4 inline-block yellow-bar px-4 py-2 font-bold uppercase tracking-widest",
				children: "Back home"
			})
		] })
	});
}
function ErrorBoundary({ error, reset }) {
	(0, import_react.useEffect)(() => {
		reportLovableError(error, { boundary: "root" });
	}, [error]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-[60vh] items-center justify-center px-4 text-center",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "display text-3xl font-black uppercase",
				children: "Something broke"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm text-muted-foreground",
				children: error.message
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				onClick: reset,
				className: "mt-4 yellow-bar px-4 py-2 font-bold uppercase tracking-widest",
				children: "Try again"
			})
		] })
	});
}
var $$splitComponentImporter$10 = () => import("./privacy-policy-CZ0pVl2f.mjs");
var Route$10 = createFileRoute("/privacy-policy")({
	head: () => ({
		meta: [{ title: "Privacy Policy — Entertainment Trends" }, {
			name: "description",
			content: "Entertainment Trends' privacy policy — what data we collect, how we use it, cookies, and your rights."
		}],
		links: [{
			rel: "canonical",
			href: "/privacy-policy"
		}]
	}),
	component: lazyRouteComponent($$splitComponentImporter$10, "component")
});
var $$splitComponentImporter$9 = () => import("./contact-Dptx6Wy8.mjs");
var Route$9 = createFileRoute("/contact")({
	head: () => ({
		meta: [{ title: "Contact Us — Entertainment Trends" }, {
			name: "description",
			content: "Get in touch with the Entertainment Trends team."
		}],
		links: [{
			rel: "canonical",
			href: "/contact"
		}]
	}),
	component: lazyRouteComponent($$splitComponentImporter$9, "component")
});
var $$splitComponentImporter$8 = () => import("./auth-CtdOE9Cy.mjs");
var Route$8 = createFileRoute("/auth")({
	head: () => ({ meta: [{ title: "Sign in — Entertainment Trends" }, {
		name: "robots",
		content: "noindex"
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$8, "component")
});
var $$splitComponentImporter$7 = () => import("./admin-D95j5GrA.mjs");
var Route$7 = createFileRoute("/admin")({
	head: () => ({ meta: [{ title: "Admin — Entertainment Trends" }, {
		name: "robots",
		content: "noindex"
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$7, "component")
});
var $$splitComponentImporter$6 = () => import("./routes-BMgWR8ko.mjs");
var Route$6 = createFileRoute("/")({
	head: () => ({
		meta: [{ title: "Entertainment Trends — Celebrity, TV, Music, Style, Royals, Sports" }, {
			name: "description",
			content: "Breaking entertainment news updated all day — celebrity, movies & TV, music, style, royals, sports."
		}],
		links: [{
			rel: "canonical",
			href: "/"
		}]
	}),
	component: lazyRouteComponent($$splitComponentImporter$6, "component")
});
var $$splitComponentImporter$5 = () => import("./admin.users-Bl9BPxBW.mjs");
var Route$5 = createFileRoute("/admin/users")({ component: lazyRouteComponent($$splitComponentImporter$5, "component") });
var $$splitComponentImporter$4 = () => import("./admin.socials-dN3Y8yFE.mjs");
var Route$4 = createFileRoute("/admin/socials")({
	head: () => ({ meta: [{ title: "Social Media Links — Admin" }, {
		name: "robots",
		content: "noindex"
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$4, "component")
});
var $$splitComponentImporter$3 = () => import("./admin.settings-C8RLnoUk.mjs");
var Route$3 = createFileRoute("/admin/settings")({ component: lazyRouteComponent($$splitComponentImporter$3, "component") });
var $$splitComponentImporter$2 = () => import("./admin.new-9vT4lKoo.mjs");
var Route$2 = createFileRoute("/admin/new")({ component: lazyRouteComponent($$splitComponentImporter$2, "component") });
var $$splitComponentImporter$1 = () => import("./admin.login-s-GTWceH.mjs");
var Route$1 = createFileRoute("/admin/login")({
	head: () => ({ meta: [{ title: "Admin sign in — Entertainment Trends" }, {
		name: "robots",
		content: "noindex"
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$1, "component")
});
var $$splitComponentImporter = () => import("./admin.categories-Cxnv2rzt.mjs");
var Route = createFileRoute("/admin/categories")({ component: lazyRouteComponent($$splitComponentImporter, "component") });
var SearchRoute = Route$16.update({
	id: "/search",
	path: "/search",
	getParentRoute: () => Route$11
});
var PrivacyPolicyRoute = Route$10.update({
	id: "/privacy-policy",
	path: "/privacy-policy",
	getParentRoute: () => Route$11
});
var ContactRoute = Route$9.update({
	id: "/contact",
	path: "/contact",
	getParentRoute: () => Route$11
});
var AuthRoute = Route$8.update({
	id: "/auth",
	path: "/auth",
	getParentRoute: () => Route$11
});
var AdminRoute = Route$7.update({
	id: "/admin",
	path: "/admin",
	getParentRoute: () => Route$11
});
var IndexRoute = Route$6.update({
	id: "/",
	path: "/",
	getParentRoute: () => Route$11
});
var AdminIndexRoute = Route$13.update({
	id: "/",
	path: "/",
	getParentRoute: () => AdminRoute
});
var CategorySlugRoute = Route$15.update({
	id: "/category/$slug",
	path: "/category/$slug",
	getParentRoute: () => Route$11
});
var ArticleSlugRoute = Route$14.update({
	id: "/article/$slug",
	path: "/article/$slug",
	getParentRoute: () => Route$11
});
var AdminUsersRoute = Route$5.update({
	id: "/users",
	path: "/users",
	getParentRoute: () => AdminRoute
});
var AdminSocialsRoute = Route$4.update({
	id: "/socials",
	path: "/socials",
	getParentRoute: () => AdminRoute
});
var AdminSettingsRoute = Route$3.update({
	id: "/settings",
	path: "/settings",
	getParentRoute: () => AdminRoute
});
var AdminNewRoute = Route$2.update({
	id: "/new",
	path: "/new",
	getParentRoute: () => AdminRoute
});
var AdminLoginRoute = Route$1.update({
	id: "/login",
	path: "/login",
	getParentRoute: () => AdminRoute
});
var AdminRouteChildren = {
	AdminCategoriesRoute: Route.update({
		id: "/categories",
		path: "/categories",
		getParentRoute: () => AdminRoute
	}),
	AdminLoginRoute,
	AdminNewRoute,
	AdminSettingsRoute,
	AdminSocialsRoute,
	AdminUsersRoute,
	AdminIndexRoute,
	AdminEditIdRoute: Route$12.update({
		id: "/edit/$id",
		path: "/edit/$id",
		getParentRoute: () => AdminRoute
	})
};
var rootRouteChildren = {
	IndexRoute,
	AdminRoute: AdminRoute._addFileChildren(AdminRouteChildren),
	AuthRoute,
	ContactRoute,
	PrivacyPolicyRoute,
	SearchRoute,
	ArticleSlugRoute,
	CategorySlugRoute
};
var routeTree = Route$11._addFileChildren(rootRouteChildren)._addFileTypes();
var getRouter = () => {
	return createRouter({
		routeTree,
		context: { queryClient: new QueryClient() },
		scrollRestoration: true,
		defaultPreloadStaleTime: 0
	});
};
//#endregion
export { getRouter };
